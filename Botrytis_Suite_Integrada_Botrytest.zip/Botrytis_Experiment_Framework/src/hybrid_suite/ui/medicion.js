"use strict";

const base = location.pathname.replace(/\/$/, "");
const go = document.querySelector("#go");
const goLabel = document.querySelector("#go-label");
const pause = document.querySelector("#pause");
const restart = document.querySelector("#restart");
const status = document.querySelector("#state");
const detail = document.querySelector("#detail");
const feedback = document.querySelector("#feedback");
const counter = document.querySelector("#counter");
const progress = document.querySelector("#progress");
const canvas = document.querySelector("#preview");
const empty = document.querySelector("#view-empty");
const caption = document.querySelector("#caption");
const hybridRows = [...document.querySelectorAll("[data-hybrid]")];

let running = false;
let pauseRequested = false;
let interruption = null;

function message(state, title, text) {
  feedback.dataset.state = state;
  status.textContent = title;
  detail.textContent = text;
  detail.hidden = !text;
}

function renderProgress(schedule, trials, active = null) {
  if (!trials) return;
  const total = trials * hybridRows.length;
  let count = 0;
  for (const row of hybridRows) {
    const hybrid = row.dataset.hybrid;
    const remaining = (schedule[hybrid] || []).length;
    const done = trials - remaining;
    count += done;
    row.dataset.state = remaining === 0 ? "complete" : active === hybrid ? "active" : "pending";
    row.querySelector(".hybrid-state").textContent = `${done}/${trials}`;
    if (active === hybrid) row.setAttribute("aria-current", "step");
    else row.removeAttribute("aria-current");
  }
  progress.max = total;
  progress.value = count;
  counter.textContent = `${count} de ${total} guardadas`;
  restart.hidden = running || count === 0 || count === total;
}

async function request(path, options = {}, abort) {
  const timeout = AbortSignal.timeout(120000);
  let response;
  try {
    response = await fetch(`${base}/${path}`, {
      ...options,
      cache: "no-store",
      signal: abort ? AbortSignal.any([timeout, abort]) : timeout,
    });
  } catch (error) {
    if (abort?.aborted) throw error;
    throw new Error(error.name === "TimeoutError"
      ? "El servidor tardó demasiado en responder. Revisa PowerShell y reanuda."
      : "Se perdió la conexión. Comprueba que el servidor siga abierto en PC‑01.");
  }
  if (!response.ok) {
    const payload = await response.json().catch(() => ({}));
    throw new Error(payload.error || `El servidor devolvió el código ${response.status}.`);
  }
  return response;
}

function getClient() {
  if (!localStorage.hybridClient) {
    const random = crypto.getRandomValues(new Uint8Array(16));
    localStorage.hybridClient = Array.from(random, value => value.toString(16).padStart(2, "0")).join("");
  }
  return localStorage.hybridClient;
}

function afterPaint(signal) {
  return new Promise((resolve, reject) => {
    let frameId;
    const canceled = () => {
      cancelAnimationFrame(frameId);
      reject(signal.reason);
    };
    if (signal.aborted) {
      reject(signal.reason);
      return;
    }
    signal.addEventListener("abort", canceled, {once: true});
    frameId = requestAnimationFrame(() => {
      frameId = requestAnimationFrame(() => {
        signal.removeEventListener("abort", canceled);
        resolve();
      });
    });
  });
}

async function measureSample(hybrid, index, bytes, client, signal) {
  const start = performance.now();
  const response = await request(`infer/${hybrid}/${index}`, {method: "POST", body: bytes}, signal);
  const image = await createImageBitmap(await response.blob());
  try {
    signal.throwIfAborted();
    empty.hidden = true;
    canvas.hidden = false;
    canvas.width = image.width;
    canvas.height = image.height;
    canvas.getContext("2d").drawImage(image, 0, 0);
  } finally {
    image.close();
  }
  await afterPaint(signal);
  const elapsed = performance.now() - start;
  signal.throwIfAborted();
  await request("report", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify({
      nonce: response.headers.get("X-Trial"),
      client,
      client_ms: elapsed,
      platform: navigator.platform,
      ua: navigator.userAgent,
      width: innerWidth,
      height: innerHeight,
      dpr: devicePixelRatio,
    }),
  });
}

function pauseMessage(text) {
  goLabel.textContent = "Reanudar medición";
  message("paused", "Medición en pausa", text);
}

async function readProgress() {
  const {trials} = await request("client").then(response => response.json());
  const client = getClient();
  const schedule = await request(`schedule/${client}`).then(response => response.json());
  renderProgress(schedule, trials);
  return {trials, client, schedule};
}

restart.addEventListener("click", async () => {
  if (!confirm("¿Borrar las muestras de la medición móvil y volver a cero? TEST y los videos se conservarán.")) return;
  go.disabled = true;
  restart.disabled = true;
  try {
    await request("reset", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({client: getClient()}),
    });
    await readProgress();
    canvas.hidden = true;
    caption.hidden = true;
    empty.hidden = false;
    goLabel.textContent = "Iniciar medición";
    message("ready", "Listo para empezar", "");
  } catch (error) {
    message("error", "No se pudo reiniciar", error.message);
  } finally {
    go.disabled = false;
    restart.disabled = false;
  }
});

pause.addEventListener("click", () => {
  pauseRequested = true;
  pause.disabled = true;
  message("running", "Pausa solicitada", "Se guardará la muestra en curso antes de pausar.");
});

document.addEventListener("visibilitychange", () => {
  if (document.hidden && running) {
    pauseRequested = true;
    interruption?.abort();
  }
});

go.addEventListener("click", async () => {
  if (running) return;
  running = true;
  pauseRequested = false;
  go.disabled = true;
  restart.hidden = true;
  goLabel.textContent = "Midiendo";
  pause.hidden = false;
  pause.disabled = false;
  message("running", "Preparando medición", "Mantén esta pestaña visible durante la prueba.");
  let successful = false;
  try {
    const {trials, client, schedule} = await readProgress();
    const needed = new Set(Object.values(schedule).flat());
    const samples = new Map(await Promise.all([...needed].map(async index => {
      const response = await request(`input/${index}`);
      return [index, await response.blob()];
    })));
    for (const [hybrid, indices] of Object.entries(schedule)) {
      if (pauseRequested) break;
      message("running", `Preparando híbrido ${hybrid}`, "El servidor está cargando el modelo.");
      renderProgress(schedule, trials, hybrid);
      await request(`activate/${hybrid}`, {method: "POST"});
      message("running", `Midiendo híbrido ${hybrid}`, "Mantén esta pestaña visible.");
      for (const index of [...indices]) {
        if (pauseRequested) break;
        interruption = new AbortController();
        await measureSample(hybrid, index, samples.get(index), client, interruption.signal);
        interruption = null;
        indices.shift();
        caption.textContent = `Híbrido ${hybrid} · muestra ${index + 1}`;
        caption.hidden = false;
        renderProgress(schedule, trials, hybrid);
      }
    }
    renderProgress(schedule, trials);
    successful = Object.values(schedule).every(indices => indices.length === 0);
    if (successful) {
      goLabel.textContent = "Medición completa";
      message("complete", "Medición completada", "Los resultados se guardaron en PC‑01.");
    } else {
      pauseMessage("Las muestras guardadas se conservarán al reanudar.");
    }
  } catch (error) {
    if (interruption?.signal.aborted) {
      pauseMessage("La pestaña dejó de estar visible. Puedes continuar desde la primera muestra pendiente.");
    } else {
      goLabel.textContent = "Reintentar conexión";
      message("error", "Medición interrumpida", error.message);
    }
  } finally {
    interruption = null;
    pause.hidden = true;
    running = false;
    restart.hidden = progress.value === 0 || progress.value === progress.max;
    go.disabled = successful;
  }
});

go.disabled = true;
readProgress().then(() => {
  if (progress.value > 0 && progress.value < progress.max) pauseMessage("");
}).catch(error => {
  message("error", "No se pudo consultar el progreso", error.message);
}).finally(() => { go.disabled = false; });
