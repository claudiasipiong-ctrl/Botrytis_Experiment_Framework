"""LAN browser prototype measuring upload through presentation on the client."""
from __future__ import annotations

import io
import json
import secrets
import socket
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlsplit

from PIL import Image

from hybrid_suite.state import PAIRS, read
from hybrid_suite.video import draw_predictions, jpeg
from utils.durable import atomic_json
from utils.hashing import sha256_bytes
from utils.timing import summarize_ms

TRIALS = 10
PAGE = r"""<!doctype html><html lang="es"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta charset="utf-8"><title>Prueba híbrida desde dispositivo</title>
<style>body{font:1.1rem system-ui;margin:1rem;max-width:50rem}canvas{width:100%}button{padding:.75rem}</style>
<h1>Latencia desde dispositivo</h1><p>Mismas imágenes de video sintético TEST para los seis híbridos.</p>
<button id="go">Medir en este dispositivo</button><p id="state" role="status"></p><canvas hidden id="preview"></canvas>
<script>
const base=location.pathname.replace(/\/$/,'');
const button=document.querySelector('#go'), status=document.querySelector('#state'), canvas=document.querySelector('#preview');
const params={cache:'no-store'};
async function request(path, options) {
  const res=await fetch(base+'/'+path,{...params,...options});
  if(!res.ok) throw new Error(await res.text());
  return res;
}
button.onclick=async()=>{
  button.disabled=true;
  try {
    const kind=await request('client').then(x=>x.json());
    const client=localStorage.hybridClient||(localStorage.hybridClient=Array.from(crypto.getRandomValues(new Uint8Array(16)),x=>x.toString(16).padStart(2,'0')).join(''));
    const samples=await Promise.all(Array.from({length:kind.trials},(_,i)=>request('input/'+i).then(r=>r.blob())));
    const schedule=await request('schedule/'+client).then(x=>x.json());
    for (const [hybrid, trials] of Object.entries(schedule)) {
      status.textContent='Preparando híbrido '+hybrid;
      await request('activate/'+hybrid,{method:'POST'});
      for(const i of trials) {
        status.textContent='Híbrido '+hybrid+' · muestra '+(i+1);
        const start=performance.now();
        const r=await request('infer/'+hybrid+'/'+i,{method:'POST',body:samples[i]});
        const image=await createImageBitmap(await r.blob());
        canvas.hidden=false; canvas.width=image.width; canvas.height=image.height;
        canvas.getContext('2d').drawImage(image,0,0);
        image.close();
        await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
        await request('report',{method:'POST',headers:{'Content-Type':'application/json'},
          body:JSON.stringify({nonce:r.headers.get('X-Trial'),client,client_ms:performance.now()-start,
          platform:navigator.platform,ua:navigator.userAgent,width:innerWidth,height:innerHeight,dpr:devicePixelRatio})});
      }
    }
    status.textContent='Medición registrada';
  } catch(e) {status.textContent=e.message;button.disabled=false;}
};
</script></html>"""


def serve(evaluation, folder, key, inputs, port=8765, host="0.0.0.0", announce=print):
    from hybrid_suite.video import frame_rgb
    import cv2
    import numpy as np
    import gc

    folder.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(24)
    samples = []
    clips = sorted(inputs.glob("sintetico-*.avi"))
    if len(clips) != TRIALS:
        raise RuntimeError("Faltan clips de entrada del prototipo.")
    for path in clips:
        cap = cv2.VideoCapture(str(path))
        try:
            samples.append(jpeg(frame_rgb(cap)))
        finally:
            cap.release()
    digests = list(map(sha256_bytes, samples))
    pending = {}
    active = {}
    receipt = folder / "client.json"

    def client_trials(client, hybrid):
        def exists(i):
            path = folder / "trials" / f"{hybrid}-{i}.json"
            if not path.is_file():
                return False
            row = read(path)
            if (row["key"], row["client"], row["device"]) != (key, client, read(receipt)["device"]):
                raise RuntimeError("Registro de cliente incompatible con la comparación.")
            return True
        return [i for i in range(TRIALS) if not exists(i)]

    class Handler(BaseHTTPRequestHandler):
        def send(self, status, body, content_type, **headers):
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Referrer-Policy", "no-referrer")
            for name, value in headers.items():
                self.send_header(name, value)
            self.end_headers()
            self.wfile.write(body)

        def json(self, payload, status=200):
            self.send(status, json.dumps(payload).encode(), "application/json")

        def log_message(self, *_args):
            # Keep the token out of file and console logs.
            return

        def body(self, maximum):
            self.connection.settimeout(20)
            size = int(self.headers.get("Content-Length", -1))
            if not 0 <= size <= maximum:
                raise ValueError("Tamaño no válido.")
            data = self.rfile.read(size)
            if len(data) != size:
                raise ValueError("Solicitud incompleta.")
            return data

        def dispatch(self, post=False):
            entered = time.perf_counter()
            path = urlsplit(self.path).path.split("/")[1:]
            if not path or not secrets.compare_digest(path[0], token):
                self.json({"error": "No encontrado"}, 404)
                return
            action = path[1:]
            try:
                if not post and action == []:
                    self.send(200, PAGE.encode(), "text/html; charset=utf-8")
                elif not post and action == ["client"]:
                    self.json({"trials": TRIALS})
                elif not post and len(action) == 2 and action[0] == "input":
                    i = int(action[1])
                    if not 0 <= i < TRIALS:
                        raise ValueError("Índice no válido.")
                    self.send(200, samples[i], "image/jpeg")
                elif not post and len(action) == 2 and action[0] == "schedule":
                    client = action[1]
                    if len(client) != 32 or any(c not in "abcdef0123456789" for c in client):
                        raise ValueError("Cliente inválido.")
                    if receipt.is_file() and read(receipt)["client"] != client:
                        raise ValueError("Use el mismo navegador/dispositivo de la medición anterior.")
                    self.json({hybrid: client_trials(client, hybrid) for hybrid in PAIRS if client_trials(client, hybrid)})
                elif post and len(action) == 2 and action[0] == "activate" and action[1] in PAIRS:
                    hybrid = action[1]
                    self.body(0)
                    if active.get("hybrid") != hybrid:
                        import torch
                        active.clear()
                        gc.collect()
                        if torch.cuda.is_available():
                            torch.cuda.empty_cache()
                        models = evaluation.load(hybrid)
                        point = evaluation.point(hybrid)
                        with Image.open(io.BytesIO(samples[0])) as image:
                            for _ in range(int(evaluation.cfg["benchmark"]["warmup_iterations"])):
                                evaluation.frame(image.convert("RGB"), models, point)
                        active.update(hybrid=hybrid, models=models, point=point)
                    self.json({"warm": True})
                elif post and len(action) == 3 and action[0] == "infer" and action[1] == active.get("hybrid"):
                    i = int(action[2])
                    body = self.body(2_000_000)
                    if not 0 <= i < TRIALS or sha256_bytes(body) != digests[i]:
                        raise ValueError("La muestra difiere de la entrada sintética fijada.")
                    with Image.open(io.BytesIO(body)) as image:
                        rgb = image.convert("RGB")
                    preds, stages = evaluation.frame(rgb, active["models"], active["point"])
                    output = jpeg(draw_predictions(rgb, preds, action[1]))
                    nonce = secrets.token_hex(16)
                    pending.clear()
                    pending[nonce] = {"hybrid": action[1], "sample": i, "input_sha256": digests[i],
                                      "server_ms": (time.perf_counter() - entered) * 1000, **stages}
                    self.send(200, output, "image/jpeg", **{"X-Trial": nonce})
                elif post and action == ["report"]:
                    body = json.loads(self.body(8192))
                    row = pending.get(body["nonce"])
                    if row is None:
                        raise ValueError("Medición caducada.")
                    client = body["client"]
                    device = {k: body[k] for k in ("platform", "ua", "width", "height", "dpr")}
                    if device["ua"] != self.headers.get("User-Agent"):
                        raise ValueError("Identidad de navegador incoherente.")
                    if not np.isfinite(body["client_ms"]) or body["client_ms"] <= 0:
                        raise ValueError("Tiempo de cliente inválido.")
                    if receipt.is_file() and read(receipt) != {"client": client, "device": device, "key": key}:
                        raise ValueError("Use las mismas condiciones y dispositivo de la medición anterior.")
                    if not receipt.is_file():
                        atomic_json(receipt, {"client": client, "device": device, "key": key})
                    file = folder / "trials" / f"{row['hybrid']}-{row['sample']}.json"
                    if not file.is_file():
                        atomic_json(file, {**row, "client": client, "device": device, "client_ms": body["client_ms"], "key": key})
                    pending.pop(body["nonce"])
                    self.json({"recorded": True})
                else:
                    self.json({"error": "Petición no válida"}, 400)
            except (ValueError, KeyError, TypeError, OSError) as exc:
                try:
                    self.json({"error": str(exc)}, 400)
                except OSError:
                    pass

        def do_GET(self):
            self.dispatch()

        def do_POST(self):
            self.dispatch(post=True)

    class ConnectionLimitedServer(HTTPServer):
        def get_request(self):
            connection, address = super().get_request()
            connection.settimeout(20)
            return connection, address

    with ConnectionLimitedServer((host, port), Handler) as server:
        server.timeout = 1
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as udp:
                udp.connect(("192.0.2.1", 9))
                ip = udp.getsockname()[0]
        except OSError:
            ip = socket.gethostname()
        announce(f"Abra en el móvil o emulador, desde la misma red: http://{ip}:{server.server_port}/{token}", flush=True)
        while True:
            evaluation.clock.check()
            server.handle_request()
            if not receipt.exists():
                continue
            profile = read(receipt)
            if any(client_trials(profile["client"], hybrid) for hybrid in PAIRS):
                continue
            rows = [read(folder / "trials" / f"{hybrid}-{i}.json") for hybrid in PAIRS for i in range(TRIALS)]
            summary = {hybrid: {k: summarize_ms([r[k] for r in rows if r["hybrid"] == hybrid])
                       for k in ("client_ms", "server_ms", "pipeline_ms")} for hybrid in PAIRS}
            atomic_json(folder / "summary.json", {"key": key, "host": socket.gethostname(), "client": profile["device"],
                        "definition": "browser request through a second animation frame after drawing; includes transfer and browser decode",
                        "results": summary, "trials": rows})
            return ["summary.json", "client.json", *[f"trials/{r['hybrid']}-{r['sample']}.json" for r in rows]]
