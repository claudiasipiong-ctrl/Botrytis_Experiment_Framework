"""Synthetic clips, frame-level evidence and same-host video benchmarking."""
from __future__ import annotations

import io
import platform
import time

import cv2
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageOps

from hybrid_suite.state import completed, read, seal
from utils.boxes import iou_matrix
from utils.durable import atomic_bytes, atomic_json
from utils.hashing import sha256_file
from utils.io import load_image_rgb
from utils.timing import summarize_ms

FPS = 30
SIZE = (1280, 720)
FOURCC = cv2.VideoWriter_fourcc(*"MJPG")


def encode(path, frames):
    tmp = path.with_name(path.stem + ".partial.avi")
    writer = cv2.VideoWriter(str(tmp), FOURCC, FPS, SIZE)
    try:
        if not writer.isOpened():
            raise RuntimeError("OpenCV no pudo abrir el codificador MJPG.")
        count = 0
        for frame in frames:
            writer.write(cv2.cvtColor(np.asarray(frame), cv2.COLOR_RGB2BGR))
            count += 1
    finally:
        writer.release()
    cap = cv2.VideoCapture(str(tmp))
    try:
        if (not count or not cap.isOpened() or int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) != count
                or abs(cap.get(cv2.CAP_PROP_FPS) - FPS) > 0.001):
            raise RuntimeError(f"Video inválido: {path}")
    finally:
        cap.release()
    tmp.replace(path)


def make_clips(evaluation, folder, key):
    if completed(folder, key, marker="suite.json"):
        return
    folder.mkdir(parents=True, exist_ok=True)
    ids = evaluation.ids("test")
    entries = []
    for clip in range(10):
        evaluation.clock.check()
        assigned = ids[clip::10] or [ids[clip % len(ids)]]
        path = folder / f"sintetico-test-{clip + 1:02d}.avi"
        memo = folder / f"{clip:02d}.json"
        shots = [{"id": iid, "source_sha256": sha256_file(evaluation.paths[iid]), "frames": FPS} for iid in assigned]
        entry = {"name": path.name, "shots": shots, "fps": FPS, "frames": FPS * len(shots),
                 "resolution": list(SIZE), "partition": "test", "synthetic": True}
        if not completed(folder, key, marker=memo.name):
            def frames():
                for i, iid in enumerate(assigned):
                    source = ImageOps.pad(load_image_rgb(evaluation.paths[iid]), SIZE, color="black")
                    for frame in range(FPS):
                        # Deterministic crop/zoom introduces modest motion within each still shot.
                        inset = frame // 3
                        image = source.crop((inset, inset, SIZE[0] - inset, SIZE[1] - inset)).resize(SIZE)
                        ImageDraw.Draw(image).text((12, 12), f"SINTETICO / TEST / {clip + 1:02d} / {i + 1:02d}", fill="white", stroke_width=2, stroke_fill="black")
                        yield image
            encode(path, frames())
            seal(folder, key, [path.name], entry, marker=memo.name)
        entries.append(entry)
    atomic_json(folder / "manifest.json", {"fps": FPS, "synthetic": True, "clips": entries})
    seal(folder, key, ["manifest.json", *[i["name"] for i in entries]], marker="suite.json")


def draw_predictions(image, predictions, hybrid):
    output = image.copy()
    draw = ImageDraw.Draw(output)
    for row in predictions:
        color = "orange" if row["positive"] else "lime"
        x, y, _, _ = row["box"]
        draw.rectangle(row["box"], outline=color, width=3)
        draw.text((x, y), f'{row["prob"]:.2f}', fill=color, stroke_width=2, stroke_fill="black")
    draw.text((12, 34), f"Hibrido {hybrid}", fill="white", stroke_width=2, stroke_fill="black")
    return output


def jpeg(image):
    stream = io.BytesIO()
    image.save(stream, format="JPEG", quality=90)
    return stream.getvalue()


def continuity(before, after):
    """Count one-to-one same-label matches at IoU >= .5 between adjacent frames."""
    b = np.asarray([r["box"] for r in before], dtype=float).reshape(-1, 4)
    a = np.asarray([r["box"] for r in after], dtype=float).reshape(-1, 4)
    if not len(b) or not len(a):
        return 0, len(b), bool(len(b) and not len(a))
    scores = iou_matrix(b, a)
    matches = 0
    used_b, used_a = set(), set()
    for k in np.argsort(-scores, axis=None, kind="stable"):
        i, j = np.unravel_index(k, scores.shape)
        if scores[i, j] < 0.5:
            break
        if i not in used_b and j not in used_a and before[i]["positive"] == after[j]["positive"]:
            used_b.add(i)
            used_a.add(j)
            matches += 1
    return matches, len(b), False


def frame_rgb(cap):
    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("Video truncado durante decodificación.")
    return Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))


def video_trial(evaluation, hybrid, folder, key, inputs):
    point = evaluation.point(hybrid)
    models = evaluation.load(hybrid)
    manifest = read(inputs / "manifest.json")
    all_rows, summaries, outputs = [], [], []
    for clip in manifest["clips"]:
        evaluation.clock.check()
        name = clip["name"]
        cap = cv2.VideoCapture(str(inputs / name))
        units = folder / "frames" / name
        units.mkdir(parents=True, exist_ok=True)
        records = []
        try:
            # Same warm-up protocol for each hybrid on each run/resumption.
            warm = frame_rgb(cap)
            for _ in range(int(evaluation.cfg["benchmark"]["warmup_iterations"])):
                evaluation.frame(warm, models, point)
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            for index in range(clip["frames"]):
                evaluation.clock.check()
                unit = units / f"{index:05d}.json"
                annotated = unit.with_suffix(".jpg")
                start = time.perf_counter()
                rgb = frame_rgb(cap)
                decoded = time.perf_counter()
                if not unit.is_file():
                    preds, stages = evaluation.frame(rgb, models, point)
                    render_start = time.perf_counter()
                    content = jpeg(draw_predictions(rgb, preds, hybrid))
                    end = time.perf_counter()
                    atomic_bytes(annotated, content)
                    stored = time.perf_counter()
                    atomic_json(unit, {"key": key, "frame": index, "sha256": sha256_file(annotated), "predictions": preds,
                                       "decode_ms": (decoded - start) * 1000, **stages, "render_encode_ms": (end - render_start) * 1000,
                                       "prediction_frame_write_ms": (stored - end) * 1000,
                                       "frame_ms": (end - start) * 1000})
                record = read(unit)
                if (record["key"], record["frame"], record["sha256"]) != (key, index, sha256_file(annotated)):
                    raise RuntimeError(f"Fotograma previo alterado: {annotated}")
                records.append(record)
        finally:
            cap.release()
        lag = 0.0
        matches = eligible = dropouts = adjacent = 0
        rows = []
        for index, record in enumerate(records):
            next_lag = max(0.0, lag + record["frame_ms"] - 1000 / FPS)
            if index and index % FPS:
                m, n, dropout = continuity(records[index - 1]["predictions"], record["predictions"])
                matches += m
                eligible += n
                dropouts += dropout
                adjacent += 1
            rows.append({"video": name, "frame": index, "image_id": clip["shots"][index // FPS]["id"],
                         "detections": len(record["predictions"]), "finish_after_capture_ms": lag + record["frame_ms"],
                         "over_33ms": lag + record["frame_ms"] > 1000 / FPS,
                         **{k: v for k, v in record.items() if k.endswith("_ms")}})
            lag = next_lag
        output = f"pred-{hybrid}-{name}"
        video_file = folder / output
        assembly_receipt = folder / f"assembly-{name}.json"
        if not completed(folder, key, marker=assembly_receipt.name):
            assembly_start = time.perf_counter()
            def saved_frames():
                for index in range(len(records)):
                    with Image.open(units / f"{index:05d}.jpg") as image:
                        yield image.convert("RGB")
            encode(video_file, saved_frames())
            seal(folder, key, [output], {"assembly_seconds": time.perf_counter() - assembly_start}, marker=assembly_receipt.name)
        assembly = read(assembly_receipt)["metadata"]["assembly_seconds"]
        working = sum(r["frame_ms"] for r in rows) / 1000
        summaries.append({"video": name, "frames": len(rows), "synthetic": True, "source_fps": FPS,
                          "effective_fps": len(rows) / working, "processing_seconds": working,
                          "output_assembly_seconds": assembly, "total_active_seconds": working + assembly + sum(r["prediction_frame_write_ms"] for r in rows) / 1000,
                          "detected_frame_fraction": sum(bool(r["detections"]) for r in rows) / len(rows),
                          "continuity_same_class_iou50": matches / eligible if eligible else None,
                          "adjacent_within_shot": adjacent, "matched_boxes": matches, "previous_boxes": eligible,
                          "complete_dropout_transitions": dropouts, "over_33ms_frames": sum(r["over_33ms"] for r in rows),
                          **{k: summarize_ms([r[k] for r in rows]) for k in rows[0] if k.endswith("_ms")}})
        all_rows.extend(rows)
        outputs.extend([output, assembly_receipt.name])
    pd.DataFrame(all_rows).to_csv(folder / "frame_timing.csv", index=False)
    atomic_json(folder / "summary.json", {"hybrid": hybrid, "videos": summaries, "host": platform.node(),
                "delay_definition": "simulated FIFO at 30 FPS; 33.33 ms frame budget; not a human-perception measurement",
                "timing_definition": "active decode/inference/render/JPEG, durable annotated frame writes and AVI encoding; excludes ledger writes, backup, gaps and model load"})
    return ["frame_timing.csv", "summary.json", *outputs]
