"""Publish a local, readable view of the sealed evidence on each PC."""
from __future__ import annotations

import html
from pathlib import Path

from hybrid_suite.state import PAIRS, checkpoint_copy, read, safe_path, token
from utils.durable import atomic_bytes, atomic_copy
from utils.hashing import sha256_file


def copy_current(source, target):
    digest = sha256_file(source)
    if not target.is_file() or sha256_file(target) != digest:
        atomic_copy(source, target)
        if sha256_file(target) != digest:
            raise RuntimeError(f"El informe cambió mientras se copiaba: {source}")


def local_report(work, root, pc, final=False):
    landing = root
    case = work.name
    root = landing / case
    root.mkdir(parents=True, exist_ok=True)
    output_rows, summaries = [], []
    links = [("Plan de asignación y estimaciones", "plan.json"), ("Configuración congelada", "freeze.json"),
             ("Manuscrito histórico y nota metodológica", "consolidated/historical-manuscript.json"),
             ("Resultados TEST y estado de A–F", "consolidated/test.csv"),
             ("Tiempos de video sintético", "consolidated/synthetic-video.csv"),
             ("Mediciones del prototipo móvil", "consolidated/deployment.csv"),
             ("Matrices de confusión", "consolidated/matrices-confusion.png"),
             ("F1 positivo en TEST", "consolidated/f1-positivo-test.png"),
             ("Latencia p95 de video", "consolidated/video-p95.png"),
             ("Latencia p95 de despliegue", "consolidated/deployment-p95.png"),
             ("Proveniencia de los resultados", "consolidated/provenance.json")]
    visible = []
    for title, filename in links:
        source = work / filename
        if source.is_file():
            copy_current(source, root / filename)
            visible.append(f'<li><a href="{filename}">{html.escape(title)}</a></li>')
    for hybrid in PAIRS:
        listing = []
        for label, task in (("VAL", f"point-{hybrid}"), ("TEST", f"test-{hybrid}"), ("Video sintético", f"video-{hybrid}")):
            folder = work / "tasks" / task
            file = folder / "complete.json"
            if not file.is_file():
                continue
            receipt = read(file)
            files = receipt.get("files", {})
            selected = []
            for name, digest in sorted(files.items()):
                if not token(digest) or name.startswith("assembly-"):
                    continue
                source = safe_path(folder, name)
                # Use the LAN copy for playback. The verified backup also keeps the AVI locally.
                if Path(name).suffix.lower() == ".avi":
                    url = html.escape(source.as_uri(), quote=True)
                    selected.append(f'<li><a href="{url}">{html.escape(name)} (carpeta compartida)</a></li>')
                    continue
                dest = safe_path(root / "tasks" / task, name)
                checkpoint_copy(source, dest, digest)
                url = dest.relative_to(root).as_posix()
                selected.append(f'<li><a href="{html.escape(url, quote=True)}">{html.escape(name)}</a></li>')
            listing.append(f"<details><summary>{label}</summary><ul>{''.join(selected)}</ul></details>")
        legacy = sorted((work / "legacy" / hybrid).glob("*/test_results.json"))
        if len(legacy) == 1:
            path = legacy[0]
            checkpoint_copy(path, root / "historical" / f"{hybrid}.json", path.parent.name)
            listing.append(f'<p><a href="historical/{hybrid}.json">Resultado TEST histórico sellado</a></p>')
        output_rows.append(f'<section><h2>{hybrid} · {html.escape(" + ".join(PAIRS[hybrid]))}</h2>'
                           f'{"".join(listing) or "<p>Sin artefactos sellados de esta ejecución.</p>"}</section>')
    for name in ("f1-positivo-test.png", "matrices-confusion.png", "video-p95.png", "deployment-p95.png"):
        if (root / "consolidated" / name).is_file():
            summaries.append(f'<figure><img src="consolidated/{name}" alt="{name}"></figure>')
    status = "Ejecución consolidada" if final else "Avance disponible"
    index = f"""<!doctype html><html lang="es"><meta charset="UTF-8"><meta name="viewport" content="width=device-width">
<title>Evaluación de híbridos</title><style>body{{font:16px system-ui;margin:1.5rem auto;max-width:960px;padding:0 1rem}}
img{{max-width:100%}}section{{border-top:1px solid #cedadf;margin:1rem 0}}a{{color:#04646b}}</style>
<h1>{status} · {html.escape(pc)}</h1><p>Artefactos verificados de la suite A–F. Los AVI se guardan en el espacio compartido y el respaldo.</p>
<ul>{''.join(visible)}</ul>{''.join(summaries)}{''.join(output_rows)}</html>"""
    atomic_bytes(root / "index.html", index.encode("utf-8"))
    escaped = html.escape(case, quote=True)
    hub = f"""<!doctype html><html lang="es"><meta charset="utf-8"><title>Resultados A–F</title>
<h1>{status} · {html.escape(pc)}</h1><p><a href="{escaped}/index.html">Abrir el informe de la ejecución</a></p></html>"""
    atomic_bytes(landing / "index.html", hub.encode("utf-8"))
