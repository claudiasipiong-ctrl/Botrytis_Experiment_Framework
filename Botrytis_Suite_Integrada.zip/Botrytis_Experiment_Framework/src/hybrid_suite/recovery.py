"""Recover data and evidence from local handoff archives without executing them."""
from __future__ import annotations

import logging
import os
import re
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from hybrid_suite.state import read
from utils.durable import atomic_json
from utils.hashing import sha256_file, sha256_json

RECOVERY_FORMAT = 1
SKIP_ARCHIVE = re.compile(r"botrytis_(?:hibridos_a-f|consolidado_tesis|suite_integrada)", re.I)
SKIP_PATH = re.compile(r"rt[\W_]*detr|[/\\](?:\.venv|__pycache__|demo|historical|superseded|smoke)(?:[/\\]|$)", re.I)
ARTIFACT = re.compile(r"dataset_(?:validation|inventory)|split_(?:manifest|metadata)|test_lock|(?:inner_)?fold|image_manifest|"
                      r"quarantine_manifest|near_duplicate_review|freeze_manifest|test_results|final_meta|pipeline_validation|"
                      r"inference_thresholds|final_thresholds|outer_validation|checkpoints|comparison", re.I)
EVIDENCE = re.compile(r"metadata|metrics|pipeline_|timing|confusion|precision|recall|summary|matrices|ap_per_iou", re.I)
IMAGE = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
TABLE = {".json", ".csv", ".tsv", ".sha256", ".yaml", ".yml", ".txt", ".log"}
WINDOWS_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"{p}{i}" for p in ("COM", "LPT") for i in range(1, 10))}


def zip_member(entry):
    name = entry.filename.replace("\\", "/")
    if entry.is_dir() or stat.S_ISLNK(entry.external_attr >> 16):
        return None
    parts = PurePosixPath(name).parts
    if not parts or name.startswith("/") or SKIP_PATH.search("/" + name):
        return None
    if any(p in (".", "..") or p != p.rstrip(" .") or re.search(r'[<>:"|?*\x00-\x1f]', p)
           or p.split(".")[0].upper() in WINDOWS_RESERVED for p in parts):
        return None
    return Path(*parts)


def evidence_member(path):
    parts = [x.casefold() for x in path.parts]
    suffix = path.suffix.casefold()
    if any(x in parts for x in ("derived", "derived_v4", "derived_v5", "crops", "detections")) and not EVIDENCE.search(path.name):
        return False
    if len(parts) >= 2 and parts[-2] in ("images", "imagenes", "imágenes"):
        return suffix in IMAGE
    if len(parts) >= 2 and parts[-2] in ("labels", "etiquetas"):
        return suffix == ".txt"
    if "configs" in parts:
        return path.name.casefold() in ("default.yaml", "local.yaml")
    if suffix in (".pt", ".pth"):
        return path.name.casefold() == "final.pt" and "checkpoints" in parts
    if suffix in TABLE and ARTIFACT.search(path.as_posix()):
        return True
    if any(x in parts for x in ("runs", "reports", "results", "figures", "figuras", "graficos")):
        return suffix in IMAGE or suffix in TABLE and EVIDENCE.search(path.name)
    return False


def copy_entry(package, entry, target, clock):
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.with_name(target.name + ".importing")
    try:
        with package.open(entry) as src, tmp.open("wb") as dst:
            while block := src.read(8 * 1024 * 1024):
                clock.check()
                dst.write(block)
            dst.flush()
            os.fsync(dst.fileno())
        os.replace(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)


def unpack_evidence(archive, target, clock, depth=0):
    """Keep each ZIP in its own namespace and use a separate tree for nested ZIPs."""
    target.mkdir(parents=True, exist_ok=True)
    files = {}
    receipt = target / ".recovering.json"
    if receipt.is_file():
        files.update(read(receipt))
    with zipfile.ZipFile(archive) as package:
        names = set()
        for entry in package.infolist():
            clock.check()
            path = zip_member(entry)
            if path is None:
                continue
            relative = path.as_posix()
            normalized = relative.casefold()
            if normalized in names:
                raise ValueError(f"Dos entradas tienen la misma ruta en Windows: {relative}")
            names.add(normalized)
            if path.suffix.casefold() == ".zip" and not SKIP_ARCHIVE.search(path.name):
                if depth >= 6:
                    logging.warning("ZIP interno fuera de alcance: %s", relative)
                    continue
                nested_name = "nested-" + sha256_json(relative)[:16]
                nested_target = target / nested_name
                if (nested_target / ".recovered.json").is_file():
                    continue
                with tempfile.TemporaryDirectory(prefix="zip-interno-", dir=target.parent) as temp:
                    nested_zip = Path(temp) / "archive.zip"
                    copy_entry(package, entry, nested_zip, clock)
                    unpack_evidence(nested_zip, nested_target, clock, depth + 1)
                continue
            if evidence_member(path):
                dest = target / path
                recorded = files.get(relative)
                if recorded and dest.is_file() and sha256_file(dest) == recorded:
                    continue
                copy_entry(package, entry, dest, clock)
                files[relative] = sha256_file(dest)
                atomic_json(receipt, files)
    atomic_json(target / ".recovered.json", {"format": RECOVERY_FORMAT, "files": files})
    receipt.unlink(missing_ok=True)


def recover_downloads(downloads, target, clock):
    target.mkdir(parents=True, exist_ok=True)
    imported = []
    for archive in sorted(downloads.iterdir(), key=lambda path: path.name.casefold()):
        if not archive.is_file() or archive.suffix.casefold() != ".zip" or SKIP_ARCHIVE.search(archive.name) or SKIP_PATH.search(archive.name):
            continue
        clock.check()
        stat_data = archive.stat()
        key = sha256_json([RECOVERY_FORMAT, archive.name, stat_data.st_size, stat_data.st_mtime_ns])[:20]
        directory = target / key
        try:
            if not (directory / ".recovered.json").is_file():
                unpack_evidence(archive, directory, clock)
                current = archive.stat()
                if (current.st_size, current.st_mtime_ns) != (stat_data.st_size, stat_data.st_mtime_ns):
                    (directory / ".recovered.json").unlink(missing_ok=True)
                    raise ValueError("El ZIP cambió mientras se leía.")
            imported.append(directory)
        except (OSError, ValueError, zipfile.BadZipFile) as exc:
            logging.warning("ZIP de Descargas pendiente: %s (%s)", archive.name, exc)
            print(f"ZIP de Descargas pendiente: {archive.name} ({exc})", flush=True)
    return imported


def evidence_trees(roots):
    """Find evidence in both a checkout (artifacts/v4) and a project sync export."""
    artifacts, raw, configs, runs = set(), set(), set(), set()
    for root in sorted(set(roots)):
        if not root.is_dir():
            continue
        for directory, children, files in os.walk(root):
            folders = {child.casefold(): child for child in children}
            files = set(files)
            path = Path(directory)
            children[:] = [child for child in sorted(children) if not child.startswith((".", "tmp"))
                           and child not in ("derived_v4", "crops", "__pycache__", "HybridSuite", "Consolidado_Tesis")
                           and not (path / child).is_symlink()]
            if any(name == "dataset_validation.json" or name.startswith(("freeze_manifest", "test_results", "pipeline_validation")) for name in files):
                artifacts.add(path)
            if "final_meta.json" in files and path.parent.name == "checkpoints":
                artifacts.add(path.parent.parent)
            if path.name == "inference_thresholds":
                artifacts.add(path.parent)
            if path.name == "runs":
                runs.add(path)
            if path.name == "configs":
                configs.update(path / filename for filename in ("local.yaml", "default.yaml") if filename in files)
            images = next((folders[k] for k in ("images", "imagenes", "imágenes") if k in folders), None)
            labels = next((folders[k] for k in ("labels", "etiquetas") if k in folders), None)
            if images and labels:
                image_path, label_path = path / images, path / labels
                if any(p.is_file() and p.suffix.casefold() in IMAGE for p in image_path.iterdir()):
                    raw.add((image_path, label_path))
                children[:] = [child for child in children if child not in (images, labels)]
    return sorted(artifacts), sorted(raw), sorted(configs), sorted(runs)
