"""VAL calibration and resumable evaluation of the fixed hybrid matrix."""
from __future__ import annotations

import gc
import socket
import time
from pathlib import Path

import numpy as np
import pandas as pd

from hybrid_suite.state import PAIRS, completed, read, seal
from utils.architectures import get_arch
from utils.classifier_models import load_classifier
from utils.durable import atomic_json
from utils.hashing import sha256_json
from utils.inference import crops_from_boxes, load_detector, predict_detector, predict_paths
from utils.io import load_image_rgb
from utils.metrics_classification import pick_threshold, threshold_sweep
from utils.metrics_detection import ap_over_iou_table, conf_sweep
from utils.pipeline_eval import _classify_timed, evaluate_pipeline, gt_from_fruit_table, summarize_from_table
from utils.timing import synchronize
from utils.training_common import resolve_device


class Evaluation:
    def __init__(self, cfg, data, work, checkpoints, clock):
        self.cfg, self.data, self.work = cfg, data, work
        self.checkpoints, self.clock = checkpoints, clock
        self.match = float(cfg["matching"]["threshold"])
        self.pos, self.neg = (cfg["classification_labels"][key] for key in ("positive_label", "negative_label"))
        self.paths = {row.image_id: Path(row.image_path) for row in data.images.itertuples(index=False)}

    def ids(self, split):
        ids = sorted(self.data.manifest.loc[self.data.manifest["outer_split"] == split, "image_id"])
        if not ids:
            raise RuntimeError(f"Partición vacía: {split}")
        return ids

    def output(self, name):
        return self.work / "tasks" / name

    def point(self, hybrid):
        return read(self.output(f"point-{hybrid}") / "point.json")

    def detector(self, model):
        return load_detector(self.checkpoints(model), get_arch(model))

    def load(self, hybrid):
        det, cls = PAIRS[hybrid]
        detector = self.detector(det)
        classifier, meta = load_classifier(self.checkpoints(cls), resolve_device(self.cfg))
        if get_arch(meta["arch"]).name != cls or tuple(meta["classes"]) != (self.neg, self.pos):
            raise RuntimeError(f"Checkpoint incompatible con arquitectura/clases de {hybrid}.")
        return detector, classifier, meta["norm"]

    def detector_stage(self, model, split, key, folder):
        tuning = self.cfg["inference_tuning"]
        ids = self.ids(split)
        gts = gt_from_fruit_table(self.data.fruits, ids)
        truth = [gts[i]["boxes"] for i in ids]
        nms_ious = [float(self.cfg["detector"]["val_nms_iou"])]
        if split == "validation" and get_arch(model).family == "yolov8":
            nms_ious = list(map(float, tuning["detector_nms_iou_grid"]))
        confs = list(map(float, tuning["detector_conf_grid"]))
        conf = min(confs) if split == "validation" else float(self.cfg["detector"]["val_conf"])
        detector = self.detector(model)
        sweeps = []
        for index, nms in enumerate(nms_ious):
            predictions = []
            for i, image_id in enumerate(ids):
                self.clock.check()
                file = folder / "units" / f"{index}-{i:05d}.json"
                if not file.exists():
                    boxes, scores = predict_paths(detector, [self.paths[image_id]], conf=conf, iou=nms, cfg=self.cfg)[0]
                    atomic_json(file, {"key": key, "id": image_id, "boxes": boxes.tolist(), "scores": scores.tolist()})
                row = read(file)
                if (row["key"], row["id"]) != (key, image_id):
                    raise RuntimeError(f"Unidad incompatible: {file}")
                predictions.append((np.asarray(row["boxes"]).reshape(-1, 4), np.asarray(row["scores"])))
            if split == "validation":
                sweeps.append(conf_sweep(predictions, truth, confs, self.match).assign(nms_iou=nms))
        if split == "test":
            ap = ap_over_iou_table(predictions, truth)
            ap.to_csv(folder / "ap_by_iou.csv", index=False)
            atomic_json(folder / "summary.json", {"map50": float(ap["ap"].iloc[0]), "map50_95": float(ap["ap"].mean()),
                        "method": "utils.metrics.average_precision_detection", "n_images": len(ids)})
            return ["summary.json", "ap_by_iou.csv"]
        sweep = pd.concat(sweeps, ignore_index=True)
        metric = tuning["detector_threshold_metric"]
        if metric == "f2":
            p, r = sweep["precision"], sweep["recall"]
            sweep["f2"] = (5 * p * r / (4 * p + r).replace(0, np.nan)).fillna(0)
        # Use the project's tie rule over the complete grid.
        tied = sweep[np.isclose(sweep[metric], sweep[metric].max(), atol=1e-12)]
        best = tied.sort_values(["conf", "nms_iou"], ascending=[False, True]).iloc[0]
        sweep.to_csv(folder / "sweep.csv", index=False)
        atomic_json(folder / "point.json", {"det_conf": float(best["conf"]), "nms_iou": float(best["nms_iou"]),
                    "source": "outer_validation_20pct"})
        return ["point.json", "sweep.csv"]

    def integrated(self, hybrid, split, point, key, folder):
        ids = self.ids(split)
        gt = gt_from_fruit_table(self.data.fruits, ids)
        detector, classifier, norm = self.load(hybrid)
        detections, misses, timing = [], [], []
        from utils.pipeline_eval import DET_COLUMNS, MISS_COLUMNS
        for i, image_id in enumerate(ids):
            self.clock.check()
            unit = folder / "units" / f"{i:06d}.json"
            if not unit.is_file():
                result = evaluate_pipeline(self.cfg, detector=detector, classifier=classifier, norm=norm,
                                           image_paths={image_id: self.paths[image_id]}, gt=gt,
                                           conf=point["det_conf"], nms_iou=point["nms_iou"], cls_threshold=point["cls_threshold"],
                                           match_iou=self.match, max_examples=0)
                atomic_json(unit, {"key": key, "id": image_id,
                                   "detections": result.detections.replace({np.nan: None}).to_dict("records"),
                                   "misses": result.misses.to_dict("records"), "timing": result.per_image.to_dict("records")})
            record = read(unit)
            if (record["key"], record["id"]) != (key, image_id):
                raise RuntimeError(f"Unidad incompatible: {unit}")
            detections.extend(record["detections"])
            misses.extend(record["misses"])
            timing.extend(record["timing"])
        det = pd.DataFrame(detections, columns=DET_COLUMNS)
        fn = pd.DataFrame(misses, columns=MISS_COLUMNS)
        op = {k: point[k] for k in ("det_conf", "nms_iou", "cls_threshold")}
        op["match_iou"] = self.match
        files = ["summary.json", "detections.csv", "misses.csv", "timing.csv", "examples.jpg"]
        if split == "validation":
            matched = det[det["matched_fruit_id"].notna()]
            if matched["gt_label"].nunique() != 2:
                raise RuntimeError(f"{hybrid}: el ajuste en VAL requiere ambas clases entre los frutos asociados.")
            tuning = self.cfg["inference_tuning"]
            sweep = threshold_sweep(matched["gt_label"].eq(self.pos).astype(int), matched["p_con_signos"],
                                    n_points=int(tuning["classifier_threshold_grid_points"]))
            threshold, _ = pick_threshold(sweep, tuning["classifier_threshold_metric"])
            op["cls_threshold"] = threshold
            atomic_json(folder / "point.json", {**op, "source": "predicted_crops_outer_validation_20pct"})
            sweep.to_csv(folder / "sweep.csv", index=False)
            files += ["point.json", "sweep.csv"]
        summary, det, _ = summarize_from_table(det, fn, n_images=len(ids), pos=self.pos, neg=self.neg, op=op)
        atomic_json(folder / "summary.json", summary)
        det.to_csv(folder / "detections.csv", index=False)
        fn.to_csv(folder / "misses.csv", index=False)
        pd.DataFrame(timing).to_csv(folder / "timing.csv", index=False)
        self.examples(ids, det, fn, folder / "examples.jpg")
        return files

    def examples(self, ids, detections, misses, target):
        from PIL import Image, ImageDraw
        selected = sorted(ids, key=lambda i: (-int(misses["image_id"].eq(i).sum()), i))[:6]
        canvas = Image.new("RGB", (960, 320 * ((len(selected) + 2) // 3)), "#18222c")
        for index, image_id in enumerate(selected):
            image = load_image_rgb(self.paths[image_id])
            draw = ImageDraw.Draw(image)
            width = max(2, image.width // 320)
            for row in detections[detections["image_id"].eq(image_id)].itertuples():
                draw.rectangle((row.x1, row.y1, row.x2, row.y2), outline={"EC": "orange", "TP": "lime"}.get(row.outcome, "red"), width=width)
            for row in misses[misses["image_id"].eq(image_id)].itertuples():
                draw.rectangle((row.x1, row.y1, row.x2, row.y2), outline="cyan", width=width)
            image.thumbnail((312, 290))
            x, y = (index % 3) * 320, (index // 3) * 320
            canvas.paste(image, (x, y))
            ImageDraw.Draw(canvas).text((x + 4, y + 293), image_id[:44], fill="white")
        canvas.save(target, format="JPEG")

    def execute(self, name, key, operation):
        if key is None:
            raise RuntimeError(f"Tarea sin identidad: {name}")
        folder = self.output(name)
        if completed(folder, key):
            return
        folder.mkdir(parents=True, exist_ok=True)
        self.clock.check()
        outputs = operation(folder)
        seal(folder, key, outputs, {"host": socket.gethostname()})
        gc.collect()
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def frame(self, image, models, point):
        detector, classifier, norm = models
        synchronize()
        t0 = time.perf_counter()
        boxes, scores = predict_detector(detector, [image], conf=point["det_conf"], iou=point["nms_iou"], cfg=self.cfg)[0]
        synchronize()
        t1 = time.perf_counter()
        crops = crops_from_boxes(image, boxes, int(self.cfg["classification_dataset"]["margin_px"]))
        t2 = time.perf_counter()
        prob, preprocess, classifier_ms = _classify_timed(classifier, crops, norm, self.cfg)
        labels = (prob >= point["cls_threshold"]).astype(int)
        t3 = time.perf_counter()
        predictions = [{"box": b.tolist(), "score": float(s), "prob": float(p), "positive": bool(l)}
                       for b, s, p, l in zip(boxes, scores, prob, labels)]
        return predictions, {"detector_ms": (t1 - t0) * 1000, "crop_ms": (t2 - t1) * 1000,
                             "classifier_preprocess_ms": preprocess, "classifier_ms": classifier_ms,
                             "pipeline_ms": (t3 - t0) * 1000}


def stage_key(run_identity, name, *dependencies):
    return sha256_json([run_identity, name, *dependencies])
