"""Create a local thesis report from downloaded experiment ZIPs using only Python."""
from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import math
import os
import re
import shutil
import statistics
import tempfile
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath

PROJECT = Path(__file__).resolve().parents[1]
MODELS = {
    "yolov8n": "YOLOv8n", "yolov8l": "YOLOv8l", "yolo26l": "YOLO26l",
    "resnet50": "ResNet50", "vitb16": "ViT-B/16", "swintiny": "Swin-Tiny",
}
PAIRS = dict(zip("ABCDEF", (("YOLO26l", "ResNet50"), ("YOLO26l", "Swin-Tiny"),
                           ("YOLO26l", "ViT-B/16"), ("YOLOv8l", "ViT-B/16"),
                           ("YOLOv8l", "ResNet50"), ("YOLOv8l", "Swin-Tiny"))))
METRICS = {
    "precision": "Precision", "recall": "Recall", "f1": "F1", "f1score": "F1",
    "f2": "F2", "accuracy": "Accuracy", "ap": "AP", "averageprecision": "AP",
    "averageprecisionpositive": "AP positiva", "rocauc": "ROC-AUC", "map50": "mAP@0.5", "map05": "mAP@0.5",
    "map5095": "mAP@0.5:0.95", "map05095": "mAP@0.5:0.95", "map050095": "mAP@0.5:0.95",
    "tp": "TP", "fp": "FP", "fn": "FN", "edet": "Omisión por detección",
    "eclas": "Error de clasificación", "eflujo": "Fallo global",
    "positivetp": "TP positivos", "positivefp": "FP positivos", "positivefn": "FN positivos",
    "positivef1": "F1 positivo extremo a extremo", "positivef2": "F2 positivo extremo a extremo",
    "positiveprecision": "Precision positiva extremo a extremo",
    "positiverecall": "Recall positivo extremo a extremo",
    "effectivefps": "FPS efectivos", "fps": "FPS",
    "meanms": "Media (ms)", "medianms": "Mediana (ms)", "p95ms": "p95 (ms)",
    "mean": "Media", "median": "Mediana", "p95": "p95",
    "trainseconds": "Entrenamiento (s)", "gflops": "GFLOPs", "paramsm": "Parámetros (M)",
}
EXCLUDED = re.compile(r"rt[\W_]*detr|re(dtr)+", re.I)
HISTORICAL = re.compile(r"(?:^|[/_. -])(?:smoke|sintetico_demo|demo|fixture|historical|superseded|obsoleto)(?:[/_. -]|$)", re.I)
ARCHIVE_EXCLUDED = re.compile(r"botrytis_hibridos_a-f|botrytis_consolidado_tesis|consolidado_tesis", re.I)
HINT = re.compile(r"result|metric|metrica|summary|resumen|report|tabla|table|ap_per|confusion|latenc|timing|evalu|bench|master|sweep|threshold|freeze|eviden|final_meta|predict|detect|valid|compar|entren|dataset|split", re.I)
MAX_TABLE = 128 * 1024**2
IMAGES = {".png", ".jpg", ".jpeg", ".webp", ".svg", ".pdf"}


def plain(value):
    return "".join(c for c in unicodedata.normalize("NFKD", str(value).lower()) if c.isascii() and c.isalnum())


def display(value):
    return html.escape(str(value), quote=True)


def destination(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as temp:
        tmp = Path(temp.name)
        temp.write(data)
    try:
        os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def csv_bytes(rows, columns=None):
    columns = columns or list(dict.fromkeys(key for row in rows for key in row))
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, columns)
    writer.writeheader()
    for row in rows:
        writer.writerow({k: "'" + v if isinstance(v, str) and v.lstrip()[:1] in ("=", "+", "-", "@") else v
                         for k, v in row.items()})
    return stream.getvalue().encode("utf-8-sig")


def archive_path(name):
    normalized = name.replace("\\", "/")
    p = PurePosixPath(normalized)
    if p.is_absolute() or ".." in p.parts or ":" in normalized:
        return None
    return p


def number(value):
    if isinstance(value, bool):
        return None
    try:
        if isinstance(value, str):
            value = value.strip()
            percent = value.endswith("%")
            value = float(value.removesuffix("%").strip().replace(",", "."))
            if percent:
                value /= 100
        x = float(value)
    except (ValueError, TypeError):
        return None
    return x if math.isfinite(x) else None


def identity(row, source, fallback=""):
    by_key = {plain(k): str(v) for k, v in row.items() if isinstance(v, (str, int))}
    det, cls = (MODELS.get(plain(by_key.get(k, ""))) for k in ("detector", "classifier"))
    raw = next((by_key[k] for k in ("hybrid", "hibrido", "system", "sistema", "architecture", "arquitectura",
                                   "model", "modelo", "arch", "slug") if k in by_key), "")
    match = re.fullmatch(r"(?:h[ií]brido|sistema)?\s*([A-F])", raw, re.I)
    if match:
        return match[1].upper()
    explicit = next((code for code, pair in PAIRS.items() if (det, cls) == pair), None)
    if explicit:
        return explicit
    raw_compact = plain(raw)
    if raw_compact in MODELS:
        return MODELS[raw_compact]
    text = plain(raw + " " + source)
    located = [name for key, name in MODELS.items() if key in text]
    explicit = next((code for code, pair in PAIRS.items() if len(located) == 2 and set(pair) == set(located)), None)
    match = re.search(r"(?:^|[/_ -])(?:hybrid|h[ií]brido|sistema|test|point|video|mobile)[_ -]([A-F])(?:[/_. -]|$)", source, re.I)
    if match:
        return match[1].upper()
    return explicit or (located[0] if len(located) == 1 else fallback)


def stage_for(row, source, prior=""):
    keys = {plain(k): v for k, v in row.items()}
    context = " ".join(str(keys[k]) for k in ("split", "stage", "evaluatedon", "partition", "particion", "phase") if k in keys)
    inspect = (context or (source if not prior else "")).casefold()
    for label, pattern in (
        ("MÓVIL", r"mobile|móvil|deployment|despliegue|client_ms"),
        ("VIDEO", r"video|frame_timing"), ("TEST", r"test|prueba"),
        ("VAL", r"validation|validaci[oó]n|(^|[/_ -])val($|[/_ -])|threshold"),
        ("HPO", r"optuna|hpo|robust"), ("TRAIN", r"train|entren"),
    ):
        if re.search(pattern, inspect):
            return label
    return prior or "Sin etapa identificada"


def rejected(value):
    return bool(EXCLUDED.search(str(value)))


def scrub(value):
    if isinstance(value, list):
        return [scrub(item) for item in value if not explicit_excluded(item)]
    if isinstance(value, dict):
        return {k: scrub(v) for k, v in value.items() if not rejected(k) and not explicit_excluded(v)}
    return value


def explicit_excluded(item):
    if isinstance(item, str):
        return rejected(item)
    if isinstance(item, dict):
        return any(rejected(v) for k, v in item.items() if plain(k) in
                   ("model", "modelo", "slug", "architecture", "arquitectura", "detector", "classifier"))
    return False


def collect_json(value, source, metrics, matrices, model="", phase="", group="", fingerprint=""):
    if isinstance(value, list):
        for entry in value:
            if isinstance(entry, (dict, list)):
                collect_json(entry, source, metrics, matrices, model, phase, group, fingerprint)
        return
    if not isinstance(value, dict):
        return
    model = identity(value, "" if model else source, model)
    phase = stage_for(value, source, phase)
    fingerprint = identity_hash(value) or fingerprint
    for k, v in value.items():
        field = plain(k)
        label = METRICS.get(field)
        total = number(v)
        if model and label and total is not None:
            metrics.append({"modelo": model, "etapa": phase, "grupo": group, "métrica": label, "valor": total,
                            "origen": "archivo", "conjunto": fingerprint, "fuente": source})
        if field in ("confusionmatrix", "pipelineconfusionmatrix", "matrizconfusion") and matrix_data(v):
            rows = value.get("pipeline_confusion_rows")
            cols = value.get("pipeline_confusion_cols")
            matrices.append({"modelo": model or "Sin identificar", "etapa": phase, "grupo": group, "valores": v,
                             "filas": rows, "columnas": cols, "fuente": source, "conjunto": fingerprint})
        elif isinstance(v, (dict, list)):
            child = k.upper() if len(k) == 1 and k.upper() in PAIRS else MODELS.get(field, model)
            collect_json(v, source, metrics, matrices, child, phase, ".".join(filter(None, (group, k))), fingerprint)


def matrix_data(value):
    return isinstance(value, list) and 1 < len(value) <= 10 and all(
        isinstance(row, list) and len(row) == len(value) and all(number(v) is not None for v in row) for row in value)


def identity_hash(row):
    if row.get("dataset_hash") and row.get("split_hash"):
        return str(row["dataset_hash"]) + ":" + str(row["split_hash"])
    return ""


def read_csv(raw):
    text = raw.decode("utf-8-sig", errors="replace")
    try:
        dialect = csv.Sniffer().sniff(text[:8192], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    rows = []
    for row in reader:
        row.pop(None, None)
        if not explicit_excluded(row) and not any(rejected(v) for v in row.values() if v):
            rows.append(row)
    return rows, reader.fieldnames



def collect_timing(records, source, metrics):
    series = {}
    for row in records:
        model = identity(row, source)
        phase = stage_for(row, source)
        if not model or phase not in ("MÓVIL", "VIDEO", "TEST", "VAL"):
            continue
        for key, raw in row.items():
            unit = plain(key)
            elapsed = number(raw)
            if unit.endswith("ms") and elapsed is not None and elapsed >= 0:
                series.setdefault((model, phase, key, identity_hash(row)), []).append(elapsed)
    for (model, phase, key, fingerprint), values in series.items():
        values.sort()
        rank = (len(values)-1) * .95
        lo, hi = math.floor(rank), math.ceil(rank)
        p95 = values[lo] + (rank-lo) * (values[hi]-values[lo])
        for label, value in (("Media (ms)", statistics.fmean(values)), ("Mediana (ms)", statistics.median(values)), ("p95 (ms)", p95)):
            metrics.append({"modelo": model, "etapa": phase, "grupo": key, "métrica": label, "valor": value,
                            "origen": "archivo", "conjunto": fingerprint, "fuente": source})

def content_resource(folder, category, name, data):
    digest = hashlib.sha256(data).hexdigest()
    safe = re.sub(r"[^a-zA-Z0-9._-]", "_", PurePosixPath(name).name)[-76:]
    path = folder / category / f"{digest[:16]}-{safe}"
    if not path.is_file():
        destination(path, data)
    return path.relative_to(folder).as_posix()


def inventory_zip(archive, label, folder, scratch, inventory, metrics, matrices, warnings, depth=0):
    with zipfile.ZipFile(archive) as package:
        for entry in package.infolist():
            member = archive_path(entry.filename)
            if member is None:
                warnings.append(f"Ruta inválida omitida: {label} › {entry.filename}")
                continue
            if entry.is_dir() or rejected(member):
                continue
            suffix = member.suffix.lower()
            source = f"{label} › {member}"
            if suffix == ".zip" and depth < 5 and not ARCHIVE_EXCLUDED.search(member.name):
                try:
                    with tempfile.TemporaryFile(dir=scratch) as temp, package.open(entry) as src:
                        shutil.copyfileobj(src, temp, 1024 * 1024)
                        temp.seek(0)
                        inventory_zip(temp, source, folder, scratch, inventory, metrics, matrices, warnings, depth + 1)
                except (OSError, ValueError, zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
                    warnings.append(f"ZIP interno sin procesar: {source} ({exc})")
                continue
            row = {"fuente": source, "tipo": suffix, "bytes": entry.file_size, "copia": ""}
            if suffix in (".pt", ".pth", ".onnx", ".mp4", ".avi", ".mov", ".xlsx", ".db", ".sqlite", ".sqlite3", ".parquet", ".feather"):
                row["estado"] = "Inventariado en el ZIP; no se extrae para el informe"
                inventory.append(row)
                continue
            table = suffix in (".json", ".csv", ".tsv") and HINT.search(str(member))
            figure = suffix in IMAGES and (suffix in (".svg", ".pdf") or re.search(r"figur|gr[aá]fic|plot|confusi|matriz|curva|precision|compar|reports", str(member), re.I))
            if not (table or figure):
                continue
            if entry.file_size > MAX_TABLE:
                row["estado"] = "Inventariado; supera el límite de copia individual"
                inventory.append(row)
                continue
            try:
                content = package.read(entry)
                if table and suffix == ".json":
                    parsed = scrub(json.loads(content.decode("utf-8-sig")))
                    if not HISTORICAL.search(source):
                        collect_json(parsed, source, metrics, matrices)
                    content = (json.dumps(parsed, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
                elif table:
                    records, columns = read_csv(content)
                    if not HISTORICAL.search(source):
                        if any(plain(col) in ("frame", "frameindex", "fotograma", "imageid") for col in (columns or [])):
                            collect_timing(records, source, metrics)
                        else:
                            for record in records:
                                collect_json(record, source, metrics, matrices)
                    if not columns:
                        continue
                    content = csv_bytes(records, columns)
                # Source SVG files are kept as text so opening a link cannot run embedded scripts.
                name = member.name + ".txt" if suffix == ".svg" else member.name
                row["copia"] = content_resource(folder, "figuras_originales" if figure else "datos", name, content)
                row["estado"] = "Copiado"
                inventory.append(row)
            except (ValueError, OSError, RuntimeError, NotImplementedError, csv.Error, zipfile.BadZipFile) as exc:
                warnings.append(f"Artefacto sin procesar: {source} ({exc})")


def documented_results():
    history_path = PROJECT / "configs/hybrid_suite_history.json"
    history = json.loads(history_path.read_text(encoding="utf-8"))
    rows = []
    for code in "AB":
        for key, value in history[code].items():
            label = METRICS.get(plain(key))
            if key in ("f1", "f2", "precision", "recall"):
                label = f"{label} positivo extremo a extremo"
            if label and number(value) is not None:
                rows.append({"modelo": code, "etapa": "TEST", "grupo": "Tablas 6.3–6.4", "métrica": label, "valor": value,
                             "origen": "manuscrito", "conjunto": "32 imágenes, 208 frutos, 20 positivos", "fuente": history["source"]})
    return rows


def render_chart(title, rows):
    width, line = 850, 29
    height = 55 + line * len(rows)
    maximum = max([abs(r["valor"]) for r in rows] + [1e-9])
    shapes = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" role="img" aria-label="{display(title)}">',
              f'<rect width="{width}" height="{height}" fill="#f5f8fa"/>',
              f'<text x="15" y="24" font-size="16" font-family="sans-serif">{display(title)}</text>']
    for i, row in enumerate(rows):
        y = 38 + i * line
        value = row["valor"]
        label = row["modelo"] if row["modelo"] not in PAIRS else f'{row["modelo"]} · {" + ".join(PAIRS[row["modelo"]])}'
        filled = "#177e83" if row["origen"] == "archivo" else "#aa6b25"
        end = round(470 * abs(value) / maximum, 2)
        shapes += [f'<text x="15" y="{y+15}" font-family="sans-serif" font-size="13">{display(label)}</text>',
                   f'<rect x="252" y="{y}" width="{end}" height="17" rx="2" fill="{filled}"/>',
                   f'<text x="{257+end}" y="{y+14}" font-family="sans-serif" font-size="13">{value:.5g}</text>']
    return ("\n".join(shapes) + "</svg>").encode("utf-8")


def matrix_html(record):
    values = record["valores"]
    labels = [str(i) for i in range(len(values))]
    rows = record["filas"] if isinstance(record["filas"], list) and len(record["filas"]) == len(values) else labels
    cols = record["columnas"] if isinstance(record["columnas"], list) and len(record["columnas"]) == len(values) else labels
    top = max([abs(number(v)) for row in values for v in row] + [1])
    body = []
    for name, row in zip(rows, values):
        cells = "".join(f'<td style="background:#cfe9e9;box-shadow:inset 0 -{round(7*abs(number(v))/top)}px #23747b">{display(v)}</td>'
                        for v in row)
        body.append(f'<tr><th>{display(name)}</th>{cells}</tr>')
    headers = "".join(f"<th>{display(label)}</th>" for label in cols)
    return (f'<details><summary>{display(record["modelo"])} · {display(record["etapa"])} · {display(record["grupo"])}</summary>'
            f'<p>{display(record["fuente"])}</p><table><thead><tr><th>Real / Predicción</th>{headers}</tr></thead>'
            f'<tbody>{"".join(body)}</tbody></table></details>')


def consolidate(downloads, output, mode):
    output.mkdir(parents=True, exist_ok=True)
    archives = sorted((p for p in downloads.iterdir() if p.is_file() and p.suffix.lower() == ".zip"
                       and not ARCHIVE_EXCLUDED.search(p.name) and not rejected(p.name)), key=lambda p: p.name.casefold())
    inventory, artifacts, matrices, warnings, statuses = [], [], [], [], []
    with tempfile.TemporaryDirectory(prefix="archivos-", dir=output) as temp:
        for archive in archives:
            start = len(inventory)
            try:
                inventory_zip(archive, archive.name, output, Path(temp), inventory, artifacts, matrices, warnings)
                statuses.append({"ZIP": archive.name, "artefactos": len(inventory)-start, "estado": "Inspeccionado"})
            except (OSError, ValueError, zipfile.BadZipFile, RuntimeError, NotImplementedError) as exc:
                statuses.append({"ZIP": archive.name, "artefactos": 0, "estado": "No disponible o incompleto"})
                warnings.append(f"{archive.name}: {exc}")
    reference = documented_results()
    metrics = list({tuple(row.values()): row for row in [*artifacts, *reference]}.values())
    matrices = list({json.dumps(row, sort_keys=True, ensure_ascii=False): row for row in matrices}.values())
    destination(output / "inventario.csv", csv_bytes(inventory, ["fuente", "tipo", "bytes", "copia", "estado"]))
    destination(output / "archivos_zip.csv", csv_bytes(statuses, ["ZIP", "artefactos", "estado"]))
    destination(output / "metricas.csv", csv_bytes(metrics))
    destination(output / "matrices.json", (json.dumps(matrices, indent=2, ensure_ascii=False) + "\n").encode("utf-8"))
    groups = {}
    for row in metrics:
        if row["origen"] == "archivo" and not row["conjunto"]:
            # Two unrelated files can report the same metric for different runs.
            scope = row["fuente"]
        else:
            scope = row["conjunto"]
        key = (row["etapa"], row["grupo"], row["métrica"], row["origen"], scope)
        groups.setdefault(key, []).append(row)
    figures = []
    for (phase, group, metric, origin, scope), rows in sorted(groups.items()):
        by_model = {}
        for row in rows:
            by_model.setdefault(row["modelo"], {})[row["valor"]] = row
        if any(len(values) > 1 for values in by_model.values()) or not (2 <= len(by_model) <= 8):
            continue
        selected = [next(iter(values.values())) for _, values in sorted(by_model.items())]
        title = f"{phase} · {metric}" + (f" · {group}" if group else "")
        resource = content_resource(output, "graficos", "comparacion.svg", render_chart(title, selected))
        title_html = display(f"{title} · {origin}")
        figures.append(f'<figure><img src="{resource}" alt="{title_html}"><figcaption>{title_html}</figcaption>'
                       f'<p>{display(scope)}</p></figure>')
    experiment = output / "resultados_ejecucion" / "index.html"
    if not experiment.is_file():
        destination(experiment, ("<!doctype html><html lang='es'><meta charset='utf-8'><title>Evaluación de híbridos</title>"
                                  "<h1>Evaluación de híbridos A–F</h1><p>Aún no hay resultados sellados de la ejecución en esta PC.</p></html>").encode())
    experiment_link = '<p><a href="resultados_ejecucion/index.html">Evaluaciones, video y latencia de los híbridos A–F</a></p>'
    one_status = "Se encontraron ZIP en Descargas." if archives else "Aún no hay ZIP de evidencia en Descargas."
    issues = "".join(f"<li>{display(w)}</li>" for w in warnings) or "<li>Sin incidencias de lectura.</li>"
    matrices_body = "".join(map(matrix_html, matrices)) or "<p>Sin matrices verificables en los archivos leídos.</p>"
    sources = "".join(f'<li><a href="{display(r["copia"])}">{display(r["fuente"])}</a></li>'
                      for r in inventory if r["copia"].startswith("figuras_originales/"))
    report = f"""<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Consolidado de tesis</title><style>
body{{font:16px system-ui;background:#f7fafb;color:#14222c;margin:0 auto;max-width:1000px;padding:1.5rem}}
a{{color:#07626b}} figure,details{{background:white;border:1px solid #dce7ec;padding:1rem;margin:1rem 0}}
img{{width:100%}} th,td{{padding:.45rem .8rem}} p,li{{overflow-wrap:anywhere}}
</style></head><body><h1>Consolidado de tesis</h1>
<p>{one_status} {len(statuses)} ZIP inspeccionados o registrados · {len(artifacts)} valores de archivos · {len(reference)} valores documentados en el manuscrito.</p>
<p><a href="metricas.csv">Métricas</a> · <a href="inventario.csv">Inventario de artefactos</a> · <a href="archivos_zip.csv">Estado de los ZIP</a> · <a href="matrices.json">Matrices en JSON</a></p>
{experiment_link}
<p>La procedencia de cada cifra figura en el CSV. Las series ambiguas conservan sus valores en la tabla. Los valores del manuscrito tienen su propia serie.</p>
<h2>Gráficos comparativos</h2>{''.join(figures) or '<p>Sin series comparables.</p>'}
<h2>Matrices de confusión</h2>{matrices_body}
<h2>Figuras recuperadas</h2><ul>{sources or '<li>Sin figuras disponibles.</li>'}</ul>
<h2>Incidencias de lectura</h2><ul>{issues}</ul></body></html>"""
    destination(output / "index.html", report.encode("utf-8"))
    print(f"{mode}: {output / 'index.html'}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("Today", "Tomorrow"))
    parser.add_argument("--downloads", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if not args.downloads.is_dir():
        parser.error(f"No se encontró Descargas: {args.downloads}")
    consolidate(args.downloads, args.output, args.mode)


if __name__ == "__main__":
    main()
