"""Entry point for the supplemental six-hybrid experiment."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from hybrid_suite.runner import main

if __name__ == "__main__":
    raise SystemExit(main())
