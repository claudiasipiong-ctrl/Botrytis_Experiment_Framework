"""Verify handoff recovery and reuse of scientifically equivalent run state."""
from __future__ import annotations

from io import BytesIO
from types import SimpleNamespace
from zipfile import ZipFile

import pandas as pd
import pytest

from hybrid_suite.local_report import local_report
from hybrid_suite.recovery import recover_downloads
from hybrid_suite.runner import COMPATIBLE_CODE, active_experiment, session_config
from hybrid_suite.state import Pause, read, seal
from utils.config_loader import load_config
from utils.dataset import compute_dataset_hash
from utils.durable import atomic_json
from utils.hashing import compute_split_hash, sha256_json
from utils.semantics import semantic_fingerprint
from utils.splits import MANIFEST_COLUMNS, write_split_manifest


def test_archives_recover_sealed_dataset_from_separate_nested_zips(tmp_path):
    pictures, labels = [tmp_path / p for p in ("original-pictures", "original-labels")]
    pictures.mkdir()
    labels.mkdir()
    for iid in ("train-1", "val-1", "test-1"):
        (pictures / f"{iid}.jpg").write_bytes(("fixture bytes " + iid).encode())
        (labels / f"{iid}.txt").write_text("0 0.5 0.5 0.2 0.2\n", encoding="utf-8")
    cfg = load_config()
    cfg["paths"].update(raw_images_dir=str(pictures), raw_labels_dir=str(labels))
    digest, _ = compute_dataset_hash(cfg)
    metadata = tmp_path / "split"
    metadata.mkdir()
    atomic_json(metadata / "dataset_validation.json", {"passed": True, "dataset_hash": digest,
                                                      "semantic_fingerprint": semantic_fingerprint(cfg)})
    (metadata / "dataset_inventory.csv").write_text("image_id\ntrain-1\nval-1\ntest-1\n")
    assignment = [("train-1", "train"), ("val-1", "validation"), ("test-1", "test")]
    split_hash = compute_split_hash(assignment)
    df = pd.DataFrame([{**dict.fromkeys(MANIFEST_COLUMNS, ""), "image_id": i, "outer_split": s,
                        "split_hash": split_hash} for i, s in assignment])
    write_split_manifest(df, metadata)
    pack = BytesIO()
    with ZipFile(pack, "w") as archive:
        for file in metadata.iterdir():
            archive.write(file, f"artifacts/{file.name}")
        archive.writestr("src/do_not_run.py", "raise Exception('this file is not executed')")
        archive.writestr("../outside.json", "{}")
    downloads = tmp_path / "Downloads"
    downloads.mkdir()
    with ZipFile(downloads / "INVENTARIO_TECNICO_COMPLETO_TESIS.ZIP", "w") as archive:
        archive.writestr("runs/handoff-results.zip", pack.getvalue())
    with ZipFile(downloads / "datos.zip", "w") as archive:
        for path, prefix in ((pictures, "images"), (labels, "labels")):
            for file in path.iterdir():
                archive.write(file, f"dataset/{prefix}/{file.name}")

    recovery = tmp_path / "recovery"
    clock = SimpleNamespace(check=lambda: None)
    roots = recover_downloads(downloads, recovery, clock)
    (resolved, art, obtained, signed_split, manifest), _, _ = session_config(roots)
    assert (obtained, signed_split) == (digest, split_hash)
    assert manifest.loc[manifest["outer_split"].eq("test"), "image_id"].tolist() == ["test-1"]
    assert (art / "split_manifest.sha256").is_file()
    assert "recovery" in resolved["paths"]["raw_images_dir"]
    assert not list(recovery.rglob("*.py"))
    assert not (tmp_path / "outside.json").exists()
    assert recover_downloads(downloads, recovery, clock) == roots


def test_interrupted_import_reuses_completed_entries(tmp_path, monkeypatch):
    import hybrid_suite.recovery as recovery

    downloads = tmp_path / "Downloads"
    downloads.mkdir()
    with ZipFile(downloads / "runs.zip", "w") as archive:
        archive.writestr("dataset/images/a.jpg", b"first")
        archive.writestr("dataset/images/b.jpg", b"second")
    clock = SimpleNamespace(check=lambda: None)
    calls = []
    copy_entry = recovery.copy_entry

    def interrupt(package, entry, target, clock):
        calls.append(entry.filename)
        if len(calls) == 2:
            raise Pause()
        copy_entry(package, entry, target, clock)

    monkeypatch.setattr(recovery, "copy_entry", interrupt)
    with pytest.raises(Pause):
        recover_downloads(downloads, tmp_path / "cache", clock)
    roots = recover_downloads(downloads, tmp_path / "cache", clock)
    assert calls == ["dataset/images/a.jpg", "dataset/images/b.jpg", "dataset/images/b.jpg"]
    assert (roots[0] / "dataset/images/b.jpg").read_bytes() == b"second"


def test_prior_plan_is_reopened_when_data_and_runtime_still_match(tmp_path):
    current = {"code": "new", "dataset_hash": "data", "split_hash": "split", "method": {"match": .5}, "runtime": "gpu"}
    earlier = {**current, "code": COMPATIBLE_CODE[0]}
    folder = tmp_path / "experiments" / sha256_json(earlier)
    atomic_json(folder / "plan.json", {"identity": sha256_json(earlier)})
    assert active_experiment(tmp_path, current) == (earlier, folder)
    newer_data = {**current, "split_hash": "different"}
    assert active_experiment(tmp_path, newer_data)[0] == newer_data


def test_local_report_contains_sealed_evidence_and_does_not_copy_frames(tmp_path):
    work = tmp_path / "shared"
    folder = work / "tasks" / "test-C"
    atomic_json(folder / "summary.json", {"result": "fixture"})
    atomic_json(folder / "units" / "00.json", {"raw": "fixture"})
    seal(folder, "test", ["summary.json"])
    atomic_json(work / "tasks" / "test-D" / "summary.json", {"result": "not complete"})
    output = tmp_path / "Consolidado_Tesis" / "resultados_ejecucion"
    local_report(work, output, "PC-03")
    assert read(next(output.rglob("summary.json")))["result"] == "fixture"
    assert not list(output.rglob("00.json"))
    assert not list((output / "test-D").rglob("*"))


def test_restore_repairs_corrupt_sealed_evidence_but_keeps_new_task(tmp_path):
    from hybrid_suite.state import backup, restore

    roots = {"replicated_work": tmp_path / "work"}
    work = roots["replicated_work"]
    owner = {"pc": "PC-01"}
    task = work / "tasks" / "test-C"
    atomic_json(task / "summary.json", {"test": "validated"})
    seal(task, "test", ["summary.json"])
    home = tmp_path / "home"
    backup(home, roots, owner)
    atomic_json(task / "summary.json", {"test": "damaged"})
    other = work / "tasks" / "test-D"
    atomic_json(other / "summary.json", {"test": "completed since backup"})
    seal(other, "test", ["summary.json"])
    restore(home, roots, owner)
    assert read(task / "summary.json") == {"test": "validated"}
    assert read(other / "summary.json") == {"test": "completed since backup"}
