[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Today','Tomorrow')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$Downloads,
    [Parameter(Mandatory=$true)][string]$ProjectRoot
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$history = [ScriptBlock]::Create([IO.File]::ReadAllText((Join-Path $root 'scripts/Invoke-ConsolidadoTesis.ps1')))
$suite = [ScriptBlock]::Create([IO.File]::ReadAllText((Join-Path $root 'scripts/Invoke-HybridSuite.ps1')))
try {
    & $history -Mode $Mode -Downloads $Downloads -ProjectRoot $root
} catch {
    Write-Warning "Consolidación histórica pendiente: $($_.Exception.Message)"
}
& $suite -Mode $Mode -Downloads $Downloads -ProjectRoot $root
