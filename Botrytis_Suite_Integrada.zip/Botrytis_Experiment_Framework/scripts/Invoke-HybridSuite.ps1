﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Today','Tomorrow')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$Downloads,
    [Parameter(Mandatory=$true)][string]$ProjectRoot
)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path -LiteralPath $ProjectRoot).Path
$base = Join-Path $env:USERPROFILE 'Documents\s2_no_borrar'
$mapping = Get-Content -LiteralPath (Join-Path $root 'configs\fleet_mapping.json') -Raw | ConvertFrom-Json
$pc = @($mapping.PSObject.Properties | Where-Object { $_.Value -in @($env:USERNAME,$env:COMPUTERNAME) })
if ($pc.Count -ne 1) { throw 'Usuario/equipo no coincide inequívocamente con el mapa de la flota.' }
$homeRoot = Join-Path $base ('HybridSuite\' + $pc[0].Name)
$logDir = Join-Path $homeRoot 'logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
$log = Join-Path $logDir ('prepare-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmssffffZ') + '.log')
$env:PYTHONUTF8 = '1'
$env:PYTHONUNBUFFERED = '1'
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PIP_DISABLE_PIP_VERSION_CHECK = '1'
$env:YOLO_CONFIG_DIR = Join-Path $homeRoot 'ultralytics'
$env:CUBLAS_WORKSPACE_CONFIG = ':4096:8'
$env:MPLCONFIGDIR = Join-Path $homeRoot 'matplotlib'
$python = Join-Path $homeRoot 'venv-312-cu126\Scripts\python.exe'

function Invoke-Checked {
    param([string]$Executable, [string[]]$Arguments)
    & $Executable @Arguments
    if ($LASTEXITCODE -ne 0) { throw "Falló $Executable (código $LASTEXITCODE)." }
}

function Find-Python312 {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        $found = & $launcher.Source -3.12 -c 'import sys; print(sys.executable)' 2>$null
        if ($LASTEXITCODE -eq 0 -and $found) { return [string]($found | Select-Object -Last 1) }
    }
    $candidates = @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'),
        (Join-Path $env:ProgramFiles 'Python312\python.exe')
    )
    foreach ($path in $candidates) {
        if (Test-Path -LiteralPath $path -PathType Leaf) { return $path }
    }
    return $null
}

Start-Transcript -LiteralPath $log | Out-Null
try {
    $nvidia = Get-Command nvidia-smi.exe -ErrorAction SilentlyContinue
    if (-not $nvidia) { throw 'nvidia-smi.exe no está disponible. Se requiere un controlador NVIDIA funcional.' }
    $drivers = & $nvidia.Source --query-gpu=driver_version --format=csv,noheader
    if ($LASTEXITCODE -ne 0 -or -not $drivers) { throw 'No se pudo consultar la GPU NVIDIA.' }
    if ([version]([string]($drivers | Select-Object -First 1)).Trim() -lt [version]'560.76') {
        throw 'El controlador NVIDIA instalado no satisface CUDA 12.6.'
    }
    if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
        $systemPython = Find-Python312
        if (-not $systemPython) {
            $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
            if (-not $winget) { throw 'No hay Python 3.12 ni winget para instalarlo.' }
            Invoke-Checked $winget.Source @('install','--id','Python.Python.3.12','--exact','--scope','user','--silent','--disable-interactivity','--accept-package-agreements','--accept-source-agreements')
            $systemPython = Find-Python312
            if (-not $systemPython) { throw 'La instalación de Python 3.12 no dejó un ejecutable detectable.' }
        }
        Invoke-Checked $systemPython @('-m','venv',(Split-Path -Parent (Split-Path -Parent $python)))
    }
    Invoke-Checked $python @('-m','pip','install','--index-url','https://download.pytorch.org/whl/cu126','torch==2.14.1+cu126','torchvision==0.29.1+cu126')
    Invoke-Checked $python @('-m','pip','install','-r',(Join-Path $root 'requirements.txt'),'-r',(Join-Path $root 'requirements-dev.txt'))
    Invoke-Checked $python @('-m','pip','check')
    Invoke-Checked $python @('-c','import cv2, torch, torchvision; assert torch.cuda.is_available(), ''CUDA no disponible''; assert torch.version.cuda == ''12.6''; x=torch.ones(2, device=''cuda''); assert (x+x).sum().item() == 4; print(torch.cuda.get_device_name(0), cv2.__version__)')
} finally {
    Stop-Transcript | Out-Null
}
Push-Location -LiteralPath $root
try {
    Invoke-Checked $python @((Join-Path $root 'tools\run_hybrid_suite.py'),$Mode,'--downloads',$Downloads)
} finally {
    Pop-Location
}
