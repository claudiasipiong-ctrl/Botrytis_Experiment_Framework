﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateSet('Today','Tomorrow')][string]$Mode,
    [Parameter(Mandatory=$true)][string]$Downloads,
    [Parameter(Mandatory=$true)][string]$ProjectRoot
)
$ErrorActionPreference = 'Stop'
$env:PYTHONUTF8 = '1'
$env:PYTHONUNBUFFERED = '1'
function Find-ThesisPython {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        $path = & $launcher.Source -3 -c 'import sys; assert sys.version_info >= (3,10); print(sys.executable)' 2>$null
        if ($LASTEXITCODE -eq 0 -and $path) { return [string]($path | Select-Object -Last 1) }
    }
    foreach ($candidate in @((Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\python.exe'), (Join-Path $env:ProgramFiles 'Python312\python.exe'))) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    return $null
}
$python = Find-ThesisPython
if (-not $python) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) { throw 'No se halló Python 3.10+ ni winget para instalar Python 3.12.' }
    & $winget.Source install --id Python.Python.3.12 --exact --scope user --silent --disable-interactivity --accept-package-agreements --accept-source-agreements
    if ($LASTEXITCODE -ne 0) { throw 'Falló la instalación de Python.' }
    $python = Find-ThesisPython
    if (-not $python) { throw 'Python se instaló, pero no se detectó el ejecutable.' }
}
$output = Join-Path $env:USERPROFILE 'Documents\s2_no_borrar\Consolidado_Tesis'
& $python (Join-Path $ProjectRoot 'tools\consolidate_tesis.py') $Mode --downloads $Downloads --output $output
if ($LASTEXITCODE -ne 0) { throw "La consolidación falló (código $LASTEXITCODE)." }
