"""Recover data and evidence from local handoff archives without executing them."""
from __future__ import annotations

import logging
import os
import re
import stat
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from hybrid_suite.state import read
from utils.durable import atomic_json, filesystem_path, replace_file
from utils.hashing import sha256_file, sha256_json

RECOVERY_FORMAT = 1
SKIP_ARCHIVE = re.compile(r"botrytis_(?:hibridos_a-f|consolidado_tesis|suite_integrada)", re.I)
SKIP_PATH = re.compile(r"rt[\W_]*detr|[/\\](?:\.venv|__pycache__|demo|historical|superseded|smoke|previous_attempts)(?:[/\\]|$)", re.I)
ARTIFACT = re.compile(r"dataset_(?:validation|inventory)|split_(?:manifest|metadata)|test_lock|(?:inner_)?fold|image_manifest|"
                      r"quarantine_manifest|near_duplicate_review|freeze_manifest|test_results|final_meta|pipeline_validation|"
                      r"inference_thresholds|final_thresholds|outer_validation|checkpoints|comparison", re.I)
EVIDENCE = re.compile(r"metadata|metrics|pipeline_|timing|confusion|precision|recall|summary|matrices|ap_per_iou", re.I)
IMAGE = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}
TABLE = {".json", ".csv", ".tsv", ".sha256", ".yaml", ".yml", ".txt", ".log"}
WINDOWS_RESERVED = {"CON", "PRN", "AUX", "NUL", *(f"{p}{i}" for p in ("COM", "LPT") for i in range(1, 10))}


def zip_member(entry):
    name = entry.filename.replace("\\", "/")
    if entry.is_dir() or stat.S_ISLNK(entry.external_attr >> 16):
        return None
    parts = PurePosixPath(name).parts
    if not parts or name.startswith("/") or SKIP_PATH.search("/" + name):
        return None
    if any(p in (".", "..") or p != p.rstrip(" .") or re.search(r'[<>:"|?*\x00-\x1f]', p)
           or p.split(".")[0].upper() in WINDOWS_RESERVED for p in parts):
        return None
    return Path(*parts)


def evidence_member(path, final_metadata_dirs=()):
    parts = [x.casefold() for x in path.parts]
    suffix = path.suffix.casefold()
    if any(x in parts for x in ("derived", "derived_v4", "derived_v5", "crops", "detections")) and not EVIDENCE.search(path.name):
        return False
    if len(parts) >= 2 and parts[-2] in ("images", "imagenes", "imágenes"):
        return suffix in IMAGE
    if len(parts) >= 2 and parts[-2] in ("labels", "etiquetas"):
        return suffix == ".txt"
    if "configs" in parts:
        return path.name.casefold() in ("default.yaml", "local.yaml")
    if suffix in (".pt", ".pth"):
        return (path.name.casefold() == "final.pt" and "checkpoints" in parts
                or path.parent.as_posix().casefold() in final_metadata_dirs)
    if suffix in TABLE and ARTIFACT.search(path.as_posix()):
        return True
    if any(x in parts for x in ("runs", "reports", "results", "figures", "figuras", "graficos")):
        return suffix in IMAGE or suffix in TABLE and EVIDENCE.search(path.name)
    return False


def copy_entry(package, entry, target, clock):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, filename = tempfile.mkstemp(dir=target.parent, prefix=".unzip-", suffix=".importing")
    tmp = Path(filename)
    try:
        with os.fdopen(fd, "wb") as dst, package.open(entry) as src:
            while block := src.read(8 * 1024 * 1024):
                clock.check()
                dst.write(block)
            dst.flush()
            os.fsync(dst.fileno())
        replace_file(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)


def unpack_evidence(archive, target, clock, depth=0):
    """Keep each ZIP in its own namespace and use a separate tree for nested ZIPs."""
    target.mkdir(parents=True, exist_ok=True)
    files = {}
    old_receipt = target / ".recovering.json"
    if old_receipt.is_file():
        try:
            files.update(read(old_receipt))
        except (OSError, ValueError, TypeError):
            logging.warning("Recibo anterior ilegible; se comprobarán entradas desde el ZIP: %s", old_receipt)
    receipts = target / ".receipts"
    for record in receipts.glob("*.json"):
        try:
            item = read(record)
            files[item["path"]] = item["sha256"]
        except (OSError, ValueError, KeyError, TypeError):
            logging.warning("Recibo de archivo ilegible: %s", record)
    with zipfile.ZipFile(archive) as package:
        members = [(entry, zip_member(entry)) for entry in package.infolist()]
        final_metadata_dirs = {path.parent.as_posix().casefold() for _, path in members
                               if path and path.name.casefold() == "final_meta.json"}
        names = set()
        for entry, path in members:
            clock.check()
            if path is None:
                continue
            relative = path.as_posix()
            normalized = relative.casefold()
            if normalized in names:
                raise ValueError(f"Dos entradas tienen la misma ruta en Windows: {relative}")
            names.add(normalized)
            if path.suffix.casefold() == ".zip" and not SKIP_ARCHIVE.search(path.name):
                if depth >= 6:
                    logging.warning("ZIP interno fuera de alcance: %s", relative)
                    continue
                nested_name = "nested-" + sha256_json(relative)[:16]
                nested_target = target / nested_name
                if (nested_target / ".recovered.json").is_file():
                    continue
                with tempfile.TemporaryDirectory(prefix="zip-interno-", dir=target.parent) as temp:
                    nested_zip = Path(temp) / "archive.zip"
                    copy_entry(package, entry, nested_zip, clock)
                    unpack_evidence(nested_zip, nested_target, clock, depth + 1)
                continue
            if evidence_member(path, final_metadata_dirs):
                dest = target / path
                recorded = files.get(relative)
                if recorded and dest.is_file() and sha256_file(dest) == recorded:
                    continue
                copy_entry(package, entry, dest, clock)
                files[relative] = sha256_file(dest)
                atomic_json(receipts / f"{sha256_json(relative)[:24]}.json", {"path": relative, "sha256": files[relative]})
    atomic_json(target / ".recovered.json", {"format": RECOVERY_FORMAT, "files": files})


def recover_downloads(downloads, target, clock):
    target = filesystem_path(target)
    downloads = filesystem_path(downloads)
    target.mkdir(parents=True, exist_ok=True)
    imported = []
    for archive in sorted(downloads.iterdir(), key=lambda path: path.name.casefold()):
        if not archive.is_file() or archive.suffix.casefold() != ".zip" or SKIP_ARCHIVE.search(archive.name) or SKIP_PATH.search(archive.name):
            continue
        clock.check()
        stat_data = archive.stat()
        key = sha256_json([RECOVERY_FORMAT, archive.name, stat_data.st_size, stat_data.st_mtime_ns])[:20]
        directory = target / key
        try:
            if not (directory / ".recovered.json").is_file():
                unpack_evidence(archive, directory, clock)
                current = archive.stat()
                if (current.st_size, current.st_mtime_ns) != (stat_data.st_size, stat_data.st_mtime_ns):
                    (directory / ".recovered.json").unlink(missing_ok=True)
                    raise ValueError("El ZIP cambió mientras se leía.")
            imported.append(directory)
        except (OSError, ValueError, zipfile.BadZipFile) as exc:
            logging.warning("ZIP de Descargas pendiente: %s (%s)", archive.name, exc)
            print(f"ZIP de Descargas pendiente: {archive.name} ({exc})", flush=True)
    return imported


def evidence_trees(roots):
    """Find evidence in both a checkout (artifacts/v4) and a project sync export."""
    artifacts, raw, configs, runs = set(), set(), set(), set()
    for root in sorted(set(map(filesystem_path, roots))):
        if not root.is_dir():
            continue
        for directory, children, files in os.walk(root):
            folders = {child.casefold(): child for child in children}
            files = set(files)
            path = Path(directory)
            children[:] = [child for child in sorted(children) if not child.startswith((".", "tmp"))
                           and child not in ("derived_v4", "crops", "__pycache__", "HybridSuite", "Consolidado_Tesis", "previous_attempts")
                           and not (path / child).is_symlink()]
            if any(name == "dataset_validation.json" or name.startswith(("freeze_manifest", "test_results", "pipeline_validation")) for name in files):
                artifacts.add(path)
            if "final_meta.json" in files:
                artifacts.add(path)
                if path.parent.name == "checkpoints":
                    artifacts.add(path.parent.parent)
            if path.name == "inference_thresholds":
                artifacts.add(path.parent)
            if path.name == "runs":
                runs.add(path)
            if path.name == "configs":
                configs.update(path / filename for filename in ("local.yaml", "default.yaml") if filename in files)
            images = next((folders[k] for k in ("images", "imagenes", "imágenes") if k in folders), None)
            labels = next((folders[k] for k in ("labels", "etiquetas") if k in folders), None)
            if images and labels:
                image_path, label_path = path / images, path / labels
                if any(p.is_file() and p.suffix.casefold() in IMAGE for p in image_path.iterdir()):
                    raw.add((image_path, label_path))
                children[:] = [child for child in children if child not in (images, labels)]
    return sorted(artifacts), sorted(raw), sorted(configs), sorted(runs)
