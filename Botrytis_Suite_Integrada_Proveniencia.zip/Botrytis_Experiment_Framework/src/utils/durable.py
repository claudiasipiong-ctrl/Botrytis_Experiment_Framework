"""Escritura durable y exclusiones locales mediante locks del sistema operativo.

El descriptor se conserva: un proceso muerto libera el lock, sin carreras de PID files.
No coordina equipos desconectados; esa exclusividad se establece con propietarios.
"""
from __future__ import annotations
import json
import ntpath
import os
import shutil
import tempfile
import time
from pathlib import Path


def windows_extended_path(path: str) -> str:
    """Convert an absolute Windows path to the Win32 extended-length namespace."""
    if path.startswith(("\\\\?\\", "\\\\.\\")):
        return path
    normalized = ntpath.normpath(path)
    if normalized.startswith("\\\\"):
        return "\\\\?\\UNC\\" + normalized[2:]
    if ntpath.isabs(normalized) and len(normalized) > 1 and normalized[1] == ":":
        return "\\\\?\\" + normalized
    raise ValueError(f"Se requiere una ruta Windows absoluta: {path}")


def filesystem_path(path):
    """Use extended-length paths for Python filesystem operations on Windows."""
    return Path(windows_extended_path(os.path.abspath(path))) if os.name == "nt" else Path(path)


def replace_file(source, target):
    """Retry only Windows errors consistent with a transient open file."""
    for delay in (0.05, 0.1, 0.2, 0.4, 0.8, 1.0, None):
        try:
            os.replace(source, target)
            return
        except OSError as exc:
            if delay is None or getattr(exc, "winerror", None) not in (5, 32, 33):
                raise
            time.sleep(delay)

class FileLock:
    def __init__(self, path):
        self.path = filesystem_path(path)
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a+b")
        self.handle.seek(0, 2)
        if self.handle.tell() == 0:
            self.handle.write(b"\0")
            self.handle.flush()
        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.handle.close()
            self.handle = None
            raise RuntimeError(f"Bloqueo local ocupado: {self.path}")
        return self

    def __exit__(self, *exc):
        if self.handle:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None

def atomic_bytes(path, data):
    path = filesystem_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=path.parent, prefix=".write-", suffix=".partial")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        replace_file(temp, path)
    finally:
        Path(temp).unlink(missing_ok=True)

def atomic_json(path, data):
    atomic_bytes(path, (json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False, default=str) + "\n").encode("utf-8"))

def atomic_copy(src, dst):
    dst = filesystem_path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=dst.parent, prefix=".write-", suffix=".partial")
    try:
        with os.fdopen(fd, "wb") as out, filesystem_path(src).open("rb") as inp:
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fsync(out.fileno())
        replace_file(temp, dst)
    finally:
        Path(temp).unlink(missing_ok=True)

def atomic_torch_save(obj, path):
    import torch
    path = filesystem_path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(dir=path.parent, prefix=".write-", suffix=".partial")
    try:
        with os.fdopen(fd, "wb") as f:
            torch.save(obj, f)
            f.flush()
            os.fsync(f.fileno())
        replace_file(temp, path)
    finally:
        Path(temp).unlink(missing_ok=True)
