"""Identify TEST membership independently of historical score availability."""
from __future__ import annotations

import logging

from hybrid_suite.state import PAIRS, read, token
from utils.hashing import sha256_file, sha256_text, verify_checksum_file


TEST_PROOF_METHODS = frozenset({"historical_result_and_freeze", "historical_freeze", "archived_test_lock", "archived_split_metadata"})


def sealed_json(files, pattern):
    """Read archives with either of the supported checksum sidecar names."""
    for folder in files:
        for path in sorted(folder.glob(pattern)):
            try:
                sidecars = (path.with_suffix(".sha256"), path.with_name(path.name + ".sha256"))
                if not any(verify_checksum_file(path, sidecar) for sidecar in sidecars if sidecar.is_file()):
                    continue
                data = read(path)
                if isinstance(data, dict):
                    yield path, sha256_file(path), data
            except (OSError, TypeError, ValueError) as exc:
                logging.warning("Sello histórico ilegible: %s (%s)", path, exc)


def matching_partition(row, key):
    return isinstance(row, dict) and all(row.get(field) == key[field] for field in ("dataset_hash", "split_hash"))


def prior_freezes(artifacts, key, *, allow_missing_arch=False):
    """Accept only frozen historical hybrids from this validated partition."""
    for path, digest, row in sealed_json(artifacts, "freeze_manifest*.json"):
        try:
            pair = (row["detector"].get("architecture"), row["classifier"].get("architecture"))
            compatible = pair in PAIRS.values() or (allow_missing_arch and any(
                all(actual in (None, expected) for actual, expected in zip(pair, candidate)) for candidate in PAIRS.values()))
            if (compatible and matching_partition(row["data"], key)
                    and row.get("semantic_fingerprint") == key["semantics"]):
                yield path, digest, row
        except (AttributeError, TypeError, KeyError):
            logging.warning("Freeze histórico sin arquitectura o partición: %s", path)


def original_test_evidence(artifacts, key, data, cfg, history, prior):
    """Verify exact TEST IDs, with the archived lock as an independent source.

    The lock proves the original partition, not that the reported A/B scores
    were obtained using a particular checkpoint. Keep these claims separate.
    """
    test_ids = sorted(data.manifest.loc[data.manifest["outer_split"].eq("test"), "image_id"])
    membership = sha256_text("\n".join(test_ids) + "\n")
    identity = {"dataset_hash": key["dataset_hash"], "split_hash": key["split_hash"], "test_image_ids_sha256": membership}
    if prior:
        if any(row.get("test_image_ids_sha256") not in (None, membership) for row in prior.values()):
            return {**identity, "method": "pending", "reason": "El freeze histórico contradice los IDs de TEST recuperados."}
        return {**identity, "method": "historical_result_and_freeze", "verified_hybrids": sorted(prior)}

    for path, digest, frozen in prior_freezes(artifacts, key):
        recorded = frozen["data"].get("test_image_ids_sha256")
        if recorded == membership:
            return {**identity, "method": "historical_freeze", "archive_file": path.name,
                    "sha256": digest, "verified_hybrids": []}
        if recorded is not None:
            return {**identity, "method": "pending", "reason": "El freeze histórico contradice los IDs de TEST recuperados.",
                    "archive_file": path.name}

    observed = {}
    positive = cfg["classification_labels"]["positive_label"]
    for split in ("train", "validation", "test"):
        ids = data.manifest.loc[data.manifest["outer_split"].eq(split), "image_id"]
        fruits = data.fruits.loc[data.fruits["image_id"].isin(ids)]
        observed[split] = {"images": len(ids), "fruits": len(fruits), "positive_fruits": int(fruits["label"].eq(positive).sum())}
    if any(observed[split] != history[split] for split in observed):
        return {**identity, "method": "pending", "reason": "El dataset/split no reproduce los conteos del manuscrito.",
                "observed": observed}

    # The lock was archived by the original split step, before evaluation.
    verified_locks = []
    for folder in artifacts:
        for path in sorted(folder.glob("test_lock*.json")):
            try:
                lock = read(path)
                if not matching_partition(lock, key):
                    continue
                if (lock.get("locked") is not True or token(lock.get("test_image_ids_sha256")) != membership
                        or lock.get("n_test_images") != len(test_ids)):
                    return {**identity, "method": "pending", "reason": "El bloqueo histórico existente contradice los IDs o el conteo de TEST.",
                            "archive_file": path.name, "observed": observed}
                verified_locks.append(path)
            except (OSError, ValueError, TypeError):
                logging.warning("Bloqueo TEST histórico ilegible: %s", path)
    if verified_locks:
        path = verified_locks[0]
        return {**identity, "method": "archived_test_lock", "archive_file": path.name,
                "sha256": sha256_file(path), "verified_hybrids": [], "observed": observed}

    # The original split metadata also seals the complete assignment file.
    manifest_file = data.artifacts_dir / cfg["outer_split"]["manifest_name"]
    if verify_checksum_file(manifest_file, manifest_file.with_suffix(".sha256")):
        manifest_digest = sha256_file(manifest_file)
        counts = {split: value["images"] for split, value in observed.items()}
        for folder in artifacts:
            for path in sorted(folder.glob("split_metadata*.json")):
                try:
                    meta = read(path)
                    if (matching_partition(meta, key) and meta.get("semantic_fingerprint") == key["semantics"]
                            and meta.get("manifest_sha256") == manifest_digest
                            and meta.get("seed") == cfg["outer_split"]["seed"] and meta.get("counts") == counts):
                        return {**identity, "method": "archived_split_metadata", "archive_file": path.name,
                                "sha256": sha256_file(path), "manifest_sha256": manifest_digest,
                                "verified_hybrids": [], "observed": observed}
                except (OSError, ValueError, TypeError):
                    logging.warning("Metadatos de split histórico ilegibles: %s", path)
    return {**identity, "method": "pending",
            "reason": "Falta un freeze sellado, test_lock.json o metadatos históricos con el SHA-256 del split original.",
            "observed": observed}
