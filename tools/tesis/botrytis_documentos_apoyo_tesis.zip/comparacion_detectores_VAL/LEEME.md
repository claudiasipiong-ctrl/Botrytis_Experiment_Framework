# Comparacion de detectores sobre VAL

Datos: 65 imagenes, 449 frutos, de los cuales 37 con_signos. Solo se procesaron filas VAL del manifiesto GT y las predicciones VAL. TEST no fue evaluado ni utilizado.

Se recalculo el matching greedy por confianza, estable y uno a uno, IoU >= 0.50 usando utils.metrics.match_detections del commit b706f176. Las asignaciones y etiquetas TP/FP coinciden con las predicciones aportadas. Los 41 puntos de cada curva guardada reproducen exactamente TP/FP/FN y P/R/F1. Dataset, split y huella semantica coinciden entre los tres modelos.

La tabla principal usa el umbral que maximiza F2 de deteccion de TODOS los frutos en los 41 puntos YA GUARDADOS de cada modelo (empate: mayor confianza). Esto es analisis exploratorio posterior a VAL: NO es el paso11 oficial; NO se repitio inferencia, NO se ajusto NMS, NO se modifico config o politica, NO se registro un ganador. Los barridos adicionales del CSV completo siguen usando las mismas cajas guardadas.

mAP50-95 y mAP50 vienen de Ultralytics en metrics.json. TP/FP/FN/P/R/F1/F2 son conteos independientes recalculados al umbral indicado. No intercambiar estas P/R con las estadisticas de Ultralytics al maximo F1.

F2 = 5TP/(5TP+4FN+FP). FN_con_signos_detector cuenta frutos GT con signos sin deteccion valida; NO incluye errores posteriores del clasificador. Recall positivo de 37/37 en estos puntos de VAL no garantiza 100% en datos nuevos o en el sistema hibrido. Las etiquetas corresponden a signos, no confirmacion de infeccion por laboratorio.

GFLOPs y parametros son costo teorico registrado. La VRAM y tiempo de entrenamiento son SOLO del entrenamiento final; no incluyen baseline/HPO/robustez y no sustituyen latencia o VRAM de inferencia. Los entrenamientos usaron distintas epocas/PC. Faltan benchmark comparable de inferencia y validacion hibrida con predicted crops para una decision de despliegue completa.

Regla original: max mAP50-95; empate <=0.005, mayor recall y luego menores GFLOPs. Recomendacion con prioridad global de omisiones y regla original: YOLOv8l. Alternativa de menor costo teorico y F2 proximo: YOLO26l. No se atribuye significacion estadistica a diferencias pequenas. Documentar RT-DETR como excluido por HPO incompleto/costo; no asignarle resultados.

comparacion.json conserva metricas recibidas, hashes ZIP, verificacion y diferentes puntos operativos. barrido_confianza.csv permite auditar cambios por confianza. tabla_comparativa_F2.csv es la tabla sintetica.
