from pathlib import Path
import csv,io,json,zipfile,hashlib
import numpy as np
from utils.metrics import match_detections
OUT=Path(__file__).parent
SRC=[('/workspace/attachments/e94301df-1de9-4e04-bb90-ea6420ddf04d/PC1.zip','PC1/yolo8n/'),('/workspace/attachments/e94301df-1de9-4e04-bb90-ea6420ddf04d/PC1.zip','PC1/yolo8l/'),('/workspace/attachments/0e2cdf2d-6fb7-424d-a49f-7aca0e50fcb0/PC2.zip','yolo26l/')]
def read(z,n):return list(csv.DictReader(io.StringIO(z.read(n).decode('utf-8-sig'))))
with zipfile.ZipFile(SRC[2][0]) as z:
 ids={r['image_id'] for r in read(z,'yolo26l/split_images.csv')}
 gt=[r for r in read(z,'yolo26l/classification_manifest.csv') if r['image_id'] in ids and r['outer_split']=='validation']
assert len(ids)==65 and len(gt)==449
G={iid:sorted([r for r in gt if r['image_id']==iid],key=lambda r:int(r['fruit_id'])) for iid in ids}
pos={(iid,i) for iid in ids for i,r in enumerate(G[iid]) if r['label']=='con_signos'}
assert len(pos)==37
rows=[];summaries=[];evidence=[];missed=[]
for path,pre in SRC:
 with zipfile.ZipFile(path) as z:
  m=json.loads(z.read(pre+'metrics.json'));slug=m['slug'];pred=read(z,pre+'predictions.csv');curve=read(z,pre+'confidence_curves.csv')
  assert {r['image_id'] for r in read(z,pre+'split_images.csv')}==ids
  assert all(r['split']=='validation' for r in pred)
  assert m['n_val_boxes']==len(gt) and m['n_val_images']==len(ids)
  PP={iid:[r for r in pred if r['image_id']==iid] for iid in ids};matches=[];all_scores=[]
  for iid,pr in PP.items():
   boxes=np.array([[float(r[k]) for k in ('x1','y1','x2','y2')] for r in pr]);scores=np.array([float(r['confidence']) for r in pr]);gb=np.array([[float(r[k]) for k in ('x1','y1','x2','y2')] for r in G[iid]]).reshape(-1,4)
   result=match_detections(boxes,scores,gb,.5)
   actual={pi:gi for pi,gi,iou in result['matches']}
   assert all((pi in actual)==(r['outcome_iou50']=='TP') for pi,r in enumerate(pr))
   assert all(actual[pi]==int(pr[pi]['gt_index']) for pi in actual)
   matches += [(float(pr[pi]['confidence']),iid,gi) for pi,gi in actual.items()];all_scores.extend(scores)
  modelrows=[]
  grid=sorted(set([float(r['conf']) for r in curve]+[.01,.02,.05,.1,.15,.2,.25,.3,.35,.4,.45,.5,.6,.7]))
  for conf in grid:
   hit={(iid,gi) for score,iid,gi in matches if score>=conf};tp=len(hit);fp=int(sum(s>=conf for s in all_scores))-tp;fn=len(gt)-tp
   p=tp/(tp+fp) if tp+fp else 0;r=tp/len(gt);f1=2*tp/(2*tp+fp+fn) if tp else 0;f2=5*tp/(5*tp+4*fn+fp) if tp else 0
   row=dict(model=slug,conf=conf,tp=tp,fp=fp,fn=fn,precision=p,recall=r,f1=f1,f2=f2,fn_positive=len(pos-hit),recall_positive=(len(pos&hit)/len(pos)),fp_per_image=fp/len(ids))
   modelrows.append(row)
  for ref in curve:
   row=next(r for r in modelrows if r['conf']==float(ref['conf']))
   for k in ['tp','fp','fn']:assert row[k]==int(ref[k]),(slug,k,row,ref)
   for k in ['precision','recall','f1']:assert abs(row[k]-float(ref[k]))<1e-10
  rows.extend(modelrows)
  selected={}
  originalgrid=[r for r in modelrows if r['conf'] in [float(c['conf']) for c in curve]]
  for metric in ['f1','f2']:
   selected['best_'+metric]=max(originalgrid,key=lambda r:(r[metric],r['conf']))
  eligible=[r for r in originalgrid if r['fn_positive']==0]
  selected['zero_positive_fn_min_fp']=min(eligible,key=lambda r:(r['fp'],-r['conf'])) if eligible else None
  selected['conf_025']=next(r for r in modelrows if r['conf']==.25)
  selected['conf_050']=next(r for r in modelrows if r['conf']==.5)
  for role,row in selected.items():
   if row:
    hit={(iid,gi) for score,iid,gi in matches if score>=row['conf']}
    for iid,gi in pos-hit:missed.append(dict(model=slug,role=role,conf=row['conf'],image_id=iid,fruit_id=G[iid][gi]['fruit_id'],label='con_signos'))
  summaries.append(dict(model=slug,metrics=m,operating_points=selected))
  evidence.append(dict(zip=Path(path).name,zip_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),prefix=pre,recomputed_matches_agree_with_saved_predictions=True,all_41_saved_curve_rows_reproduced=True))
print(json.dumps([{'model':s['model'],'operating_points':s['operating_points']} for s in summaries],indent=2))
for name,data in [('barrido_confianza',rows),('omisiones_positivas',missed)]:
 if data:
  with (OUT/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(OUT/'comparacion.json').write_text(json.dumps(dict(n_val_images=65,n_gt=449,n_positive_gt=37,matching_iou=.5,scope='VAL only; post-hoc descriptive confidence analysis with existing NMS. No official tuning, selection or TEST executed.',evidence=evidence,models=summaries),indent=2)+'\n')
