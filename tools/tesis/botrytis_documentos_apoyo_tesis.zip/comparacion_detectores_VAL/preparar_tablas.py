from pathlib import Path
import json,csv
OUT=Path(__file__).parent
d=json.loads((OUT/'comparacion.json').read_text())
assert len({s['metrics']['dataset_hash'] for s in d['models']})==1
assert len({s['metrics']['split_hash'] for s in d['models']})==1
assert len({s['metrics']['semantic_fingerprint'] for s in d['models']})==1
rows=[]
for s in d['models']:
 m=s['metrics'];r=s['operating_points']['best_f2']
 rows.append(dict(modelo=m['architecture'],map50_95_VAL=m['map50_95'],map50_VAL=m['map50'],parametros_M=m['params_m'],GFLOPs=m['gflops'],conf_exploratoria_F2=r['conf'],TP=r['tp'],FP=r['fp'],FN=r['fn'],precision=r['precision'],recall=r['recall'],F1=r['f1'],F2=r['f2'],FP_por_imagen=r['fp_per_image'],FN_con_signos_detector=r['fn_positive'],recall_con_signos_detector=r['recall_positive'],VRAM_entrenamiento_pico_MiB=m['vram_train_peak_mb'],segundos_entrenamiento_final=m['train_seconds'],epocas_finales=m['final_epochs'],latencia_ms='NO_MEDIDA_EN_ARCHIVOS_RECIBIDOS',VRAM_inferencia='NO_MEDIDA_EN_ARCHIVOS_RECIBIDOS'))
with (OUT/'tabla_comparativa_F2.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
text='''# Comparacion de detectores sobre VAL

Datos: 65 imagenes, 449 frutos, de los cuales 37 con_signos. Solo se procesaron filas VAL del manifiesto GT y las predicciones VAL. TEST no fue evaluado ni utilizado.

Se recalculo el matching greedy por confianza, estable y uno a uno, IoU >= 0.50 usando utils.metrics.match_detections del commit b706f176. Las asignaciones y etiquetas TP/FP coinciden con las predicciones aportadas. Los 41 puntos de cada curva guardada reproducen exactamente TP/FP/FN y P/R/F1. Dataset, split y huella semantica coinciden entre los tres modelos.

La tabla principal usa el umbral que maximiza F2 de deteccion de TODOS los frutos en los 41 puntos YA GUARDADOS de cada modelo (empate: mayor confianza). Esto es analisis exploratorio posterior a VAL: NO es el paso11 oficial; NO se repitio inferencia, NO se ajusto NMS, NO se modifico config o politica, NO se registro un ganador. Los barridos adicionales del CSV completo siguen usando las mismas cajas guardadas.

mAP50-95 y mAP50 vienen de Ultralytics en metrics.json. TP/FP/FN/P/R/F1/F2 son conteos independientes recalculados al umbral indicado. No intercambiar estas P/R con las estadisticas de Ultralytics al maximo F1.

F2 = 5TP/(5TP+4FN+FP). FN_con_signos_detector cuenta frutos GT con signos sin deteccion valida; NO incluye errores posteriores del clasificador. Recall positivo de 37/37 en estos puntos de VAL no garantiza 100% en datos nuevos o en el sistema hibrido. Las etiquetas corresponden a signos, no confirmacion de infeccion por laboratorio.

GFLOPs y parametros son costo teorico registrado. La VRAM y tiempo de entrenamiento son SOLO del entrenamiento final; no incluyen baseline/HPO/robustez y no sustituyen latencia o VRAM de inferencia. Los entrenamientos usaron distintas epocas/PC. Faltan benchmark comparable de inferencia y validacion hibrida con predicted crops para una decision de despliegue completa.

Regla original: max mAP50-95; empate <=0.005, mayor recall y luego menores GFLOPs. Recomendacion de equilibrio exploratoria: YOLO26l. Regla original y prioridad global de omisiones: YOLOv8l debe mantenerse como alternativa. No se atribuye significacion estadistica a diferencias pequenas. Documentar RT-DETR como excluido por HPO incompleto/costo; no asignarle resultados.

comparacion.json conserva metricas recibidas, hashes ZIP, verificacion y diferentes puntos operativos. barrido_confianza.csv permite auditar cambios por confianza. tabla_comparativa_F2.csv es la tabla sintetica.
'''
(OUT/'LEEME.md').write_text(text,encoding='utf-8')
print('TABLA')
for row in rows:print(row)
try:
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 fig,axes=plt.subplots(1,2,figsize=(11,4.3))
 for s in d['models']:
  m=s['metrics'];r=s['operating_points']['best_f2'];label=m['architecture']
  axes[0].scatter(m['gflops'],m['map50_95'],s=65)
  axes[0].annotate(label,(m['gflops'],m['map50_95']),xytext=(5,-15),textcoords='offset points')
  axes[1].scatter(r['fp'],r['fn'],s=65)
  axes[1].annotate(label,(r['fp'],r['fn']),xytext=(5,5),textcoords='offset points')
 axes[0].set(xlabel='GFLOPs registrados',ylabel='mAP50-95 VAL (Ultralytics)',title='Rendimiento y costo teorico')
 axes[1].set(xlabel='Falsos positivos (frutos)',ylabel='Falsos negativos (frutos)',title='Mejor F2 del barrido guardado | IoU 0.50')
 for ax in axes:ax.margins(.25);ax.grid(alpha=.25)
 fig.suptitle('VAL: 65 imagenes, 449 frutos | Analisis exploratorio, sin TEST',fontsize=11)
 fig.tight_layout()
 for ext in ['png','pdf','svg']:fig.savefig(OUT/('comparacion_detectores.'+ext),dpi=170)
 print('FIGURAS creadas')
except ImportError as exc:print('Sin figuras',exc)
