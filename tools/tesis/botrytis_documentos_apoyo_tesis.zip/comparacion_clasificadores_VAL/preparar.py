from pathlib import Path
import json,csv,zipfile
OUT=Path(__file__).parent
d=json.loads((OUT/'resultados.json').read_text())
readme='''# Comparacion de clasificadores - VAL, 2026-11-05

Verificados: mismos 449 pares (image_id, fruit_id) con etiquetas identicas, 37 positivos con_signos y 412 negativos sin_signos, 58 imagenes con crops dentro del split VAL de 65 imagenes. Misma huella de dataset, split, semantica, codigo y entorno. Se comprobaron SHA256 de predicciones y se reprodujeron las matrices de confusion, precision/recall/F1/F2/accuracy a umbral 0.5. Solo se usaron predicciones de validation. No se uso TEST ni se ejecutaron modelos.

Los valores AP y ROC-AUC oficiales se conservan de metrics.json; las probabilidades CSV guardadas tienen 8 decimales. La prediccion positiva usa p_con_signos >= umbral. FN: con_signos clasificado sin_signos; FP: sin_signos clasificado con_signos. Signos no equivale a infeccion confirmada por laboratorio.

Tablas: tabla_umbral_05.csv (rendimiento y conteos actuales), tabla_costo_teorico.csv (parametros/GFLOPs y datos de entrenamiento final), tabla_umbrales_exploratorios.csv (F1, F2, cero FN en VAL), barrido_101_umbrales.csv (todos los puntos), casos_FP_FN.csv (casos auditables).

Analisis adicional de umbrales: rejilla preexistente de 101 puntos [0,1] (paso 0.01), funciones originales threshold_sweep/pick_threshold. Para maximo F1/F2 se usa la mediana de los umbrales empatados, que puede caer entre dos puntos; sus conteos se recalculan. El criterio de cero FN usa el menor numero de FP y luego mayor umbral dentro de la rejilla. Es un analisis exploratorio sobre la misma VAL, no una evaluacion independiente ni el registro oficial del paso11. No se alteran config.yaml, politica ni artefactos del framework. F2=5TP/(5TP+4FN+FP).

Cero FN solo describe los 37 positivos observados, no garantiza recall 100% en datos nuevos. Las diferencias de 1-2 casos no acreditan significacion estadistica; las muestras comparten imagenes. Maximizar F2 no implica cero FN. Estos son GT crops: aun falta evaluar el clasificador sobre crops predichos por YOLO26l y los FN del sistema integrado.

Parametros/GFLOPs: costo teorico registrado por recorte; no son latencia ni energia. VRAM y tiempos: SOLO entrenamiento final, distintas epocas y PCs, no son consumo de inferencia ni costo total HPO/robustez.

Recomendacion de clasificador: ViT-B/16 por mejor AP/F2 y menos FP manteniendo el recall alto observado. Tiene mayor costo teorico. No se registra automaticamente esta recomendacion; YOLO26l sigue siendo el detector elegido por el usuario. El umbral final debe quedar documentado y comprobarse en el pipeline integrado antes de freeze/TEST.
'''
(OUT/'LEEME.md').write_text(readme,encoding='utf-8')
# Spreadsheet if the installed optional library is present.
try:
 from openpyxl import Workbook
 from openpyxl.styles import Font,PatternFill
 wb=Workbook();wb.remove(wb.active)
 for name in ['tabla_umbral_05','tabla_costo_teorico','tabla_umbrales_exploratorios','barrido_101_umbrales','casos_FP_FN']:
  ws=wb.create_sheet(name[:31]);rows=list(csv.reader((OUT/(name+'.csv')).open(encoding='utf-8-sig')))
  for row in rows:
   parsed=[]
   for value in row:
    try:parsed.append(float(value) if '.' in value or 'e-' in value else int(value))
    except ValueError:parsed.append(value)
   ws.append(parsed)
  ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
  for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='205072')
  for col in ws.columns:ws.column_dimensions[col[0].column_letter].width=min(38,max(12,max(len(str(c.value or '')) for c in col)+2))
 wb.save(OUT/'comparacion_clasificadores.xlsx')
 print('XLSX creado')
except ImportError:print('XLSX no disponible; CSV completos generados')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,3,figsize=(11,3.6))
for ax,m in zip(axes,d['original_metrics']):
 cm=m['confusion_matrix'];ax.imshow(cm,cmap='Blues',vmin=0,vmax=412)
 for i in range(2):
  for j in range(2):ax.text(j,i,str(cm[i][j]),ha='center',va='center',fontsize=16,color='white' if cm[i][j]>200 else 'black')
 ax.set(xticks=[0,1],yticks=[0,1],xticklabels=['Sin signos','Con signos'],yticklabels=['Sin signos','Con signos'],xlabel='Prediccion',ylabel='Etiqueta GT',title=m['architecture'])
fig.suptitle('VAL: 449 recortes GT | Umbral 0.5 | Filas: GT, columnas: prediccion',fontsize=11)
fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(OUT/('matrices_confusion_05.'+ext),dpi=180)
plt.close(fig)
with zipfile.ZipFile(OUT.parent/'comparacion_clasificadores_VAL.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in OUT.iterdir():
  if p.is_file():z.write(p,p.name)
print(OUT.parent/'comparacion_clasificadores_VAL.zip')
