from pathlib import Path
import zipfile,json,csv,io,hashlib
import numpy as np
from utils.metrics import binary_classification_report
from utils.metrics_classification import threshold_sweep,pick_threshold
OUT=Path(__file__).parent
SOURCES=[('/workspace/attachments/5a573a8e-5c42-4f77-b7a8-c8411c19be75/ResNet50_VAL.zip','ResNet50_VAL/'),('/workspace/attachments/83b05ebc-03f4-4781-85f1-0f29fcc3cba0/SwinTiny_VAL.zip','SwinTiny_VAL/'),('/workspace/attachments/1168b2b7-7ee5-485a-8825-c467314baa33/ViT_B16_VAL.zip','ViT_B16_VAL/')]
baseline=[];cost=[];points=[];all_sweeps=[];cases=[];ref=None;meta=[];proof=[]
def clean(v):
 if isinstance(v,np.generic):return v.item()
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
 if isinstance(v,list):return [clean(x) for x in v]
 return v
for path,pre in SOURCES:
 with zipfile.ZipFile(path) as z:
  m=json.loads(z.read(pre+'metrics.json'));raw=z.read(pre+'validation_predictions.csv');data=list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))));slug=m['slug']
  assert hashlib.sha256(raw).hexdigest()==m['predictions_sha256']
  keys={(r['image_id'],int(r['fruit_id'])):int(r['y_true']) for r in data}
  assert len(keys)==len(data)==449 and sum(keys.values())==37
  if ref is None:ref=keys
  else:assert keys==ref
  assert all(r['crop_path'].startswith('validation/') for r in data)
  y=np.array([int(r['y_true']) for r in data]);p=np.array([float(r['p_con_signos']) for r in data]);assert np.isfinite(p).all() and ((p>=0)&(p<=1)).all()
  rep=binary_classification_report(y,p,threshold=.5)
  assert rep['confusion_matrix']==m['confusion_matrix']
  for k in ['precision','recall','f1','f2','accuracy']:assert abs(rep[k]-m[k])<1e-10
  row=dict(modelo=m['architecture'],AP_con_signos=m['average_precision_positive'],ROC_AUC=m['roc_auc'],umbral=.5,TP=rep['tp'],TN=rep['tn'],FP=rep['fp'],FN=rep['fn'],precision=rep['precision'],recall=rep['recall'],F1=rep['f1'],F2=rep['f2'],accuracy=rep['accuracy'])
  baseline.append(row)
  cost.append(dict(modelo=m['architecture'],parametros_M=m['params_m'],GFLOPs=m['gflops'],VRAM_pico_entrenamiento_MiB=m['vram_train_peak_mb'],tiempo_entrenamiento_final_seg=m['train_seconds'],epocas_finales=m['final_epochs'],latencia='NO_INCLUIDA_EN_ARCHIVOS',precision_inferencia='Consultar config de la ronda'))
  sw=threshold_sweep(y,p,n_points=101);sw.insert(0,'model',slug);all_sweeps.extend(sw.to_dict('records'))
  selected={}
  for metric in ['f1','f2']:
   t,_=pick_threshold(sw,metric);selected['max_'+metric]=float(t)
  eligible=sw[sw['fn']==0];t=float(eligible.sort_values(['fp','threshold'],ascending=[True,False]).iloc[0]['threshold']);selected['cero_FN_en_VAL_min_FP']=t
  for criterion,t in selected.items():
   a=binary_classification_report(y,p,threshold=t)
   points.append(dict(modelo=m['architecture'],criterio=criterion,umbral=t,TP=a['tp'],TN=a['tn'],FP=a['fp'],FN=a['fn'],precision=a['precision'],recall=a['recall'],F1=a['f1'],F2=a['f2']))
  for criterion,t in {'inicial_0.5':.5,**selected}.items():
   for r,yy,pp in zip(data,y,p):
    if int(pp>=t)!=yy:cases.append(dict(modelo=slug,criterio=criterion,umbral=t,image_id=r['image_id'],fruit_id=r['fruit_id'],y_true=int(yy),probabilidad=float(pp),error='FN' if yy==1 else 'FP'))
  meta.append(m);proof.append(dict(zip=Path(path).name,zip_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest(),predictions_sha256_verified=True,n=449,positive=37,confusion_matrix_and_metrics_0_5_verified=True))
assert all(len({m[k] for m in meta})==1 for k in ['dataset_hash','split_hash','code_hash','semantic_fingerprint','environment_hash'])
for name,rows in [('tabla_umbral_05',baseline),('tabla_costo_teorico',cost),('tabla_umbrales_exploratorios',points),('barrido_101_umbrales',all_sweeps),('casos_FP_FN',cases)]:
 with (OUT/(name+'.csv')).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
result=clean(dict(verified=proof,same_keys_and_labels=True,n_gt_crops=449,n_positive=37,n_negative=412,n_images_with_crops=len({k[0] for k in ref}),baseline=baseline,cost=cost,exploratory_points=points,original_metrics=meta))
(OUT/'resultados.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(clean(dict(baseline=baseline,cost=cost,points=points)),ensure_ascii=False,indent=2))
