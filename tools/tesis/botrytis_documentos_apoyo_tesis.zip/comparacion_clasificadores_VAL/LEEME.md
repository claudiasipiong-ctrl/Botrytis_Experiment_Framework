# Comparacion de clasificadores - VAL, 2026-11-05

Verificados: mismos 449 pares (image_id, fruit_id) con etiquetas identicas, 37 positivos con_signos y 412 negativos sin_signos, 58 imagenes con crops dentro del split VAL de 65 imagenes. Misma huella de dataset, split, semantica, codigo y entorno. Se comprobaron SHA256 de predicciones y se reprodujeron las matrices de confusion, precision/recall/F1/F2/accuracy a umbral 0.5. Solo se usaron predicciones de validation. No se uso TEST ni se ejecutaron modelos.

Los valores AP y ROC-AUC oficiales se conservan de metrics.json; las probabilidades CSV guardadas tienen 8 decimales. La prediccion positiva usa p_con_signos >= umbral. FN: con_signos clasificado sin_signos; FP: sin_signos clasificado con_signos. Signos no equivale a infeccion confirmada por laboratorio.

Tablas: tabla_umbral_05.csv (rendimiento y conteos actuales), tabla_costo_teorico.csv (parametros/GFLOPs y datos de entrenamiento final), tabla_umbrales_exploratorios.csv (F1, F2, cero FN en VAL), barrido_101_umbrales.csv (todos los puntos), casos_FP_FN.csv (casos auditables).

Analisis adicional de umbrales: rejilla preexistente de 101 puntos [0,1] (paso 0.01), funciones originales threshold_sweep/pick_threshold. Para maximo F1/F2 se usa la mediana de los umbrales empatados, que puede caer entre dos puntos; sus conteos se recalculan. El criterio de cero FN usa el menor numero de FP y luego mayor umbral dentro de la rejilla. Es un analisis exploratorio sobre la misma VAL, no una evaluacion independiente ni el registro oficial del paso11. No se alteran config.yaml, politica ni artefactos del framework. F2=5TP/(5TP+4FN+FP).

Cero FN solo describe los 37 positivos observados, no garantiza recall 100% en datos nuevos. Las diferencias de 1-2 casos no acreditan significacion estadistica; las muestras comparten imagenes. Maximizar F2 no implica cero FN. Estos son GT crops: aun falta evaluar el clasificador sobre crops predichos por YOLO26l y los FN del sistema integrado.

Parametros/GFLOPs: costo teorico registrado por recorte; no son latencia ni energia. VRAM y tiempos: SOLO entrenamiento final, distintas epocas y PCs, no son consumo de inferencia ni costo total HPO/robustez.

Recomendacion de clasificador: ViT-B/16 por mejor AP/F2 y menos FP manteniendo el recall alto observado. Tiene mayor costo teorico. No se registra automaticamente esta recomendacion; YOLO26l sigue siendo el detector elegido por el usuario. El umbral final debe quedar documentado y comprobarse en el pipeline integrado antes de freeze/TEST.
