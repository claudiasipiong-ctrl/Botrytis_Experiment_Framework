# Tablas y graficos de apoyo preparados en esta conversacion

Comparaciones de VAL; no son resultados de TEST. Incluyen tablas, barridos exploratorios, figuras, Excel y codigo de calculo. Los scripts conservan las rutas de entrada del entorno en que se elaboraron; adaptar rutas a los CSV/JSON originales que se encuentran en los paquetes de las PCs.

La seleccion de YOLO26l priorizo el equilibrio entre rendimiento y costo teorico. Para clasificadores se examinaron FN y F2. El equipo decidio presentar dos sistemas finales (YOLO26l+ResNet50 y YOLO26l+Swin-Tiny); no se debe ocultar que la eleccion posterior del profesor consultara ambos TEST.

No confundir umbrales exploratorios de estas tablas con la ejecucion oficial: los freezes/protocolo y resultados guardados en PC2/bd son la fuente para documentar los dos TEST realmente ejecutados. No inventar benchmark de latencia ni etapas completadas de RT-DETR.
