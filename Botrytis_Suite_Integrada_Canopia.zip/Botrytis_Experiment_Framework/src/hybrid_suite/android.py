"""Connect an already running Android emulator to the local mobile benchmark."""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path


def find_adb():
    if executable := shutil.which("adb"):
        return executable
    sdk_roots = [os.environ.get("ANDROID_SDK_ROOT"), os.environ.get("ANDROID_HOME")]
    if local := os.environ.get("LOCALAPPDATA"):
        sdk_roots.append(str(Path(local) / "Android" / "Sdk"))
    name = "adb.exe" if os.name == "nt" else "adb"
    for root in filter(None, sdk_roots):
        candidate = Path(root) / "platform-tools" / name
        if candidate.is_file():
            return str(candidate)
    return None


def open_emulator(url, port):
    """Set up reverse TCP and open the exact current URL on a single emulator."""
    adb = find_adb()
    if adb is None:
        return False, "ADB no disponible. Para el emulador, use la URL local con ADB Reverse."
    try:
        devices = subprocess.run([adb, "devices"], capture_output=True, text=True, check=True, timeout=6).stdout
        emulators = [line.split()[0] for line in devices.splitlines()
                     if line.startswith("emulator-") and line.split()[1:2] == ["device"]]
        if not emulators:
            return True, "Encienda un emulador. El servidor comprobará ADB periódicamente."
        if len(emulators) > 1:
            return True, "ADB detectó varios emuladores. Mantenga uno para la medición y use la URL local."
        target = [adb, "-s", emulators[0]]
        endpoint = f"tcp:{port}"
        subprocess.run([*target, "reverse", endpoint, endpoint], capture_output=True, check=True, timeout=6)
        result = subprocess.run([*target, "shell", "am", "start", "-a", "android.intent.action.VIEW", "-d", url],
                                capture_output=True, text=True, check=True, timeout=6)
        if "Error:" in result.stdout or "Error:" in result.stderr:
            return False, "El túnel ADB está listo. Abra la URL local exacta en Chrome del emulador."
    except (OSError, subprocess.SubprocessError):
        return False, "ADB no pudo abrir la prueba automáticamente. Use ADB Reverse y la URL local de esta consola."
    return False, f"Se abrió la URL de esta sesión en {emulators[0]} mediante ADB Reverse."
