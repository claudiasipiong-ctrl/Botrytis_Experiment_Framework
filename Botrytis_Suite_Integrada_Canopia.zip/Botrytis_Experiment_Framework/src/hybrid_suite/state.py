"""Portable experiment state, assignment and verified local recovery."""
from __future__ import annotations

import itertools
import json
import logging
import os
import re
import socket
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

from utils.durable import FileLock, atomic_copy, atomic_json, filesystem_path
from utils.hashing import sha256_file, sha256_json

PAIRS = {
    "A": ("YOLO26l", "ResNet50"), "B": ("YOLO26l", "Swin-Tiny"),
    "C": ("YOLO26l", "ViT-B/16"), "D": ("YOLOv8l", "ViT-B/16"),
    "E": ("YOLOv8l", "ResNet50"), "F": ("YOLOv8l", "Swin-Tiny"),
}
LIMA = timezone(timedelta(hours=-5), "America/Lima")
SLOT = ("PC-01", "PC-02", "PC-03")
BASELINE = "PC-01"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def token(value):
    return str(value) if re.fullmatch(r"[a-f0-9]{64}", str(value)) else None


def files_under(root):
    for directory, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if not (Path(directory) / d).is_symlink())
        for name in sorted(files):
            path = Path(directory) / name
            if path.is_file() and not path.is_symlink() and not name.endswith((".partial", ".lock", ".tmp", ".partial.avi", ".importing")):
                yield path


def safe_path(root, name):
    path = (root / name).resolve()
    if not path.is_relative_to(root.resolve()) or path == root.resolve():
        raise ValueError(f"Ruta no contenida en el directorio esperado: {name}")
    return path


def seal(folder, key, names, metadata=None, *, marker="complete.json"):
    record = {"key": key, "files": {n: sha256_file(safe_path(folder, n)) for n in names},
              "metadata": metadata or {}}
    atomic_json(folder / marker, record)
    return record


def completed(folder, key, *, marker="complete.json"):
    path = folder / marker
    if not path.is_file():
        return None
    record = read(path)
    if record.get("key") != key or not record.get("files"):
        raise RuntimeError(f"Resultado previo incompatible, conservado: {path}")
    for name, digest in record["files"].items():
        path = safe_path(folder, name)
        if not path.is_file() or sha256_file(path) != digest:
            raise RuntimeError(f"Resultado previo alterado o incompleto: {path}")
    return record


def identify(mapping, username=None, hostname=None):
    candidates = {(username or os.getenv("USERNAME", "")).casefold(),
                  (hostname or socket.gethostname()).split(".")[0].casefold()}
    matches = [pc for pc, identity in mapping.items() if identity.casefold() in candidates]
    if len(matches) != 1:
        raise RuntimeError("Usuario y equipo no identifican de forma inequívoca una PC del mapa existente.")
    return matches[0]


def checkpoint_copy(source, target, digest):
    if target.is_file():
        if sha256_file(target) != digest:
            raise RuntimeError(f"Objeto alterado: {target}")
    else:
        if sha256_file(source) != digest:
            raise RuntimeError(f"Fuente alterada: {source}")
        atomic_copy(source, target)
        if sha256_file(target) != digest:
            raise RuntimeError(f"Copia no verificada: {target}")


def stage_checkpoint(store, cache_dir, digest):
    """Give model loaders a regular short path to the verified checkpoint.

    The original path can use Windows extended-length syntax. Ultralytics
    interprets the question mark in that syntax as the start of a URL query.
    """
    if token(digest) is None:
        raise RuntimeError("Huella SHA-256 de checkpoint inválida.")
    filename = f"{digest}.pt"
    target = cache_dir / filename
    checkpoint_copy(store / filename, target, digest)
    return target


def choose_plan(reports, tasks, sizes):
    """Exhaustive assignment of the small fixed DAG by simulated makespan.

    Estimated duration uses a measured GPU score, prior unit counts, and bytes
    that must be imported. A checkpoint is transferred once per receiving PC.
    """
    owners = sorted(reports)
    pinned = {name: task["owner"] for name, task in tasks.items() if task.get("owner")}
    movable = [name for name in tasks if name not in pinned]
    options = [[pc for pc in owners if reports[pc]["gpu_rate"] > 0] for _ in movable]
    best = None
    placement = None
    for combination in itertools.product(*options):
        assignment = pinned | dict(zip(movable, combination))
        finish = {}
        loads = dict.fromkeys(owners, 0.0)
        resident = {pc: set(reports[pc]["local"]) for pc in owners}
        copied = 0
        for name, task in tasks.items():
            pc = assignment[name]
            start = max([loads[pc], *[finish[d] for d in task["deps"]]])
            missing = set(task["models"]) - resident[pc]
            transfer = sum(sizes[m] for m in missing)
            copied += transfer
            resident[pc].update(missing)
            loads[pc] = finish[name] = start + task["cost"] / reports[pc]["gpu_rate"] + transfer / (100 * 1024**2)
        objective = (max(loads.values()), copied, sum(loads.values()), tuple(assignment.values()))
        if best is None or objective < best:
            best, placement = objective, assignment
    if placement is None:
        raise RuntimeError("No hay GPU disponible para el plan.")
    return {"owners": placement, "estimated_seconds": best[0], "estimated_transfer_bytes": best[1], "tasks": tasks}


def backup(home, roots, owner):
    """Incremental, content-addressed backup with verification before publication."""
    home.mkdir(parents=True, exist_ok=True)
    with FileLock(home / "snapshot.lock"):
        objects = home / "objects"
        entries = {}
        verified = set()
        for name, root in roots.items():
            root = filesystem_path(root)
            entries[name] = {}
            for file in files_under(root):
                digest = sha256_file(file)
                if digest not in verified:
                    checkpoint_copy(file, objects / digest, digest)
                    verified.add(digest)
                entries[name][file.relative_to(root).as_posix()] = digest
        manifest = {"schema": 1, "owner": owner, "entries": entries,
                    "created": datetime.now(timezone.utc).isoformat()}
        identifier = sha256_json(manifest)
        atomic_json(home / "snapshots" / f"{identifier}.json", manifest)
        atomic_json(home / "latest.json", {"snapshot": identifier})
        return identifier


def restore(home, roots, owner):
    """Validate the latest recoverable snapshot before restoring any file."""
    if not (home / "latest.json").is_file():
        return None
    try:
        preferred = token(read(home / "latest.json").get("snapshot"))
    except (OSError, ValueError, TypeError):
        preferred = None
    preferred_path = home / "snapshots" / f"{preferred}.json"
    snapshots = sorted((home / "snapshots").glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for manifest_path in [preferred_path, *[p for p in snapshots if p != preferred_path]]:
        try:
            manifest = read(manifest_path)
            if manifest["owner"] != owner or sha256_json(manifest) != manifest_path.stem:
                continue
            operations = []
            verified = set()
            for name, entries in manifest["entries"].items():
                for relative, digest in entries.items():
                    if token(digest) is None:
                        raise ValueError("Objeto de respaldo inválido")
                    obj = home / "objects" / digest
                    if digest not in verified and sha256_file(obj) != digest:
                        raise ValueError(f"Objeto de respaldo alterado: {obj}")
                    verified.add(digest)
                    operations.append((obj, safe_path(filesystem_path(roots[name]), relative), digest, name, relative))
        except (OSError, ValueError, KeyError, TypeError):
            continue
        for obj, dest, digest, name, relative in operations:
            if not dest.exists():
                checkpoint_copy(obj, dest, digest)
            elif not dest.is_file():
                raise RuntimeError(f"Destino de respaldo en conflicto: {dest}")
            elif name == "replicated_work" and recoverable_immutable(roots[name], relative, digest, manifest["entries"][name]):
                if sha256_file(dest) != digest:
                    atomic_copy(obj, dest)
                    if sha256_file(dest) != digest:
                        raise RuntimeError(f"Objeto restaurado no verificable: {dest}")
        return manifest_path.stem
    raise RuntimeError("No se encontró un respaldo íntegro para esta máquina.")


def recoverable_immutable(root, relative, digest, entries):
    """Repair immutable bytes, or a result whose live seal agrees with the backup."""
    parts = Path(relative).parts
    if relative.startswith("weights/") or (len(parts) >= 4 and parts[0] == "tasks" and parts[2] in ("units", "frames", "trials")):
        return True
    if len(parts) >= 3 and parts[0] == "tasks":
        seal_path = "/".join([*parts[:2], "complete.json"])
        current = root / seal_path
        if not current.is_file() or sha256_file(current) != entries.get(seal_path):
            return False
        task_file = "/".join(parts[2:])
        return read(current).get("files", {}).get(task_file) == digest
    return False


class Pause(Exception):
    """Cooperative stop after the last durable unit."""


class Clock:
    def __init__(self, mode, snapshot, *, now=lambda: datetime.now(LIMA), sleep=time.sleep):
        self.now, self.snapshot, self.sleep = now, snapshot, sleep
        current = now()
        self.deadline = current.replace(hour=21, minute=30, second=0, microsecond=0)
        self.next_backup = current + timedelta(minutes=15)
        self.stopped = False

    def check(self):
        current = self.now()
        if current >= self.deadline:
            while True:
                try:
                    self.snapshot()
                    break
                except (OSError, RuntimeError) as exc:
                    message = f"Respaldo pendiente de verificar; se reintenta en 30 s: {exc}"
                    logging.error(message)
                    print(message, flush=True)
                    self.sleep(30)
            self.stopped = True
            raise Pause("Respaldo verificado. Jornada cerrada a partir de las 21:30 (Lima).")
        if current >= self.next_backup:
            try:
                self.snapshot()
            except (OSError, RuntimeError) as exc:
                logging.error("Respaldo periódico pendiente: %s", exc)
                self.next_backup = self.now() + timedelta(minutes=1)
            else:
                self.next_backup = self.now() + timedelta(minutes=15)
