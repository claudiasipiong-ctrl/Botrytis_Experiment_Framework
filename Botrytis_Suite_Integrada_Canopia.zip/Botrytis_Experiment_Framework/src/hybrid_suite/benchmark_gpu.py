"""Check the selected GPU's actual utilization before measuring latency."""
from __future__ import annotations

import os
import re
import subprocess
import time


IDLE_LIMIT = 10
IDLE_SAMPLES = 4
SAMPLE_PERIOD = 2
WAIT_SECONDS = 60


def selected_gpu():
    import torch

    identity = str(getattr(torch.cuda.get_device_properties(0), "uuid", ""))
    if re.fullmatch(r"(?:GPU-)?[a-fA-F0-9-]{36}", identity):
        return identity if identity.startswith("GPU-") else f"GPU-{identity}"
    visible = os.environ.get("CUDA_VISIBLE_DEVICES")
    return visible.split(",")[0].strip() if visible else "0"


def utilization(gpu):
    try:
        result = subprocess.run(
            ["nvidia-smi", "--id", gpu, "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, check=True, timeout=5,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise RuntimeError(f"No se pudo consultar la utilización de la GPU {gpu}: {exc}") from exc
    value = result.stdout.strip()
    if not value.isdigit() or int(value) > 100:
        raise RuntimeError(f"Telemetría de utilización no disponible para la GPU {gpu}: {value!r}")
    return int(value)


def wait_for_idle(gpu, check, *, sample=utilization, sleep=time.sleep, monotonic=time.monotonic):
    """Require consecutive low-load observations. Idle contexts alone are normal on Windows."""
    start = monotonic()
    samples = []
    consecutive = 0
    while True:
        check()
        try:
            load = sample(gpu)
        except RuntimeError as exc:
            return {"status": "telemetry_unavailable", "reason": str(exc), "gpu": gpu,
                    "samples_percent": samples, "idle_limit_percent": IDLE_LIMIT}
        samples.append(load)
        consecutive = consecutive + 1 if load <= IDLE_LIMIT else 0
        elapsed = monotonic() - start
        if consecutive >= IDLE_SAMPLES or elapsed >= WAIT_SECONDS:
            return {"status": "ready" if consecutive >= IDLE_SAMPLES else "busy", "gpu": gpu,
                    "samples_percent": samples, "idle_limit_percent": IDLE_LIMIT,
                    "required_consecutive_samples": IDLE_SAMPLES, "wait_seconds": round(elapsed, 3)}
        sleep(min(SAMPLE_PERIOD, WAIT_SECONDS - elapsed))
