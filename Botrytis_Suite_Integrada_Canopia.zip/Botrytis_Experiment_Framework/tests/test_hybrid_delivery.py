"""Verify handoff recovery and reuse of scientifically equivalent run state."""
from __future__ import annotations

from io import BytesIO
from types import SimpleNamespace
from zipfile import ZipFile

import pandas as pd
import pytest

from hybrid_suite.local_report import local_report
from hybrid_suite.recovery import recover_downloads
from hybrid_suite.runner import COMPATIBLE_CODE, active_experiment, session_config
from hybrid_suite.state import Pause, read, seal
from utils.config_loader import load_config
from utils.dataset import compute_dataset_hash
from utils.durable import atomic_json
from utils.hashing import compute_split_hash, sha256_json
from utils.semantics import semantic_fingerprint
from utils.splits import MANIFEST_COLUMNS, write_split_manifest


def test_archives_recover_sealed_dataset_from_separate_nested_zips(tmp_path):
    pictures, labels = [tmp_path / p for p in ("original-pictures", "original-labels")]
    pictures.mkdir()
    labels.mkdir()
    for iid in ("train-1", "val-1", "test-1"):
        (pictures / f"{iid}.jpg").write_bytes(("fixture bytes " + iid).encode())
        (labels / f"{iid}.txt").write_text("0 0.5 0.5 0.2 0.2\n", encoding="utf-8")
    cfg = load_config()
    cfg["paths"].update(raw_images_dir=str(pictures), raw_labels_dir=str(labels))
    digest, _ = compute_dataset_hash(cfg)
    metadata = tmp_path / "split"
    metadata.mkdir()
    atomic_json(metadata / "dataset_validation.json", {"passed": True, "dataset_hash": digest,
                                                      "semantic_fingerprint": semantic_fingerprint(cfg)})
    (metadata / "dataset_inventory.csv").write_text("image_id\ntrain-1\nval-1\ntest-1\n")
    assignment = [("train-1", "train"), ("val-1", "validation"), ("test-1", "test")]
    split_hash = compute_split_hash(assignment)
    df = pd.DataFrame([{**dict.fromkeys(MANIFEST_COLUMNS, ""), "image_id": i, "outer_split": s,
                        "split_hash": split_hash} for i, s in assignment])
    write_split_manifest(df, metadata)
    pack = BytesIO()
    with ZipFile(pack, "w") as archive:
        for file in metadata.iterdir():
            archive.write(file, f"artifacts/{file.name}")
        archive.writestr("src/do_not_run.py", "raise Exception('this file is not executed')")
        archive.writestr("../outside.json", "{}")
    downloads = tmp_path / "Downloads"
    downloads.mkdir()
    with ZipFile(downloads / "INVENTARIO_TECNICO_COMPLETO_TESIS.ZIP", "w") as archive:
        archive.writestr("runs/handoff-results.zip", pack.getvalue())
    with ZipFile(downloads / "datos.zip", "w") as archive:
        for path, prefix in ((pictures, "images"), (labels, "labels")):
            for file in path.iterdir():
                archive.write(file, f"dataset/{prefix}/{file.name}")

    recovery = tmp_path / "recovery"
    clock = SimpleNamespace(check=lambda: None)
    roots = recover_downloads(downloads, recovery, clock)
    (resolved, art, obtained, signed_split, manifest), _, _ = session_config(roots)
    assert (obtained, signed_split) == (digest, split_hash)
    assert manifest.loc[manifest["outer_split"].eq("test"), "image_id"].tolist() == ["test-1"]
    assert (art / "split_manifest.sha256").is_file()
    assert "recovery" in resolved["paths"]["raw_images_dir"]
    assert not list(recovery.rglob("*.py"))
    assert not (tmp_path / "outside.json").exists()
    assert recover_downloads(downloads, recovery, clock) == roots


def test_interrupted_import_reuses_completed_entries(tmp_path, monkeypatch):
    import hybrid_suite.recovery as recovery

    downloads = tmp_path / "Downloads"
    downloads.mkdir()
    with ZipFile(downloads / "runs.zip", "w") as archive:
        archive.writestr("dataset/images/a.jpg", b"first")
        archive.writestr("dataset/images/b.jpg", b"second")
    clock = SimpleNamespace(check=lambda: None)
    calls = []
    copy_entry = recovery.copy_entry

    def interrupt(package, entry, target, clock):
        calls.append(entry.filename)
        if len(calls) == 2:
            raise Pause()
        copy_entry(package, entry, target, clock)

    monkeypatch.setattr(recovery, "copy_entry", interrupt)
    with pytest.raises(Pause):
        recover_downloads(downloads, tmp_path / "cache", clock)
    roots = recover_downloads(downloads, tmp_path / "cache", clock)
    assert calls == ["dataset/images/a.jpg", "dataset/images/b.jpg", "dataset/images/b.jpg"]
    assert (roots[0] / "dataset/images/b.jpg").read_bytes() == b"second"


def test_prior_plan_is_reopened_when_data_and_runtime_still_match(tmp_path):
    current = {"code": "new", "dataset_hash": "data", "split_hash": "split", "method": {"match": .5}, "runtime": "gpu"}
    earlier = {**current, "code": COMPATIBLE_CODE[0]}
    folder = tmp_path / "experiments" / sha256_json(earlier)
    atomic_json(folder / "plan.json", {"identity": sha256_json(earlier)})
    assert active_experiment(tmp_path, current) == (earlier, folder)
    newer_data = {**current, "split_hash": "different"}
    assert active_experiment(tmp_path, newer_data)[0] == newer_data


def test_local_report_contains_sealed_evidence_and_does_not_copy_frames(tmp_path):
    work = tmp_path / "shared"
    folder = work / "tasks" / "test-C"
    atomic_json(folder / "summary.json", {"result": "fixture"})
    atomic_json(folder / "units" / "00.json", {"raw": "fixture"})
    seal(folder, "test", ["summary.json"])
    atomic_json(work / "tasks" / "test-D" / "summary.json", {"result": "not complete"})
    output = tmp_path / "Consolidado_Tesis" / "resultados_ejecucion"
    local_report(work, output, "PC-03")
    assert read(next(output.rglob("summary.json")))["result"] == "fixture"
    assert not list(output.rglob("00.json"))
    assert not list((output / "test-D").rglob("*"))


def test_restore_repairs_corrupt_sealed_evidence_but_keeps_new_task(tmp_path):
    from hybrid_suite.state import backup, restore

    roots = {"replicated_work": tmp_path / "work"}
    work = roots["replicated_work"]
    owner = {"pc": "PC-01"}
    task = work / "tasks" / "test-C"
    atomic_json(task / "summary.json", {"test": "validated"})
    seal(task, "test", ["summary.json"])
    home = tmp_path / "home"
    backup(home, roots, owner)
    atomic_json(task / "summary.json", {"test": "damaged"})
    other = work / "tasks" / "test-D"
    atomic_json(other / "summary.json", {"test": "completed since backup"})
    seal(other, "test", ["summary.json"])
    restore(home, roots, owner)
    assert read(task / "summary.json") == {"test": "validated"}
    assert read(other / "summary.json") == {"test": "completed since backup"}


def test_windows_extended_local_and_unc_paths():
    from utils.durable import windows_extended_path

    path = "C:\\Users\\i21315\\" + "\\".join(["test-data-directory"] * 15) + "\\final_meta.json"
    assert len(path) > 260
    extended = windows_extended_path(path)
    assert extended == "\\\\?\\" + path
    assert windows_extended_path(extended) == extended
    assert windows_extended_path(r"\\servidor\recurso\tesis") == r"\\?\UNC\servidor\recurso\tesis"


def test_transient_windows_access_errors_retry_the_same_atomic_replace(tmp_path, monkeypatch):
    from utils import durable

    source, target = tmp_path / "partial", tmp_path / "data.json"
    source.write_bytes(b"sealed")
    replace = durable.os.replace
    delays = []
    attempts = []

    def temporarily_busy(a, b):
        attempts.append((a, b))
        if len(attempts) < 3:
            exc = PermissionError("archivo en uso")
            exc.winerror = 5
            raise exc
        replace(a, b)

    monkeypatch.setattr(durable.os, "replace", temporarily_busy)
    monkeypatch.setattr(durable.time, "sleep", delays.append)
    durable.replace_file(source, target)
    assert target.read_bytes() == b"sealed"
    assert attempts == [(source, target)] * 3
    assert delays == [0.05, 0.1]


def test_recovery_reuses_old_journal_and_accepts_deep_paths(tmp_path, monkeypatch):
    import hybrid_suite.recovery as recovery

    archive_path = tmp_path / "history.zip"
    target = tmp_path / "recovered"
    target.mkdir()
    deep = "/".join(["registro-historico"] * 15 + ["results", "test_results.json"])
    existing = target / "dataset/images/existing.jpg"
    existing.parent.mkdir(parents=True)
    existing.write_bytes(b"already extracted")
    from utils.hashing import sha256_file
    old = {"dataset/images/existing.jpg": sha256_file(existing)}
    atomic_json(target / ".recovering.json", old)
    copies = []
    copy_entry = recovery.copy_entry

    def record(package, entry, path, clock):
        copies.append(entry.filename)
        copy_entry(package, entry, path, clock)

    monkeypatch.setattr(recovery, "copy_entry", record)
    with ZipFile(archive_path, "w") as archive:
        archive.writestr("dataset/images/existing.jpg", b"already extracted")
        archive.writestr(deep, "{}")
        archive.writestr("runs/previous_attempts/ignored/test_results.json", "{}")
    clock = SimpleNamespace(check=lambda: None)
    recovery.unpack_evidence(archive_path, target, clock)
    assert copies == [deep]
    assert (target / deep).is_file()
    assert read(target / ".recovering.json") == old
    assert len(list((target / ".receipts").glob("*.json"))) == 1


def test_no_network_runs_only_pc01_and_does_not_fork_existing_plan(tmp_path):
    from hybrid_suite.runner import execution_storage

    key = {"code": "new", "dataset_hash": "data"}
    home = tmp_path / "PC-01"
    _, local, participants = execution_storage(home, "PC-01", None, key)
    assert participants == ("PC-01",)
    assert local.is_relative_to(home / "local-fleet")
    assert execution_storage(tmp_path / "PC-02", "PC-02", None, key) == (key, None, ())
    atomic_json(local / "plan.json", {"identity": sha256_json(key)})
    shared = tmp_path / "share"
    shared.mkdir()
    assert execution_storage(home, "PC-01", shared, key, local)[1:] == (local, ("PC-01",))
    missing = tmp_path / "old-share/experiments" / sha256_json(key)
    with pytest.raises(RuntimeError, match="no está disponible"):
        execution_storage(home, "PC-01", None, key, missing)


def test_checkpoint_from_tesis_archive_requires_final_meta_and_matching_hash(tmp_path):
    from hybrid_suite.runner import inventory
    from utils.hashing import sha256_file

    downloads = tmp_path / "Downloads"
    downloads.mkdir()
    weights = tmp_path / "weights.pt"
    weights.write_bytes(b"fixture")
    key = {"dataset_hash": "d", "split_hash": "s"}
    prefix = "PC-03/01_MODELOS/vit_b16/07_Pesos_y_procedencia/"
    import json
    with ZipFile(downloads / "TESIS_PC-03.zip", "w") as z:
        z.write(weights, prefix + "vit_final.pt")
        z.writestr(prefix + "final_meta.json", json.dumps({**key, "architecture": "ViT-B/16", "sha256": sha256_file(weights),
                   "trained_on": "outer_train_100pct", "early_stopping": False, "epoch_selected_on_validation": False}))
        z.writestr(prefix + "otro/last.pt", b"partial")
    from hybrid_suite.recovery import evidence_trees
    recovered = recover_downloads(downloads, tmp_path / "imports", SimpleNamespace(check=lambda: None))
    artifacts, *_ = evidence_trees(recovered)
    checkpoints, _, _ = inventory(artifacts, key)
    assert set(checkpoints) == {"ViT-B/16"}
    assert next(iter(checkpoints["ViT-B/16"].values()))[0].name == "vit_final.pt"
    assert not list((tmp_path / "imports").rglob("last.pt"))


def test_local_plan_runs_val_without_historical_ab_result(tmp_path):
    from hybrid_suite.runner import MODELS, create_plan

    key = {"dataset_hash": "d", "split_hash": "s",
           "method": {"inference_tuning": {"detector_nms_iou_grid": [.5, .6]}}}
    weights = {model: {"hash-" + model: {"size": 500}} for model in MODELS}
    atomic_json(tmp_path / "machines/PC-01.json", {"offers": weights, "thresholds": {}, "legacy": {},
                "local": MODELS, "gpu": "test", "gpu_rate": 1, "host": "fixture", "vram": 1, "torch_cuda": "test"})
    plan = create_plan(tmp_path, key, (65, 32), ("PC-01",))
    assert plan["prior"] == {}
    assert {"point-C", "point-D", "point-E", "point-F"} <= plan["validation"]["owners"].keys()
    assert {"test-C", "test-D", "test-E", "test-F"} <= plan["test"]["owners"].keys()
    assert {"test-A", "test-B"}.isdisjoint(plan["test"]["owners"])
    assert set(plan["validation"]["owners"].values()) == {"PC-01"}


def provenance_fixture(tmp_path):
    from utils.hashing import sha256_text
    from utils.splits import build_split_manifest

    cfg = load_config()
    assignments = {"tr": "train", "va": "validation", "te": "test"}
    manifest = build_split_manifest(assignments)
    labels = cfg["classification_labels"]
    fruits = pd.DataFrame({"image_id": ["tr", "va", "te"], "label": [labels["negative_label"]] * 2 + [labels["positive_label"]]})
    data = SimpleNamespace(manifest=manifest, fruits=fruits, artifacts_dir=tmp_path)
    key = {"dataset_hash": "d", "split_hash": manifest["split_hash"].iloc[0], "semantics": semantic_fingerprint(cfg)}
    history = {split: {"images": 1, "fruits": 1, "positive_fruits": int(split == "test")} for split in assignments.values()}
    lock = {"dataset_hash": key["dataset_hash"], "split_hash": key["split_hash"],
            "locked": True, "n_test_images": 1, "test_image_ids_sha256": sha256_text("te\n")}
    write_split_manifest(manifest, tmp_path, cfg["outer_split"]["manifest_name"])
    return key, data, cfg, history, lock


def test_original_test_lock_verifies_oversight_without_certifying_ab(tmp_path):
    from hybrid_suite.provenance import original_test_evidence

    key, data, cfg, history, lock = provenance_fixture(tmp_path)
    result = original_test_evidence([tmp_path], key, data, cfg, history, {})
    assert result["method"] == "pending"
    atomic_json(tmp_path / "test_lock.json", lock)
    result = original_test_evidence([tmp_path], key, data, cfg, history, {})
    assert result["method"] == "archived_test_lock"
    assert result["verified_hybrids"] == []
    assert result["test_image_ids_sha256"] == lock["test_image_ids_sha256"]
    atomic_json(tmp_path / "test_lock.json", {**lock, "test_image_ids_sha256": "1" * 64})
    result = original_test_evidence([tmp_path], key, data, cfg, history, {})
    assert result["method"] == "pending"
    assert "contradice" in result["reason"]


def test_original_split_metadata_checks_entire_manifest_and_counts(tmp_path):
    from hybrid_suite.provenance import original_test_evidence
    from utils.hashing import sha256_file

    key, data, cfg, history, _ = provenance_fixture(tmp_path)
    split_path = tmp_path / cfg["outer_split"]["manifest_name"]
    atomic_json(tmp_path / "split_metadata.json", {"dataset_hash": key["dataset_hash"], "split_hash": key["split_hash"],
                "seed": cfg["outer_split"]["seed"], "semantic_fingerprint": key["semantics"],
                "manifest_sha256": sha256_file(split_path), "counts": {split: 1 for split in history}})
    result = original_test_evidence([tmp_path], key, data, cfg, history, {})
    assert result["method"] == "archived_split_metadata"
    assert result["verified_hybrids"] == []
    history["test"]["positive_fruits"] = 2
    assert original_test_evidence([tmp_path], key, data, cfg, history, {})["method"] == "pending"
    history["test"]["positive_fruits"] = 1
    split_path.write_text("invalid file")
    assert original_test_evidence([tmp_path], key, data, cfg, history, {})["method"] == "pending"


def test_inventory_recovers_a_from_separate_freeze_and_result_archives(tmp_path):
    from hybrid_suite.runner import inventory
    from utils.hashing import sha256_file, write_checksum_file

    key, data, cfg, _, lock = provenance_fixture(tmp_path)
    freeze = tmp_path / "archive A" / "freeze_manifest_A.json"
    result = tmp_path / "archive results" / "test_results_portable.json"
    atomic_json(freeze, {"data": {"dataset_hash": key["dataset_hash"], "split_hash": key["split_hash"],
                                  "test_image_ids_sha256": lock["test_image_ids_sha256"]},
                "semantic_fingerprint": key["semantics"],
                "detector": {"architecture": "YOLO26l", "checkpoint_hash": "det", "confidence_threshold": .325, "nms_iou": None},
                "classifier": {"architecture": "ResNet50", "checkpoint_hash": "cls", "probability_threshold": .69},
                "pipeline": {"matching_rule": {"threshold": .5}}})
    write_checksum_file(freeze, freeze.with_name(freeze.name + ".sha256"))
    atomic_json(result, {"detector": "YOLO26l", "classifier": "ResNet50", "dataset_hash": key["dataset_hash"],
                "split_hash": key["split_hash"], "freeze_sha256": sha256_file(freeze), "thresholds_changed_after_test": False})
    write_checksum_file(result, result.with_suffix(".sha256"))
    _, _, legacy = inventory([result.parent, freeze.parent], key)
    assert legacy["A"]["freeze"] == freeze
    assert legacy["A"]["path"] == result
    from hybrid_suite.provenance import original_test_evidence
    verified = original_test_evidence([], key, data, cfg, {}, legacy)
    assert verified["method"] == "historical_result_and_freeze"
    assert verified["verified_hybrids"] == ["A"]


def test_model_loader_uses_verified_local_pt_instead_of_import_path(tmp_path):
    from hybrid_suite.state import stage_checkpoint
    from utils.hashing import sha256_file

    store = tmp_path / "work" / "weights"
    state = tmp_path / "local_state" / "checkpoints"
    store.mkdir(parents=True)
    checkpoint = store / "original"
    checkpoint.write_bytes(b"checkpoint bytes")
    digest = sha256_file(checkpoint)
    source = checkpoint.with_name(digest + ".pt")
    checkpoint.rename(source)
    local = stage_checkpoint(store, state, digest)
    assert local == state / (digest + ".pt")
    assert local.read_bytes() == source.read_bytes()
    assert sha256_file(local) == digest
    source.unlink()
    assert stage_checkpoint(store, state, digest) == local
    local.write_bytes(b"tampered")
    with pytest.raises(RuntimeError, match="alterado"):
        stage_checkpoint(store, state, digest)
    with pytest.raises(RuntimeError, match="inválida"):
        stage_checkpoint(store, state, "../anything")


def test_benchmark_waits_for_four_consecutive_idle_samples():
    from hybrid_suite.benchmark_gpu import wait_for_idle

    readings = iter([25, 6, 5, 17, 10, 0, 2, 4])
    elapsed = [0]
    checks = []

    def sleep(seconds):
        elapsed[0] += seconds

    result = wait_for_idle("GPU-test", lambda: checks.append(True),
                           sample=lambda gpu: next(readings), sleep=sleep, monotonic=lambda: elapsed[0])
    assert result["status"] == "ready"
    assert result["samples_percent"][-4:] == [10, 0, 2, 4]
    assert len(checks) == 8


def test_benchmark_stays_pending_under_load_or_missing_telemetry():
    from hybrid_suite.benchmark_gpu import WAIT_SECONDS, wait_for_idle

    elapsed = [0]

    def sleep(seconds):
        elapsed[0] += seconds

    result = wait_for_idle("0", lambda: None, sample=lambda _gpu: 70,
                           sleep=sleep, monotonic=lambda: elapsed[0])
    assert result["status"] == "busy" and result["wait_seconds"] == WAIT_SECONDS

    def unavailable(_gpu):
        raise RuntimeError("utilización N/A")

    result = wait_for_idle("0", lambda: None, sample=unavailable)
    assert result["status"] == "telemetry_unavailable"


def test_adb_reverse_opens_exact_current_url_for_one_emulator(monkeypatch):
    from types import SimpleNamespace
    from hybrid_suite import android

    calls = []
    monkeypatch.setattr(android, "find_adb", lambda: "adb.exe")

    def command(arguments, **kwargs):
        calls.append(arguments)
        return SimpleNamespace(stdout="List of devices attached\nemulator-5554\tdevice\nphone\tdevice\n", stderr="")

    monkeypatch.setattr(android.subprocess, "run", command)
    url = "http://127.0.0.1:8765/current-session"
    retry, message = android.open_emulator(url, 8765)
    assert not retry and "emulator-5554" in message
    assert calls[1] == ["adb.exe", "-s", "emulator-5554", "reverse", "tcp:8765", "tcp:8765"]
    assert calls[2][-2:] == ["-d", url]
