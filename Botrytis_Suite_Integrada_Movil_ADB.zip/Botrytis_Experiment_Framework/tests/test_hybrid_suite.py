"""Regression tests for the durable six-hybrid workflow (no trained weights)."""
from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
from PIL import Image

from hybrid_suite import video
from hybrid_suite.runner import PAIRS, MODELS, create_plan, inventory
from hybrid_suite.state import LIMA, Clock, Pause, backup, choose_plan, completed, identify, read, restore, seal
from utils.durable import atomic_json
from utils.hashing import sha256_file, write_checksum_file


def test_snapshot_restore_recovers_missing_files_and_preserves_new_progress(tmp_path):
    roots = {"local_state": tmp_path / "live"}
    live = roots["local_state"]
    live.mkdir()
    weights = live / "checkpoint.pt"
    weights.write_bytes(b"fixture")
    state = live / "journal.json"
    atomic_json(state, {"done": [0, 1]})
    who = {"pc": "PC-01", "host": "test", "user": "owner"}
    home = tmp_path / "backup"
    saved = backup(home, roots, who)
    weights.unlink()
    atomic_json(state, {"done": [0, 1, 2]})
    assert restore(home, roots, who) == saved
    assert weights.read_bytes() == b"fixture"
    assert read(state)["done"] == [0, 1, 2]
    digest = sha256_file(weights)
    (home / "objects" / digest).write_bytes(b"damaged")
    with pytest.raises(RuntimeError, match="íntegro"):
        restore(home, roots, who)


def test_cutoff_pauses_only_after_verified_backup():
    now = [datetime(2026, 11, 25, 21, 29, tzinfo=LIMA)]
    calls = []
    clock = Clock("Today", lambda: calls.append("backup"), now=lambda: now[0])
    clock.check()
    assert calls == []
    now[0] = now[0].replace(minute=30)
    with pytest.raises(Pause):
        clock.check()
    assert calls == ["backup"]
    assert clock.stopped
    retries = []
    def failed():
        retries.append("backup")
        if len(retries) == 1:
            raise OSError("copia falló")
    now[0] = now[0].replace(minute=31)
    broken = Clock("Tomorrow", failed, now=lambda: now[0], sleep=lambda _seconds: retries.append(broken.stopped))
    with pytest.raises(Pause):
        broken.check()
    assert retries == ["backup", False, "backup"]
    assert broken.stopped


def test_plan_uses_parallel_gpus_and_local_weights():
    reports = {"PC-01": {"local": ["x"], "gpu_rate": 1}, "PC-02": {"local": ["y"], "gpu_rate": 2},
               "PC-03": {"local": ["z"], "gpu_rate": 1}}
    tasks = {name: {"deps": [], "models": [name], "cost": 100} for name in ("x", "y", "z")}
    plan = choose_plan(reports, tasks, dict.fromkeys(tasks, 400_000_000))
    assert plan["owners"] == {"x": "PC-01", "y": "PC-02", "z": "PC-03"}
    assert plan["estimated_transfer_bytes"] == 0
    assert identify({"PC-01": "i21315"}, "i21315", "arbitrary-name") == "PC-01"


def test_original_receipt_is_preserved_and_never_assigns_ab_test(tmp_path):
    art = tmp_path / "artifacts"
    art.mkdir()
    key = {"dataset_hash": "data", "split_hash": "split", "semantics": "semantic",
           "method": {"inference_tuning": {"detector_nms_iou_grid": [0.5, 0.6]}}}
    freeze = art / "freeze_manifest_A.json"
    atomic_json(freeze, {"data": {"dataset_hash": "data", "split_hash": "split"}, "semantic_fingerprint": "semantic",
                        "detector": {"checkpoint_hash": "yolo-hash", "confidence_threshold": .325, "nms_iou": None},
                        "classifier": {"checkpoint_hash": "res-hash", "probability_threshold": .69},
                        "pipeline": {"matching_rule": {"threshold": .5}}})
    write_checksum_file(freeze, freeze.with_suffix(".sha256"))
    result = art / "test_results_A.json"
    atomic_json(result, {"detector": "YOLO26l", "classifier": "ResNet50", "dataset_hash": "data", "split_hash": "split",
                         "freeze_sha256": sha256_file(freeze), "thresholds_changed_after_test": False,
                         "detection_standard_metrics": {"map50": .9, "source": "test-fixture"}})
    write_checksum_file(result, result.with_suffix(".sha256"))
    before = result.read_bytes()
    _, _, legacy = inventory([art], key)
    assert set(legacy) == {"A"}
    assert legacy["A"]["point"]["cls_threshold"] == .69
    portable = {k: v for k, v in legacy["A"].items() if k not in ("path", "freeze")}
    for index, pc in enumerate(("PC-01", "PC-02", "PC-03")):
        models = {model: {portable["hashes"].get(model, model): {"size": 10}} for model in MODELS}
        atomic_json(tmp_path / "machines" / f"{pc}.json",
                    {"host": pc, "gpu_rate": index + 1, "gpu": "fixture", "vram": 1024, "torch_cuda": "fixture",
                     "local": MODELS, "offers": models, "thresholds": {}, "legacy": {"A": portable} if index == 1 else {}})
    plan = create_plan(tmp_path, key, (65, 32))
    tasks = plan["test"]["owners"]
    assert {name for name in tasks if not name.startswith("test-det")} == {"test-C", "test-D", "test-E", "test-F"}
    assert "test-det-yolo26l" not in tasks
    assert plan["det_points"]["YOLO26l"]["det_conf"] == .325
    assert result.read_bytes() == before


def test_incompatible_completion_is_never_reused(tmp_path):
    atomic_json(tmp_path / "summary.json", {"f1": .9})
    seal(tmp_path, "identity", ["summary.json"])
    assert completed(tmp_path, "identity")
    with pytest.raises(RuntimeError, match="incompatible"):
        completed(tmp_path, "other identity")
    atomic_json(tmp_path / "summary.json", {"f1": 0})
    with pytest.raises(RuntimeError, match="alterado"):
        completed(tmp_path, "identity")


def test_video_units_resume_with_same_inputs(tmp_path, monkeypatch):
    monkeypatch.setattr(video, "SIZE", (64, 48))
    image = tmp_path / "source.png"
    Image.new("RGB", (80, 60), "brown").save(image)
    folder = tmp_path / "inputs"
    calls = []
    clock = SimpleNamespace(check=lambda: None)
    point = {"det_conf": .325, "cls_threshold": .69}
    def timed_frame(rgb, _models, _point):
        calls.append(rgb.size)
        return [{"box": [5, 5, 25, 25], "score": .8, "prob": .93, "positive": True}], {"pipeline_ms": .5}
    fake = SimpleNamespace(ids=lambda split: ["test-only"], paths={"test-only": image}, clock=clock,
                           cfg={"benchmark": {"warmup_iterations": 0}}, point=lambda h: point,
                           load=lambda h: None, frame=timed_frame)
    video.make_clips(fake, folder, "input")
    input_manifest = read(folder / "manifest.json")
    assert len(input_manifest["clips"]) == 10
    assert all(c["synthetic"] and c["fps"] == 30 and c["partition"] == "test" for c in input_manifest["clips"])
    out = tmp_path / "output"
    out.mkdir()
    def interrupt_if_necessary():
        if len(calls) >= 35:
            raise Pause()
    clock.check = interrupt_if_necessary
    with pytest.raises(Pause):
        video.video_trial(fake, "A", out, "trial", folder)
    assert len(calls) == 35
    clock.check = lambda: None
    files = video.video_trial(fake, "A", out, "trial", folder)
    seal(out, "trial", files)
    assert completed(out, "trial")
    assert len(calls) == 300
    rows = pd.read_csv(out / "frame_timing.csv")
    assert len(rows) == 300
    assert rows["image_id"].unique().tolist() == ["test-only"]
    assert all(clip["continuity_same_class_iou50"] == 1 for clip in read(out / "summary.json")["videos"])
    assert len(list(out.glob("pred-A-*.avi"))) == 10


def test_integrated_units_resume_with_real_matching(tmp_path, monkeypatch):
    from hybrid_suite.evaluation import Evaluation
    from utils.config_loader import load_config
    import utils.inference
    import utils.pipeline_eval

    ids = ["val-0", "val-1", "test-0"]
    for iid in ids:
        Image.new("RGB", (32, 32)).save(tmp_path / f"{iid}.png")
    fruits = pd.DataFrame([{"image_id": iid, "fruit_id": 1, "image_w": 32, "image_h": 32,
                            "x1": 2, "y1": 2, "x2": 15, "y2": 15,
                            "label": "sin_signos" if iid == "val-0" else "con_signos"} for iid in ids])
    data = SimpleNamespace(images=pd.DataFrame({"image_id": ids, "image_path": [tmp_path / f"{i}.png" for i in ids]}),
                           manifest=pd.DataFrame({"image_id": ids, "outer_split": ["validation", "validation", "test"]}),
                           fruits=fruits)
    invocations = []
    def predict(*_args, **_kwargs):
        invocations.append(True)
        return [(np.array([[2, 2, 15, 15]]), np.array([.8]))]
    monkeypatch.setattr(utils.inference, "predict_detector", predict)
    monkeypatch.setattr(utils.pipeline_eval, "_classify_timed", lambda *_args: (np.array([.1 if len(invocations) == 1 else .91]), .02, .03))
    clock = SimpleNamespace(check=lambda: None)
    ev = Evaluation(load_config(), data, tmp_path, None, clock)
    monkeypatch.setattr(ev, "load", lambda _h: (None, None, None))
    folder = tmp_path / "integrated"
    folder.mkdir()
    point = {"det_conf": .325, "nms_iou": .5, "cls_threshold": .5}
    def pause():
        if len(invocations) == 1:
            raise Pause()
    clock.check = pause
    with pytest.raises(Pause):
        ev.integrated("C", "validation", point, "fixture", folder)
    clock.check = lambda: None
    outputs = ev.integrated("C", "validation", point, "fixture", folder)
    assert len(invocations) == 2
    assert "point.json" in outputs
    assert read(folder / "point.json")["source"] == "predicted_crops_outer_validation_20pct"
    assert pd.read_csv(folder / "detections.csv")["image_id"].tolist() == ids[:2]


def test_mobile_http_protocol_accepts_identical_samples_for_all_six(tmp_path):
    import os
    import subprocess
    import sys
    from pathlib import Path

    # The original QA bootstrap deliberately prohibits ports in its own process.
    root = Path(__file__).resolve().parents[1]
    env = {**os.environ, "PYTHONPATH": str(root / "src")}
    result = subprocess.run([sys.executable, __file__, str(tmp_path)], env=env, capture_output=True, text=True, timeout=40)
    assert result.returncode == 0, result.stdout + result.stderr
    assert "aborted response fixture" not in result.stderr
    assert "Exception occurred during processing" not in result.stderr


def exercise_mobile_http(tmp_path, monkeypatch):
    import json
    import queue
    import socket
    import threading
    from http.server import BaseHTTPRequestHandler
    from urllib.error import HTTPError
    from urllib.parse import urlsplit
    from urllib.request import Request, urlopen
    from hybrid_suite import mobile

    monkeypatch.setattr(video, "SIZE", (64, 48))
    monkeypatch.setattr(mobile, "TRIALS", 2)
    monkeypatch.setattr(mobile, "open_emulator", lambda *_: (False, "ADB fixture"))
    disconnected = threading.Event()
    end_headers = BaseHTTPRequestHandler.end_headers

    def abort_probe(handler):
        if handler.path == "/canceled":
            disconnected.set()
            raise ConnectionAbortedError("aborted response fixture")
        end_headers(handler)

    monkeypatch.setattr(BaseHTTPRequestHandler, "end_headers", abort_probe)
    inputs = tmp_path / "inputs"
    inputs.mkdir()
    image = Image.new("RGB", (64, 48), "brown")
    for i in range(2):
        video.encode(inputs / f"sintetico-{i}.avi", [image])
    announced = queue.Queue()
    outcomes = queue.Queue()
    calls = []
    def frame(_image, models, _point):
        calls.append(models)
        return [], {"pipeline_ms": .07}
    fake = SimpleNamespace(clock=SimpleNamespace(check=lambda: None), cfg={"benchmark": {"warmup_iterations": 0}},
                           load=lambda hybrid: hybrid, point=lambda hybrid: hybrid, frame=frame)
    folder = tmp_path / "mobile"
    thread = threading.Thread(target=lambda: outcomes.put(mobile.serve(fake, folder, "mock-no-device", inputs, port=0,
                                                                       host="127.0.0.1",
                                                                       announce=lambda message, **kw: announced.put(message))),
                              daemon=True)
    thread.start()
    url = urlsplit(announced.get(timeout=10).split()[-1])
    origin = f"http://127.0.0.1:{url.port}"
    base = origin + url.path + "/"
    # An idle speculative connection must not queue unrelated HTTP requests.
    with socket.create_connection(("127.0.0.1", url.port), timeout=3):
        with socket.create_connection(("127.0.0.1", url.port), timeout=3) as canceled:
            canceled.sendall(b"GET /canceled HTTP/1.0\r\n\r\n")
            assert disconnected.wait(3)
        with urlopen(origin + "/healthz", timeout=3) as response:
            assert json.load(response) == {"status": "ready"}
        with pytest.raises(HTTPError) as rejected:
            urlopen(origin + "/incorrecto", timeout=3)
        assert rejected.value.code == 404
        assert b"Ruta incorrecta" in rejected.value.read()
        with urlopen(base, timeout=3) as response:
            assert b"Medir en este dispositivo" in response.read()

    def request(route, data=None):
        with urlopen(Request(base + route, data=data, headers={"User-Agent": "mock-browser"}), timeout=10) as response:
            return response.read(), response.headers
    client = "a" * 32
    schedules = json.loads(request("schedule/" + client)[0])
    assert list(schedules) == list(PAIRS)
    for h, indices in schedules.items():
        request("activate/" + h, b"")
        for index in indices:
            pixels, _ = request(f"input/{index}")
            annotation, headers = request(f"infer/{h}/{index}", pixels)
            assert annotation[:2] == b"\xff\xd8"
            request("report", json.dumps({"nonce": headers["X-Trial"], "client": client, "client_ms": 25,
                                          "platform": "mock", "ua": "mock-browser", "width": 320, "height": 640, "dpr": 1}).encode())
    assert outcomes.get(timeout=10)
    thread.join(1)
    assert calls == [h for h in PAIRS for _ in range(2)]
    assert set(read(folder / "summary.json")["results"]) == set(PAIRS)


if __name__ == "__main__":
    import sys
    from pathlib import Path

    with pytest.MonkeyPatch.context() as patch:
        exercise_mobile_http(Path(sys.argv[1]), patch)
