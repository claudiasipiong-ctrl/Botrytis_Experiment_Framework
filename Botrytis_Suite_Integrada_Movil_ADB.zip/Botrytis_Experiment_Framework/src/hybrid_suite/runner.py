"""Orchestration for the six-hybrid supplement to the official experiment."""
from __future__ import annotations

import argparse
import csv
import getpass
import importlib.metadata
import logging
import os
import socket
import sys
import time
from pathlib import Path

from hybrid_suite.local_report import local_report
from hybrid_suite.provenance import TEST_PROOF_METHODS, original_test_evidence, prior_freezes, sealed_json
from hybrid_suite.recovery import evidence_trees, recover_downloads
from hybrid_suite.state import (BASELINE, PAIRS, SLOT, Clock, Pause, backup, checkpoint_copy,
                                choose_plan, completed, identify, read, restore, seal, stage_checkpoint)
from utils.architectures import get_arch
from utils.config_loader import PROJECT_ROOT, cfg_path, load_config
from utils.durable import FileLock, atomic_bytes, atomic_json, filesystem_path
from utils.hashing import compute_code_hash, sha256_file, sha256_json
from utils.semantics import semantic_fingerprint

MODELS = sorted(set().union(*map(set, PAIRS.values())))
DETECTORS = sorted({det for det, _ in PAIRS.values()})
# Approximate relative compute from the manuscript: image GFLOPs for the
# detector and crop GFLOPs times the mean of about seven annotated fruits.
COST = {"YOLO26l": 1.0, "YOLOv8l": 164.81 / 92.70, "ResNet50": 7 * 8.17 / 92.70,
        "Swin-Tiny": 7 * 8.98 / 92.70, "ViT-B/16": 7 * 33.70 / 92.70}
PREVIOUS = ("A", "B")
# Accepted deliveries preserve the evaluation and receipt formats.
COMPATIBLE_CODE = (
    "5373b21804fd00330779ee16389006b6d5a20c0b176d14eb65011e4e2da7fe69",
    "486d2f168a67584f2a6ddda573b28745a7ee06e7b1bb8b01f821c88a6e5a4f7f",
    "dc0090ecc108bfab16d0d2218ebd3daab3e659fe932f801b13317112cca2d490",
    "828654e61f41129f3733be492c30f3ca4e115d6d22ffc822da2fec9827785b2d",
    "8d7e36525914dd291ebd4998fee1568d646a564a147933c787d1dda32451a8e1",
    "c1d68b549f2205abad15f2e9579c7ae9fd6185395fca563eee5d588ca04fe8b1",
    "80a83266bf454ea26c8e73733c410ec0cfbbfb0a9bdac0af4a25e0b5709f8896",
)


def project_sources(base, downloads):
    roots = {PROJECT_ROOT}
    locations = [base, downloads, PROJECT_ROOT.parent]
    locations += [place / "descomprimido" for place in (base, downloads)]
    if os.name == "nt":
        import ctypes
        for drive in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            disk = Path(f"{drive}:/")
            if ctypes.windll.kernel32.GetDriveTypeW(str(disk)) not in (3, 4):
                continue
            for parent in ("My Drive", "Mi unidad"):
                tree = disk / parent
                if tree.is_dir():
                    locations.append(tree)
                    locations.extend(p / "descomprimido" for p in tree.iterdir() if p.is_dir())
    for location in locations:
        if not location.is_dir():
            continue
        nearby = [p for p in location.iterdir() if p.is_dir() and not p.is_symlink()
                  and p.name not in ("HybridSuite", ".venv", "__pycache__")]
        nested = []
        for p in nearby:
            try:
                nested.extend(q for q in p.iterdir() if q.is_dir() and not q.is_symlink())
            except PermissionError:
                logging.warning("Ruta inaccesible al buscar fuentes: %s", p)
        for root in [location, *nearby, *nested]:
            if (root / "configs/default.yaml").is_file() or (root / "artifacts").is_dir():
                roots.add(root.resolve())
    return sorted(roots)


def session_config(sources):
    """Match archived configuration, dataset bytes and sealed original split."""
    from utils.config_loader import ConfigError
    from utils.dataset import compute_dataset_hash, require_validated_dataset
    from utils.splits import load_split_manifest

    candidates, errors = [], []
    artifacts, raw_roots, config_files, runs = evidence_trees(sources)
    config_rows = []
    image_roots = set(raw_roots)
    for path in [*config_files, None]:
        source = path.parent.parent if path else PROJECT_ROOT
        try:
            cfg = load_config(path)
        except (OSError, ValueError, ConfigError) as exc:
            errors.append(f"{path}: {exc}")
            continue
        paths = cfg["paths"]
        for key in ("raw_images_dir", "raw_labels_dir", "artifacts_dir", "detection_dir", "classification_dir", "runs_dir"):
            value = Path(paths[key])
            paths[key] = str(value if value.is_absolute() else source / value)
        original = (cfg_path(cfg, "paths.raw_images_dir"), cfg_path(cfg, "paths.raw_labels_dir"))
        if all(p.is_dir() for p in original):
            image_roots.add(original)
        config_rows.append((path, cfg, original))

    hashes = {}
    for art in artifacts:
        if not (art / "dataset_validation.json").is_file() or not (art / "dataset_inventory.csv").is_file():
            continue
        try:
            validation = read(art / "dataset_validation.json")
        except (OSError, ValueError) as exc:
            errors.append(f"{art}: {exc}")
            continue
        rows = sorted(config_rows, key=lambda row: (
            not (row[0] and art.is_relative_to(row[0].parent.parent)),
            not (row[0] and row[0].name == "local.yaml"), str(row[0])))
        found = False
        for _, cfg, original in rows:
            fingerprint = semantic_fingerprint(cfg)
            if validation.get("semantic_fingerprint") != fingerprint or not validation.get("passed"):
                continue
            ordered_raw = sorted(image_roots, key=lambda pair: (pair != original, str(pair)))
            for pictures, labels in ordered_raw:
                effective = {**cfg, "paths": {**cfg["paths"], "raw_images_dir": str(pictures),
                                              "raw_labels_dir": str(labels), "artifacts_dir": str(art)}}
                try:
                    dataset_hash = require_validated_dataset(effective, recheck=False)
                    cache_key = (pictures, labels, fingerprint)
                    if cache_key not in hashes:
                        hashes[cache_key], _ = compute_dataset_hash(effective)
                    if hashes[cache_key] != dataset_hash:
                        continue
                    manifest = load_split_manifest(art, cfg["outer_split"]["manifest_name"])
                except (OSError, ValueError, RuntimeError) as exc:
                    errors.append(f"{art}: {exc}")
                    continue
                candidates.append((effective, art, dataset_hash, str(manifest["split_hash"].iloc[0]), manifest))
                found = True
                break
            if found:
                break
    if not candidates:
        detail = " / ".join(errors[-5:])
        raise RuntimeError("No se encontró el dataset original validado con su split sellado en las fuentes locales. " + detail)
    identities = {(dataset, split, semantic_fingerprint(cfg)) for cfg, _, dataset, split, _ in candidates}
    if len(identities) > 1:
        anchored = [row for row in candidates if original_test_anchor(artifacts, row[2], row[3], semantic_fingerprint(row[0]))]
        if len({(row[2], row[3], semantic_fingerprint(row[0])) for row in anchored}) != 1:
            raise RuntimeError("Hay varios datasets/splits y el TEST histórico no permite elegir uno inequívocamente.")
        candidates = anchored
    return candidates[0], artifacts, runs


def original_test_anchor(artifacts, dataset, split, semantics):
    key = {"dataset_hash": dataset, "split_hash": split, "semantics": semantics}
    freezes = {digest for _, digest, _ in prior_freezes(artifacts, key, allow_missing_arch=True)}
    return any(matches(row, key) and row.get("freeze_sha256") in freezes
               for _, _, row in sealed_json(artifacts, "test_results*.json"))


def identity(cfg, dataset_hash, split_hash):
    runtime = {pkg: importlib.metadata.version(pkg) for pkg in
               ("torch", "torchvision", "ultralytics", "timm", "numpy", "pandas", "pillow", "opencv-python")}
    method = {key: cfg[key] for key in ("inference_tuning", "matching", "detector", "classifier", "classification_dataset", "benchmark")}
    return {"dataset_hash": dataset_hash, "split_hash": split_hash, "semantics": semantic_fingerprint(cfg),
            "code": compute_code_hash(PROJECT_ROOT), "method": method, "runtime": runtime,
            "python": sys.version.split()[0], "pairs": {k: list(v) for k, v in PAIRS.items()}}



def active_experiment(fleet, current):
    alternatives = [current, *[{**current, "code": digest} for digest in COMPATIBLE_CODE]]
    existing = [candidate for candidate in alternatives
                if (fleet / "experiments" / sha256_json(candidate) / "plan.json").is_file()]
    if len(existing) > 1:
        raise RuntimeError("Hay ejecuciones compatibles duplicadas. Se preservan ambas sin repetir tareas.")
    selected = existing[0] if existing else current
    return selected, fleet / "experiments" / sha256_json(selected)


def hybrid_val_artifacts(art, key):
    for path in sorted(art.glob("pipeline_validation*.json")):
        try:
            row = read(path)
            final = row["final_thresholds"]
            detector, classifier = final["detector"], final["classifier"]
            pair = next((h for h, models in PAIRS.items() if models == (detector["architecture"], classifier["architecture"])), None)
            method = key.get("method", {}).get("matching")
            if (not pair or not method or not matches(row, key) or row.get("status") != "PASS"
                    or row.get("evaluated_on") != "outer_validation_20pct" or row.get("predicted_crops_used") is not True
                    or final.get("test_used") is not False or final.get("tuned_on") != "outer_validation_20pct"
                    or any(final["matching"].get(k) != method.get(k) for k in ("metric", "threshold", "one_to_one_rule", "duplicate_policy"))
                    or float(key["method"]["classification_dataset"]["margin_px"]) != 0):
                continue
            yield pair, {"det_hash": detector["checkpoint_sha256"], "cls_hash": classifier["checkpoint_sha256"],
                         "det_conf": detector["conf"], "nms_iou": detector["nms_iou"],
                         "cls_threshold": classifier["probability_threshold"], "match_iou": final["matching"]["threshold"],
                         "source": "verified_original_pipeline_VAL"}
        except (OSError, TypeError, ValueError, KeyError) as exc:
            logging.warning("Validación histórica sin procedencia suficiente: %s (%s)", path, exc)


def matches(row, key):
    return all(row.get(k) == key[k] for k in ("dataset_hash", "split_hash"))


def inventory(artifact_dirs, key):
    checkpoints, thresholds, legacy = {}, {}, {}
    freezes = {digest: (path, row) for path, digest, row in prior_freezes(artifact_dirs, key, allow_missing_arch=True)}
    for art in artifact_dirs:
        metadata = {art / "final_meta.json"}
        metadata.update(art / "checkpoints" / get_arch(model).slug / "final_meta.json" for model in MODELS)
        for meta in sorted(metadata):
            if not meta.is_file():
                continue
            try:
                row = read(meta)
                model = get_arch(row["architecture"]).name
                if (model not in MODELS or not matches(row, key) or row.get("trained_on") != "outer_train_100pct"
                        or row.get("early_stopping") is not False or row.get("epoch_selected_on_validation") is not False):
                    continue
            except (OSError, ValueError, KeyError, TypeError) as exc:
                logging.warning("Metadatos finales ilegibles o desconocidos: %s (%s)", meta, exc)
                continue
            for path in sorted(meta.parent.iterdir(), key=lambda p: (p.name != "final.pt", p.name)):
                if path.suffix.casefold() not in (".pt", ".pth") or not path.is_file():
                    continue
                if row.get("size_bytes") and row["size_bytes"] != path.stat().st_size:
                    continue
                digest = sha256_file(path)
                if row.get("sha256") == digest:
                    checkpoints.setdefault(model, {})[digest] = (path, row)
                    break
        for model in MODELS:
            slug = get_arch(model).slug
            p = art / "inference_thresholds" / f"{slug}.json"
            if p.is_file():
                row = read(p)
                if (matches(row, key) and row.get("architecture") == model and row.get("test_used") is False
                        and row.get("evaluated_on") == "outer_validation_20pct"):
                    thresholds.setdefault(model, []).append(row)
        for code, point in hybrid_val_artifacts(art, key):
            thresholds.setdefault(f"hybrid-{code}", []).append(point)
        # Historical results and freezes can be stored in separate archives.
        for result, result_digest, row in sealed_json([art], "test_results*.json"):
            hash_value = row.get("freeze_sha256")
            match = freezes.get(hash_value) if isinstance(hash_value, str) else None
            hybrid = next((h for h, pair in PAIRS.items() if pair == (row.get("detector"), row.get("classifier"))), None)
            if not match or hybrid is None or not matches(row, key) or row.get("thresholds_changed_after_test") is not False:
                continue
            freeze, frozen = match
            if any(frozen[role].get("architecture") not in (None, expected)
                   for role, expected in zip(("detector", "classifier"), PAIRS[hybrid])):
                continue
            if not all(isinstance(frozen.get(role), dict) and frozen[role].get("checkpoint_hash")
                       for role in ("detector", "classifier")) or not frozen.get("pipeline", {}).get("matching_rule"):
                logging.warning("Freeze histórico sin procedencia de checkpoints o umbral: %s", freeze)
                continue
            hashes = {name: frozen[role]["checkpoint_hash"] for role, name in zip(("detector", "classifier"), PAIRS[hybrid])}
            comparison = {}
            for model in DETECTORS:
                candidate = row.get("comparison_models", {}).get(get_arch(model).slug, {})
                if (matches(candidate, key) and candidate.get("split") == "test"
                        and candidate.get("architecture") == model and candidate.get("official_metric_source") == "ultralytics_val"
                        and candidate.get("checkpoint_sha256") and "map50" in candidate and "map50_95" in candidate):
                    comparison[model] = {"checkpoint_sha256": candidate["checkpoint_sha256"], "map50": candidate["map50"],
                                         "map50_95": candidate["map50_95"], "source": "ultralytics_val"}
            item = {"path": result, "freeze": freeze, "hashes": hashes, "digest": result_digest,
                    "test_image_ids_sha256": frozen["data"].get("test_image_ids_sha256"),
                    "standard_metrics": row.get("detection_standard_metrics"), "comparison_detectors": comparison,
                    "point": {"det_conf": frozen["detector"]["confidence_threshold"], "nms_iou": frozen["detector"]["nms_iou"],
                              "cls_threshold": frozen["classifier"]["probability_threshold"],
                              "match_iou": frozen["pipeline"]["matching_rule"]["threshold"],
                              "source": "original_sealed_freeze"}}
            if hybrid in legacy and legacy[hybrid]["digest"] != item["digest"]:
                raise RuntimeError(f"Hay dos resultados históricos diferentes para {hybrid}.")
            legacy[hybrid] = item
    return checkpoints, thresholds, legacy


def gpu_profile():
    import torch
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA no disponible. Este flujo compara GPUs reales.")
    prop = torch.cuda.get_device_properties(0)
    work = torch.ones((1536, 1536), device="cuda:0", dtype=torch.float16)
    for _ in range(5):
        work @ work
    torch.cuda.synchronize(0)
    start = time.perf_counter()
    for _ in range(25):
        work @ work
    torch.cuda.synchronize(0)
    elapsed = time.perf_counter() - start
    return {"gpu_rate": (25 / elapsed) / 1200, "gpu": prop.name, "vram": prop.total_memory,
            "torch_cuda": torch.version.cuda, "host": socket.gethostname()}


def publish(work, pc, cfg, key, artifacts, runs=(), check=lambda: None):
    local, thresholds, legacy = inventory(artifacts, key)
    report = {**gpu_profile(), "local": sorted(local), "offers": {}, "legacy": {}, "thresholds": thresholds}
    for model, picks in local.items():
        report["offers"][model] = {}
        for digest, (path, meta) in picks.items():
            check()
            checkpoint_copy(path, work / "weights" / (digest + ".pt"), digest)
            report["offers"][model][digest] = {"size": path.stat().st_size, "meta": meta}
    for hybrid, row in legacy.items():
        location = work / "legacy" / hybrid / row["digest"]
        for source, name in (("path", "test_results.json"), ("freeze", "freeze_manifest.json")):
            p = row[source]
            checkpoint_copy(p, location / name, sha256_file(p))
        # Original files stay in their original tree. Capture adjacent scientific tables when available.
        run_roots = {*runs, cfg_path(cfg, "paths.runs_dir")}
        for existing in (p for root in sorted(run_roots) if root.is_dir() for p in root.rglob("metadata.json")):
            check()
            meta = read(existing)
            if meta.get("extra", {}).get("freeze_sha256") != sha256_file(row["freeze"]):
                continue
            for name in ("pipeline_detections_test.csv", "pipeline_misses_test.csv", "per_image_timing_test.csv"):
                src = existing.parent / name
                if src.is_file():
                    checkpoint_copy(src, location / name, sha256_file(src))
        report["legacy"][hybrid] = {k: v for k, v in row.items() if k not in ("path", "freeze")}
    report["registered_at"] = time.time()
    atomic_json(work / "machines" / f"{pc}.json", report)
    return local


def create_plan(work, key, counts, participants=SLOT):
    reports = {pc: read(work / "machines" / f"{pc}.json") for pc in participants}
    offered = {model: {} for model in MODELS}
    prior, stored_thresholds = {}, {}
    for row in reports.values():
        for model, versions in row["offers"].items():
            offered[model].update(versions)
        for model, thresholds in row["thresholds"].items():
            stored_thresholds.setdefault(model, []).extend(thresholds)
        for hybrid, evidence in row["legacy"].items():
            if hybrid in prior and prior[hybrid]["digest"] != evidence["digest"]:
                raise RuntimeError(f"Conflicto de resultados previos de {hybrid}.")
            prior[hybrid] = evidence
    missing = [model for model, candidates in offered.items() if not candidates]
    if missing:
        raise RuntimeError("Faltan checkpoints finales verificables: " + ", ".join(missing)
                           + ". Se necesitan los pesos y sus metadatos finales para el dataset y split recuperados.")
    chosen, sizes = {}, {}
    for model, candidates in offered.items():
        required = {p["hashes"][model] for p in prior.values() if model in p["hashes"]}
        if len(required) > 1 or len(candidates) > 1 and not required:
            raise RuntimeError(f"Varias revisiones incompatibles de {model}; se requiere identificar el checkpoint final.")
        if not candidates or (required and not required.issubset(candidates)):
            raise RuntimeError(f"Falta checkpoint final verificable de {model}.")
        digest = next(iter(required or candidates))
        chosen[model], sizes[model] = digest, candidates[digest]["size"]
        for report in reports.values():
            report["local"] = [m for m in report["local"] if m != model or digest in report["offers"][model]]
    hybrid_points = {}
    for hybrid, (det, cls) in PAIRS.items():
        if hybrid in prior:
            continue
        options = [point for point in stored_thresholds.get(f"hybrid-{hybrid}", [])
                   if (point["det_hash"], point["cls_hash"]) == (chosen[det], chosen[cls])]
        if len({sha256_json(point) for point in options}) > 1:
            raise RuntimeError(f"Hay puntos de operación VAL incompatibles para {hybrid}.")
        if options:
            hybrid_points[hybrid] = options[0]
    det_points = {}
    tune = {}
    n_val, n_test = counts
    for model in DETECTORS:
        if not any(pair[0] == model and h not in prior and h not in hybrid_points and h not in PREVIOUS
                   for h, pair in PAIRS.items()):
            continue
        relevant = [r for r in stored_thresholds.get(model, []) if r.get("checkpoint_sha256") == chosen[model]]
        historical = [p["point"] for h, p in prior.items() if PAIRS[h][0] == model]
        if relevant:
            options = {(r["conf"], r["nms_iou"]) for r in relevant}
        else:
            options = {(p["det_conf"], p["nms_iou"]) for p in historical}
        if len(options) > 1:
            raise RuntimeError(f"Umbrales VAL previos de {model} inconsistentes.")
        if options:
            conf, nms = next(iter(options))
            det_points[model] = {"det_conf": conf, "nms_iou": nms, "source": "verified_original_VAL"}
        else:
            grid = len(key["method"]["inference_tuning"]["detector_nms_iou_grid"]) if model == "YOLOv8l" else 1
            tune[model] = {"deps": [], "models": [model], "cost": COST[model] * n_val * grid}
    validation = {f"val-det-{get_arch(m).slug}": spec for m, spec in tune.items()}
    for hybrid, (det, cls) in PAIRS.items():
        if hybrid not in prior and hybrid not in PREVIOUS and hybrid not in hybrid_points:
            deps = [f"val-det-{get_arch(det).slug}"] if det in tune else []
            validation[f"point-{hybrid}"] = {"deps": deps, "models": [det, cls], "cost": (COST[det] + COST[cls]) * n_val}
    det_results = {PAIRS[h][0]: evidence["standard_metrics"] for h, evidence in prior.items() if evidence.get("standard_metrics")}
    for evidence in prior.values():
        for model, stats in evidence.get("comparison_detectors", {}).items():
            if chosen[model] == stats["checkpoint_sha256"]:
                det_results.setdefault(model, stats)
    test = {f"test-det-{get_arch(m).slug}": {"deps": [], "models": [m], "cost": COST[m] * n_test}
            for m in DETECTORS if m not in det_results}
    for hybrid, (det, cls) in PAIRS.items():
        if hybrid not in prior and hybrid not in PREVIOUS:
            test[f"test-{hybrid}"] = {"deps": [], "models": [det, cls], "cost": (COST[det] + COST[cls]) * n_test}
    return {"identity": sha256_json(key), "chosen": chosen, "sizes": sizes, "det_points": det_points, "prior": prior, "hybrid_points": hybrid_points,
            "validation": choose_plan(reports, validation, sizes), "test": choose_plan(reports, test, sizes),
            "det_results": det_results,
            "benchmark_pc": BASELINE, "participants": list(participants), "machine_profiles": {pc: {k: row[k] for k in ("gpu", "gpu_rate", "host", "vram", "torch_cuda")}
                                                          for pc, row in reports.items()}}


def authorization(work, freeze, clock):
    """Explicit release of the sealed six-hybrid experiment on the coordinator console."""
    release = work / "manual_test_release.json"
    digest = sha256_file(freeze)
    if release.is_file():
        saved = read(release)
        if saved.get("freeze_sha256") != digest or saved.get("state") != "AUTORIZADO_PERSONALMENTE" or not saved.get("operator"):
            raise RuntimeError("La autorización previa corresponde a otro freeze.")
        return True
    if not sys.stdin.isatty():
        return False
    print(f"Revise {freeze}. Para confirmar las decisiones y autorizar TEST, escriba {digest[:12]} y Enter.", flush=True)
    typed = ""
    while True:
        clock.check()
        if os.name == "nt":
            import msvcrt
            if not msvcrt.kbhit():
                time.sleep(.25)
                continue
            char = msvcrt.getwch()
            if char not in ("\r", "\n"):
                typed = typed[:-1] if char == "\b" else typed + char
                continue
        else:
            import select
            if not select.select([sys.stdin], [], [], .25)[0]:
                continue
            typed = sys.stdin.readline().strip()
        if typed == digest[:12]:
            atomic_json(release, {"state": "AUTORIZADO_PERSONALMENTE", "freeze_sha256": digest,
                                 "operator": getpass.getuser(), "host": socket.gethostname(),
                                 "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
            return True
        typed = ""


def validate_prior(work, hybrid, row, cfg, folder):
    old = work / "legacy" / hybrid / row["digest"]
    result, freeze = old / "test_results.json", old / "freeze_manifest.json"
    if sha256_file(result) != row["digest"] or sha256_file(freeze) != read(result)["freeze_sha256"]:
        raise RuntimeError(f"Resultado histórico de {hybrid} alterado.")
    point = dict(row["point"])
    if float(point["match_iou"]) != float(cfg["matching"]["threshold"]):
        raise RuntimeError(f"El IoU de asociación histórico de {hybrid} es diferente.")
    if point["nms_iou"] is None:
        point["nms_iou"] = cfg["detector"]["val_nms_iou"]
    atomic_json(folder / "point.json", point)
    return ["point.json"]


def fleet_dir(explicit):
    if explicit:
        return explicit.resolve(strict=True)
    path = os.environ.get("BOTRYTIS_FLEET_DIR")
    if path:
        return Path(path).resolve(strict=True)
    if os.name == "nt":
        import ctypes
        shares = [Path(f"{drive}:/BotrytisFleet") for drive in "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  if ctypes.windll.kernel32.GetDriveTypeW(f"{drive}:\\") == 4]
        matches = [p for p in shares if p.is_dir()]
        if len(matches) == 1:
            return matches[0]
        if matches:
            raise RuntimeError("Se encontraron varias carpetas BotrytisFleet; hay que identificar la carpeta común.")
    return None


def execution_storage(home, pc, shared, current, previous=None):
    """Continue an existing run, or choose a single safe owner when the LAN is unavailable."""
    local = home / "local-fleet"
    local_key, local_work = active_experiment(local, current)
    if previous and not previous.is_relative_to(local):
        old_share = previous.parents[1]
        if not old_share.is_dir():
            raise RuntimeError("La carpeta de una ejecución compartida anterior no está disponible. Se conserva el respaldo.")
        if shared is None:
            shared = old_share
    if shared is not None:
        key, work = active_experiment(shared, current)
        if pc != BASELINE or not (local_work / "plan.json").is_file():
            return key, work, SLOT
        if (work / "plan.json").is_file():
            raise RuntimeError("Hay un plan local y uno compartido para la misma ejecución. Se preservan ambos.")
        # Preserve completed local units, even if a share appears the following day.
        return local_key, local_work, (BASELINE,)
    if pc == BASELINE:
        return local_key, local_work, (BASELINE,)
    return current, None, ()




def export(work, evaluation, plan, key, task_key):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    from io import BytesIO
    folder = work / "consolidated"
    folder.mkdir(parents=True, exist_ok=True)
    def save_figure(fig, name):
        payload = BytesIO()
        fig.savefig(payload, format="png", dpi=180)
        plt.close(fig)
        atomic_bytes(folder / name, payload.getvalue())

    records, summaries = [], {}
    history = read(PROJECT_ROOT / "configs/hybrid_suite_history.json")
    atomic_json(folder / "historical-manuscript.json", history)
    video_rows = []
    for hybrid, (det, cls) in PAIRS.items():
        row = {"hybrid": hybrid, "detector": det, "classifier": cls}
        if hybrid in plan["prior"]:
            path = work / "legacy" / hybrid / plan["prior"][hybrid]["digest"] / "test_results.json"
            summary = read(path)["pipeline"]
            row["status"] = "reused_sealed_test"
        elif completed(evaluation.output(f"test-{hybrid}"), task_key(f"test-{hybrid}")):
            summary = read(evaluation.output(f"test-{hybrid}") / "summary.json")
            row["status"] = "completed"
        else:
            summary = {}
            row["status"] = "reported_in_manuscript_pending_artifact_verification" if hybrid in PREVIOUS else "pending"
            if hybrid in PREVIOUS:
                row.update({f"reported_{k}": value for k, value in history[hybrid].items() if isinstance(value, (int, float))})
        if summary:
            matrix = summary["pipeline_confusion_matrix"]
            tp, fp, fn = matrix[0][0], matrix[1][0] + matrix[2][0], matrix[0][1] + matrix[0][2]
            row.update(positive_tp=tp, positive_fp=fp, positive_fn=fn, positive_precision=tp / (tp + fp) if tp + fp else 0.0,
                       positive_recall=tp / (tp + fn) if tp + fn else 0.0,
                       positive_f1=2*tp / (2*tp + fp + fn) if 2*tp + fp + fn else 0.0,
                       positive_f2=5*tp / (5*tp + fp + 4*fn) if 5*tp + fp + 4*fn else 0.0)
            summaries[hybrid] = summary
            for group in ("detection", "classification_on_matched", "errors"):
                row.update({f"{group}_{k}": v for k, v in summary[group].items() if isinstance(v, (int, float)) or v is None})
        det_name = f"test-det-{get_arch(det).slug}"
        if completed(evaluation.output(det_name), task_key(det_name)):
            det_stats = read(evaluation.output(det_name) / "summary.json")
            row.update(map50=det_stats["map50"], map50_95=det_stats["map50_95"], detector_ap_method=det_stats["method"])
        elif det in plan["det_results"]:
            det_stats = plan["det_results"][det]
            row.update(map50=det_stats.get("map50"), map50_95=det_stats.get("map50_95"), detector_ap_method=det_stats.get("source"))
        video_name = f"video-{hybrid}"
        if completed(evaluation.output(video_name), task_key(video_name)):
            videos = read(evaluation.output(video_name) / "summary.json")["videos"]
            for video in videos:
                video_rows.append({"hybrid": hybrid, "video": video["video"], "fps": video["effective_fps"],
                                   "frame_ms_p95": video["frame_ms"]["p95_ms"], "active_seconds": video["total_active_seconds"],
                                   "delay_p95": video["finish_after_capture_ms"]["p95_ms"],
                                   "continuity": video["continuity_same_class_iou50"]})
        records.append(row)
    def table(name, records):
        import io
        stream = io.StringIO(newline="")
        columns = list(dict.fromkeys(k for row in records for k in row))
        writer = csv.DictWriter(stream, columns)
        writer.writeheader()
        writer.writerows(records)
        atomic_bytes(folder / name, stream.getvalue().encode("utf-8"))
    table("test.csv", records)
    if video_rows:
        table("synthetic-video.csv", video_rows)
    mobile = evaluation.output("mobile")
    if completed(mobile, task_key("mobile")):
        summary = read(mobile / "summary.json")
        deployment_rows = [{"hybrid": h, "stage": kind, **values} for h, stages in summary["results"].items()
                           for kind, values in stages.items()]
        table("deployment.csv", deployment_rows)
        fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)
        for stage, label in (("client_ms", "Navegador E2E"), ("server_ms", "Servidor LAN"), ("pipeline_ms", "Inferencia")):
            ax.plot(list(PAIRS), [r["p95_ms"] for r in deployment_rows if r["stage"] == stage], marker="o", label=label)
        ax.set(xlabel="Híbrido", ylabel="p95 (ms)")
        ax.legend()
        save_figure(fig, "deployment-p95.png")
    atomic_json(folder / "test_summaries.json", summaries)
    if summaries:
        fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)
        for row in records:
            if "positive_f1" in row:
                ax.scatter(row["hybrid"], row["positive_f1"], color="#116f72", s=58)
            elif "reported_f1" in row:
                ax.scatter(row["hybrid"], row["reported_f1"], facecolors="none", edgecolors="#b35a1d", s=58)
        ax.set(xlabel="Híbrido", ylabel="F1 positivo extremo a extremo", ylim=(0, 1.03),
               title="Puntos huecos: valores documentados pendientes de verificar")
        save_figure(fig, "f1-positivo-test.png")
        fig, axes = plt.subplots(2, 3, figsize=(12, 7), constrained_layout=True)
        for hybrid, ax in zip(PAIRS, axes.flat):
            ax.set_title(hybrid)
            if hybrid not in summaries:
                ax.text(.5, .5, "Pendiente", ha="center")
                ax.set_axis_off()
                continue
            summary = summaries[hybrid]
            matrix = np.asarray(summary["pipeline_confusion_matrix"])
            ax.imshow(matrix, cmap="Blues")
            ax.set_xticks(range(3), summary["pipeline_confusion_cols"], rotation=30, ha="right", fontsize=7)
            ax.set_yticks(range(3), summary["pipeline_confusion_rows"], fontsize=7)
            for (i, j), cell in np.ndenumerate(matrix):
                ax.text(j, i, str(cell), ha="center", va="center", color="white" if cell > matrix.max() / 2 else "black")
        save_figure(fig, "matrices-confusion.png")
    if video_rows:
        fig, ax = plt.subplots(figsize=(9, 4), constrained_layout=True)
        by_hybrid = [[r["frame_ms_p95"] for r in video_rows if r["hybrid"] == h] for h in PAIRS]
        ax.boxplot(by_hybrid, tick_labels=list(PAIRS), showmeans=True)
        ax.set(ylabel="p95 por fotograma (ms)", xlabel="Híbrido")
        save_figure(fig, "video-p95.png")
    atomic_json(folder / "provenance.json", {"experiment": sha256_json(key), "test_results": records,
                "test_provenance": read(work / "test-provenance.json")["evidence"],
                "detector_ap": "Detector AP reused from the original experiment when available. Compare only identical reported estimators.",
                "training_lab": "Consult machine inventories for prior train_seconds and descriptive image timing.",
                "deployment": "Separate browser prototype on the benchmark PC; see deployment.csv when measured."})


def run(args):
    from hybrid_suite.evaluation import Evaluation, stage_key
    from hybrid_suite import video
    from utils.prepared import load_prepared_data
    from utils.reproducibility import set_global_seed

    base = Path(os.environ.get("USERPROFILE", Path.home())) / "Documents/s2_no_borrar"
    pc = identify(read(PROJECT_ROOT / "configs/fleet_mapping.json"))
    owner = {"pc": pc, "host": socket.gethostname(), "user": getpass.getuser()}
    home = base / "HybridSuite" / pc
    logs = home / "logs"
    local_state = home / "state"
    logs.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=logs / "runner.log", level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s", encoding="utf-8")
    logging.info("Jornada %s en %s", args.mode, owner)
    recovery_marker = home / "recovery-roots.json"
    paths = {name: Path(path) for name, path in read(recovery_marker).items()} if recovery_marker.is_file() else {}
    if args.mode == "Tomorrow" and paths:
        with FileLock(home / "runner.lock"):
            if "replicated_work" in paths and not paths["replicated_work"].parents[1].is_dir():
                raise RuntimeError("El directorio compartido original no está disponible. Se conserva el respaldo.")
            saved = restore(home, paths, owner)
            logging.info("Respaldo recuperado: %s", saved)
    imports = filesystem_path(home / "imports")
    report = base / "Consolidado_Tesis" / "resultados_ejecucion"
    roots = {"local_state": local_state, "logs": logs, "imported": imports, "source_config": PROJECT_ROOT / "configs",
             "local_report": report}

    def snapshot():
        if work := roots.get("replicated_work"):
            try:
                local_report(work, report, pc, final=(work / "consolidated" / "final-ready.json").is_file())
            except (OSError, RuntimeError, ValueError) as exc:
                logging.warning("Avance local pendiente de copiar: %s", exc)
        digest = backup(home, roots, owner)
        logging.info("Respaldo verificado: %s", digest)
        print(f"Respaldo verificado: {digest}", flush=True)

    clock = Clock(args.mode, snapshot)
    with FileLock(home / "runner.lock"):
        if not recovery_marker.is_file():
            atomic_json(recovery_marker, {name: str(path) for name, path in roots.items()})
        # Import only evidence and weights. No scripts from historical ZIPs are run.
        recover_downloads(args.downloads, imports, clock)
    recovered = [p for p in imports.iterdir() if p.is_dir() and (p / ".recovered.json").is_file()]
    sources = [*project_sources(base, args.downloads), *recovered]
    shared = fleet_dir(args.fleet)
    if shared is None and not paths.get("replicated_work") and pc != BASELINE:
        print(f"{pc}: carpeta de red ausente. Importación local y consolidado histórico listos; PC-01 es la única ejecutora local.", flush=True)
        snapshot()
        return
    cfg_info, artifacts, runs = session_config(sources)
    cfg, art, dataset_hash, split_hash, manifest = cfg_info
    cfg["compute"]["device"] = "cuda:0"
    current_key = identity(cfg, dataset_hash, split_hash)
    key, work, participants = execution_storage(home, pc, shared, current_key, paths.get("replicated_work"))
    if work is None:
        print(f"{pc}: importación local lista; la ejecución sin red corresponde a PC-01.", flush=True)
        snapshot()
        return
    if participants == (BASELINE,):
        print("No hay coordinación compartida para esta ejecución. PC-01 continuará en modo local con el TEST y los checkpoints verificables.", flush=True)
    basis = sha256_json(key)
    work.mkdir(parents=True, exist_ok=True)
    roots.update(replicated_work=work, scientific_artifacts=art, raw_images=cfg_path(cfg, "paths.raw_images_dir"),
                 raw_labels=cfg_path(cfg, "paths.raw_labels_dir"))
    for index, run_root in enumerate(runs):
        roots[f"prior_runs_{index}"] = run_root
    with FileLock(home / "runner.lock"):
        atomic_json(home / "recovery-roots.json", {key: str(path) for key, path in roots.items()})
        clock.check()
        atomic_json(local_state / "effective-config.json", cfg)
        atomic_json(local_state / "experiment.json", key)
        set_global_seed(int(cfg["reproducibility"]["seed"]))
        publish(work, pc, cfg, key, artifacts, runs=runs, check=clock.check)
        plan_file = work / "plan.json"
        registered = read(work / "machines" / f"{pc}.json")["registered_at"]
        while not plan_file.is_file():
            clock.check()
            if (work / "preflight-error.json").is_file():
                diagnostic = read(work / "preflight-error.json")
                if diagnostic.get("registered", {}).get(pc) == registered:
                    raise RuntimeError(diagnostic["message"])
            if pc == BASELINE and all((work / "machines" / f"{p}.json").is_file() for p in participants):
                counts = [int(manifest["outer_split"].eq(split).sum()) for split in ("validation", "test")]
                try:
                    atomic_json(plan_file, create_plan(work, key, counts, participants))
                except RuntimeError as exc:
                    atomic_json(work / "preflight-error.json", {"message": str(exc),
                                "registered": {p: read(work / "machines" / f"{p}.json").get("registered_at") for p in participants}})
                    raise
                break
            time.sleep(5)
        plan = read(plan_file)
        if plan["identity"] != basis or tuple(plan.get("participants", SLOT)) != participants:
            raise RuntimeError("Plan incompatible con el código, el dataset o las máquinas disponibles.")
        expected_profile = plan["machine_profiles"][pc]
        current_profile = read(work / "machines" / f"{pc}.json")
        if any(expected_profile[k] != current_profile[k] for k in ("host", "gpu", "vram", "torch_cuda")):
            raise RuntimeError(f"El equipo o la GPU cambió desde el plan de {pc}; se conservan las mediciones previas.")
        selected_hash = sha256_json(plan["chosen"])
        print(f"{pc} · {work} · VAL: {plan['validation']['owners']} · TEST: {plan['test']['owners']}", flush=True)
        def checkpoint(model):
            return stage_checkpoint(work / "weights", local_state / "checkpoints", plan["chosen"][model])
        data = load_prepared_data(cfg, with_split=True)
        evaluation = Evaluation(cfg, data, work, checkpoint, clock)
        def val_key(name):
            return stage_key(basis, name, selected_hash, sha256_json(plan["prior"]))
        def perform(name, kind, func):
            if not completed(evaluation.output(name), kind(name)):
                logging.info("Iniciando %s", name)
                print(f"{pc} · {name}", flush=True)
                evaluation.execute(name, kind(name), func)
                logging.info("Sellado %s", name)
        for model, point in plan["det_points"].items():
            name = f"val-det-{get_arch(model).slug}"
            if pc == BASELINE:
                perform(name, val_key, lambda folder, point=point: store_point(folder, point, cfg))
        history = read(PROJECT_ROOT / "configs/hybrid_suite_history.json")
        if pc == BASELINE:
            for hybrid, point in plan.get("hybrid_points", {}).items():
                perform(f"point-{hybrid}", val_key, lambda folder, point=point: store_point(folder, point, cfg))
            for hybrid, prior in plan["prior"].items():
                perform(f"point-{hybrid}", val_key, lambda folder, prior=prior: validate_prior(work, hybrid, prior, cfg, folder))
            for hybrid in PREVIOUS:
                if hybrid in plan["prior"] or hybrid in plan.get("hybrid_points", {}):
                    continue
                documented = history[hybrid]
                point = {"det_conf": documented["det_conf"], "nms_iou": None,
                         "cls_threshold": documented["cls_threshold"], "match_iou": cfg["matching"]["threshold"],
                         "source": "reported_in_manuscript_VAL_original_hybrid_seal_unverified"}
                perform(f"point-{hybrid}", val_key, lambda folder, point=point: store_point(folder, point, cfg))
        evidence = original_test_evidence(artifacts, key, data, cfg, history, plan["prior"])
        atomic_json(work / "machines" / f"{pc}-test.json", {**evidence, "registered_at": registered})
        validation = plan["validation"]["owners"]
        val_points = {f"point-{h}" for h in PAIRS}
        while any(not completed(evaluation.output(n), val_key(n)) for n in val_points):
            clock.check()
            progress = False
            for name, assign in validation.items():
                if assign != pc or completed(evaluation.output(name), val_key(name)):
                    continue
                if name.startswith("val-det-"):
                    model = next(m for m in DETECTORS if name.endswith(get_arch(m).slug))
                    perform(name, val_key, lambda folder: evaluation.detector_stage(model, "validation", val_key(name), folder))
                else:
                    hybrid = name[-1]
                    det_task = f"val-det-{get_arch(PAIRS[hybrid][0]).slug}"
                    if not completed(evaluation.output(det_task), val_key(det_task)):
                        continue
                    point = read(evaluation.output(det_task) / "point.json")
                    perform(name, val_key, lambda folder: evaluation.integrated(hybrid, "validation", {**point, "cls_threshold": 0.5}, val_key(name), folder))
                progress = True
            if not progress:
                time.sleep(5)
        provenance = work / "test-provenance.json"
        if pc == BASELINE:
            evidence_files = [work / "machines" / f"{p}-test.json" for p in participants]
            proven = [read(path) for path in evidence_files if path.is_file()]
            exact = ("dataset_hash", "split_hash", "test_image_ids_sha256")
            valid = [item for item in proven if all(item.get(k) == evidence.get(k) for k in exact)
                     and item.get("method") in TEST_PROOF_METHODS]
            selected = valid[0] if valid else evidence
            selected.pop("registered_at", None)
            coordinator_stamp = read(work / "machines" / f"{BASELINE}.json")["registered_at"]
            if not provenance.is_file() or read(provenance).get("evidence", {}).get("method") == "pending":
                atomic_json(provenance, {"coordinator": coordinator_stamp, "evidence": selected})
        while True:
            clock.check()
            if provenance.is_file():
                view = read(provenance)
                coordinator_stamp = read(work / "machines" / f"{BASELINE}.json").get("registered_at")
                if view["evidence"].get("method") != "pending" or view["coordinator"] == coordinator_stamp:
                    break
            time.sleep(5)
        chosen_test = view["evidence"]
        if any(chosen_test.get(k) != evidence.get(k) for k in ("dataset_hash", "split_hash", "test_image_ids_sha256")):
            raise RuntimeError("La procedencia compartida no corresponde al TEST recuperado en esta máquina.")
        if chosen_test.get("method") == "pending":
            snapshot()
            print(f"VAL guardado. TEST pendiente: {chosen_test.get('reason')}", flush=True)
            return
        if chosen_test.get("method") not in TEST_PROOF_METHODS:
            raise RuntimeError("Método de verificación del TEST desconocido.")
        freeze = work / "freeze.json"
        frozen = {"experiment": key, "checkpoints": plan["chosen"], "prior": plan["prior"],
                  "test_ids": evaluation.ids("test"), "thresholds": {h: evaluation.point(h) for h in PAIRS}}
        # Preserve previously authorized freezes byte for byte.
        if not freeze.is_file() or "test_provenance" in read(freeze):
            frozen["test_provenance"] = chosen_test
        if pc == BASELINE:
            if not freeze.is_file():
                atomic_json(freeze, frozen)
            if read(freeze) != frozen:
                raise RuntimeError("El freeze guardado no coincide con los artefactos VAL.")
            if not authorization(work, freeze, clock):
                snapshot()
                raise RuntimeError("TEST pendiente de aprobación personal del freeze en la consola PC-01.")
        while not (work / "manual_test_release.json").is_file():
            clock.check()
            time.sleep(5)
        if read(freeze) != frozen:
            raise RuntimeError("El freeze cambió tras VAL.")
        release = read(work / "manual_test_release.json")
        freeze_hash = sha256_file(freeze)
        if release.get("state") != "AUTORIZADO_PERSONALMENTE" or release.get("freeze_sha256") != freeze_hash or not release.get("operator"):
            raise RuntimeError("TEST cerrado: el freeze actual no tiene autorización válida.")
        def test_key(name):
            if name.startswith("video-") or name == "mobile":
                return stage_key(basis, name, freeze_hash, plan["machine_profiles"][BASELINE]["host"],
                                 plan["machine_profiles"][BASELINE]["gpu"])
            return stage_key(basis, name, freeze_hash)
        test = plan["test"]["owners"]
        for name, assign in test.items():
            if assign != pc:
                continue
            if name.startswith("test-det-"):
                model = next(m for m in DETECTORS if name.endswith(get_arch(m).slug))
                perform(name, test_key, lambda folder: evaluation.detector_stage(model, "test", test_key(name), folder))
            else:
                hybrid = name[-1]
                perform(name, test_key, lambda folder: evaluation.integrated(hybrid, "test", evaluation.point(hybrid), test_key(name), folder))
        snapshot()
        final_folder = work / "consolidated"
        if pc != BASELINE:
            while not completed(final_folder, freeze_hash, marker="final-ready.json"):
                clock.check()
                time.sleep(5)
            local_report(work, report, pc, final=True)
            snapshot()
            print(f"Consolidación: {report / 'index.html'}", flush=True)
            return
        if completed(final_folder, freeze_hash, marker="final-ready.json"):
            local_report(work, report, pc, final=True)
            snapshot()
            print(f"Consolidación: {report / 'index.html'}", flush=True)
            return
        while any(not completed(evaluation.output(n), test_key(n)) for n in test):
            clock.check()
            time.sleep(5)
        export(work, evaluation, plan, key, test_key)

        def benchmark(name, operation):
            if completed(evaluation.output(name), test_key(name)):
                return True
            from hybrid_suite.benchmark_gpu import selected_gpu, wait_for_idle

            print(f"Comprobando utilización de la GPU antes de {name}…", flush=True)
            load = wait_for_idle(selected_gpu(), clock.check)
            atomic_json(final_folder / f"gpu-{name}.json", load)
            if load["status"] != "ready":
                reason = load.get("reason") or f"utilización reciente {load['samples_percent'][-4:]} %"
                export(work, evaluation, plan, key, test_key)
                snapshot()
                print(f"Benchmarks pendientes en {name}: {reason}. TEST y las etapas completas quedaron guardados.", flush=True)
                return False
            perform(name, test_key, operation)
            return True

        inputs = work / "synthetic"
        video.make_clips(evaluation, inputs, test_key("synthetic-input"))
        for hybrid in PAIRS:
            name = f"video-{hybrid}"
            if not benchmark(name, lambda folder: video.video_trial(evaluation, hybrid, folder, test_key(name), inputs)):
                return
        export(work, evaluation, plan, key, test_key)
        if any(h not in plan["prior"] for h in PREVIOUS):
            print("A/B: falta evidencia histórica verificable en una o ambas combinaciones. TEST de imagen no repetido.", flush=True)
        if not completed(evaluation.output("mobile"), test_key("mobile")):
            from hybrid_suite.mobile import serve
            if not benchmark("mobile", lambda folder: serve(evaluation, folder, test_key("mobile"), inputs)):
                return
        export(work, evaluation, plan, key, test_key)
        files = [file.name for file in final_folder.iterdir() if file.is_file() and file.name != "final-ready.json"]
        seal(final_folder, freeze_hash, files, {"pc": pc}, marker="final-ready.json")
        local_report(work, report, pc, final=True)
        snapshot()
        print(f"Consolidación: {report / 'index.html'}", flush=True)


def store_point(folder, point, cfg):
    atomic_json(folder / "point.json", {**point, "nms_iou": point["nms_iou"] if point["nms_iou"] is not None else cfg["detector"]["val_nms_iou"]})
    return ["point.json"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("Today", "Tomorrow"))
    parser.add_argument("--downloads", type=Path, default=Path.home() / "Downloads")
    parser.add_argument("--fleet", type=Path)
    args = parser.parse_args()
    try:
        run(args)
    except Pause as exc:
        print(exc, flush=True)
    except (OSError, RuntimeError, ValueError) as exc:
        logging.error("%s", exc)
        print(f"PENDIENTE: {exc}", file=sys.stderr, flush=True)
        return 2
    return 0
